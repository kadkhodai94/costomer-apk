# برنامه مهاجرت دیتابیس به SQLite/Drift

برای نسخه انتشار رسمی:

Tables:
- businesses(id, name, category, phone, createdAt)
- customers(id, businessId, name, phone, note, createdAt)
- transactions(id, customerId, type, amount, date, reminderDate, note, createdAt, updatedAt)
- settings(key, value)

Indexes:
- customers_businessId
- transactions_customerId
- transactions_reminderDate

مسیر مهاجرت:
1. خواندن JSON فعلی از SharedPreferences
2. ساخت جداول SQLite
3. انتقال businesses/customers/transactions
4. نگهداری backup JSON برای اطمینان
