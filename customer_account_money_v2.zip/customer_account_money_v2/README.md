# Customer Account Money V2

نسخه ۲ پول‌ساز اپ مدیریت حساب مشتریان.

امکانات:
- Flutter + Material 3
- SQLite واقعی با sqflite
- ثبت کسب‌وکار
- ورود با رمز ۴ رقمی
- ثبت مشتری
- ثبت بدهی، پرداخت، تخفیف / اصلاح حساب
- تاریخ شمسی دستی مثل ۱۴۰۳/۰۳/۲۳
- یادآوری بدهی‌ها داخل اپ
- داشبورد
- گزارش کلی
- خروجی JSON
- خروجی CSV قابل باز شدن در Excel
- خروجی Word
- خروجی PDF برای مشتری
- ارسال صورتحساب واتساپ
- workflow آماده GitHub Actions برای ساخت APK

برای ساخت APK:
1. این ZIP را با نام customer_account_money_v2.zip در ریشه ریپو بگذار.
2. workflow داخل .github/workflows/build-apk.yml آماده است.
3. از تب Actions اجرا کن.
