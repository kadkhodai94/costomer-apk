
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MoneyApp());
}

class MoneyApp extends StatelessWidget {
  const MoneyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xff00a98f);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دفتر حساب مشتریان',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xfff4fbfb),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
      ),
      home: const AuthGate(),
    );
  }
}

String fa(String input) {
  const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const pr = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  var out = input;
  for (var i = 0; i < en.length; i++) {
    out = out.replaceAll(en[i], pr[i]);
  }
  return out;
}

String enDigits(String input) {
  const pr = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const ar = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  var out = input;
  for (var i = 0; i < en.length; i++) {
    out = out.replaceAll(pr[i], en[i]).replaceAll(ar[i], en[i]);
  }
  return out;
}

String money(int value) {
  final s = value.abs().toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'),
        (_) => ',',
      );
  return '${fa(s)} تومان';
}

String signedMoney(int value) {
  if (value == 0) return 'تسویه';
  if (value < 0) return 'بستانکار: ${money(value)}';
  return money(value);
}

int cleanAmount(String value) {
  return int.tryParse(enDigits(value).replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
}

int _div(int a, int b) => a ~/ b;
int _mod(int a, int b) => a - (a ~/ b) * b;

int _g2d(int gy, int gm, int gd) {
  var d = _div((gy + _div(gm - 8, 6) + 100100) * 1461, 4) +
      _div(153 * _mod(gm + 9, 12) + 2, 5) +
      gd -
      34840408;
  d = d - _div(_div(gy + 100100 + _div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

({int gy, int gm, int gd}) _d2g(int jdn) {
  var j = 4 * jdn + 139361631;
  j = j + _div(_div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  final i = _div(_mod(j, 1461), 4) * 5 + 308;
  final gd = _div(_mod(i, 153), 5) + 1;
  final gm = _mod(_div(i, 153), 12) + 1;
  final gy = _div(j, 1461) - 100100 + _div(8 - gm, 6);
  return (gy: gy, gm: gm, gd: gd);
}

({int leap, int gy, int march}) _jalCal(int jy) {
  final breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  var gy = jy + 621;
  var leapJ = -14;
  var jp = breaks[0];
  var jump = 0;
  for (var i = 1; i < breaks.length; i++) {
    final jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + _div(jump, 33) * 8 + _div(_mod(jump, 33), 4);
    jp = jm;
  }
  var n = jy - jp;
  leapJ = leapJ + _div(n, 33) * 8 + _div(_mod(n, 33) + 3, 4);
  if (_mod(jump, 33) == 4 && jump - n == 4) leapJ += 1;
  final leapG = _div(gy, 4) - _div((_div(gy, 100) + 1) * 3, 4) - 150;
  final march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + _div(jump + 4, 33) * 33;
  var leap = _mod(_mod(n + 1, 33) - 1, 4);
  if (leap == -1) leap = 4;
  return (leap: leap, gy: gy, march: march);
}

int _j2d(int jy, int jm, int jd) {
  final r = _jalCal(jy);
  return _g2d(r.gy, 3, r.march) + (jm - 1) * 31 - _div(jm, 7) * (jm - 7) + jd - 1;
}

({int jy, int jm, int jd}) _d2j(int jdn) {
  final gy = _d2g(jdn).gy;
  var jy = gy - 621;
  final r = _jalCal(jy);
  final jdn1f = _g2d(gy, 3, r.march);
  var k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) return (jy: jy, jm: 1 + _div(k, 31), jd: _mod(k, 31) + 1);
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap == 1) k += 1;
  }
  return (jy: jy, jm: 7 + _div(k, 30), jd: _mod(k, 30) + 1);
}

String pad2(int n) => n.toString().padLeft(2, '0');
String isoToday() => DateTime.now().toIso8601String().substring(0, 10);

String isoToJalali(String? iso) {
  if (iso == null || iso.isEmpty) return '-';
  final p = iso.split('-').map((e) => int.tryParse(e) ?? 0).toList();
  if (p.length != 3 || p.contains(0)) return '-';
  final j = _d2j(_g2d(p[0], p[1], p[2]));
  return fa('${j.jy}/${pad2(j.jm)}/${pad2(j.jd)}');
}

String todayJalali() => isoToJalali(isoToday());

String? jalaliToIso(String value) {
  final cleaned = enDigits(value.trim()).replaceAll('-', '/');
  if (cleaned.isEmpty) return null;
  final p = cleaned.split('/').map((e) => int.tryParse(e) ?? 0).toList();
  if (p.length != 3 || p.contains(0)) return null;
  try {
    final g = _d2g(_j2d(p[0], p[1], p[2]));
    return '${g.gy}-${pad2(g.gm)}-${pad2(g.gd)}';
  } catch (_) {
    return null;
  }
}

class AppDb {
  static Database? _db;

  static Future<Database> get instance async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'customer_money_v2.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
        await db.execute('CREATE TABLE businesses(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, phone TEXT)');
        await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, businessId INTEGER NOT NULL, name TEXT NOT NULL, phone TEXT, note TEXT, createdAt TEXT NOT NULL)');
        await db.execute('CREATE TABLE account_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER NOT NULL, type TEXT NOT NULL, amount INTEGER NOT NULL, dateIso TEXT NOT NULL, reminderIso TEXT, note TEXT, createdAt TEXT NOT NULL)');
      },
    );
    return _db!;
  }

  static Future<String?> getSetting(String key) async {
    final db = await instance;
    final rows = await db.query('settings', where: 'key=?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  static Future<void> setSetting(String key, String value) async {
    final db = await instance;
    await db.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<int?> activeBusinessId() async {
    final id = await getSetting('activeBusinessId');
    return id == null ? null : int.tryParse(id);
  }

  static Future<Map<String, Object?>?> activeBusiness() async {
    final db = await instance;
    final id = await activeBusinessId();
    if (id == null) return null;
    final rows = await db.query('businesses', where: 'id=?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<int> createBusiness(String name, String category, String phone) async {
    final db = await instance;
    final id = await db.insert('businesses', {'name': name, 'category': category, 'phone': phone});
    await setSetting('activeBusinessId', '$id');
    return id;
  }

  static Future<void> updateBusiness(int id, String name, String category, String phone) async {
    final db = await instance;
    await db.update('businesses', {'name': name, 'category': category, 'phone': phone}, where: 'id=?', whereArgs: [id]);
  }

  static Future<List<Map<String, Object?>>> customers({String query = ''}) async {
    final db = await instance;
    final businessId = await activeBusinessId();
    if (businessId == null) return [];
    if (query.trim().isEmpty) {
      return db.query('customers', where: 'businessId=?', whereArgs: [businessId], orderBy: 'id DESC');
    }
    return db.query(
      'customers',
      where: 'businessId=? AND (name LIKE ? OR phone LIKE ? OR note LIKE ?)',
      whereArgs: [businessId, '%$query%', '%$query%', '%$query%'],
      orderBy: 'id DESC',
    );
  }

  static Future<int> insertCustomer(String name, String phone, String note) async {
    final db = await instance;
    final businessId = await activeBusinessId();
    if (businessId == null) throw Exception('No active business');
    return db.insert('customers', {'businessId': businessId, 'name': name, 'phone': phone, 'note': note, 'createdAt': DateTime.now().toIso8601String()});
  }

  static Future<void> updateCustomer(int id, String name, String phone, String note) async {
    final db = await instance;
    await db.update('customers', {'name': name, 'phone': phone, 'note': note}, where: 'id=?', whereArgs: [id]);
  }

  static Future<void> deleteCustomer(int id) async {
    final db = await instance;
    await db.delete('account_transactions', where: 'customerId=?', whereArgs: [id]);
    await db.delete('customers', where: 'id=?', whereArgs: [id]);
  }

  static Future<Map<String, Object?>?> customer(int id) async {
    final db = await instance;
    final rows = await db.query('customers', where: 'id=?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<List<Map<String, Object?>>> transactions(int customerId) async {
    final db = await instance;
    return db.query('account_transactions', where: 'customerId=?', whereArgs: [customerId], orderBy: 'dateIso DESC, id DESC');
  }

  static Future<void> insertTransaction({required int customerId, required String type, required int amount, required String dateIso, String? reminderIso, String note = ''}) async {
    final db = await instance;
    await db.insert('account_transactions', {
      'customerId': customerId,
      'type': type,
      'amount': amount,
      'dateIso': dateIso,
      'reminderIso': reminderIso,
      'note': note,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> deleteTransaction(int id) async {
    final db = await instance;
    await db.delete('account_transactions', where: 'id=?', whereArgs: [id]);
  }

  static Future<int> balance(int customerId) async {
    final txs = await transactions(customerId);
    var total = 0;
    for (final t in txs) {
      final type = t['type'] as String;
      final amount = t['amount'] as int;
      total += type == 'debt' ? amount : -amount;
    }
    return total;
  }

  static Future<Map<String, int>> stats() async {
    final list = await customers();
    var totalDebt = 0, debtors = 0, settled = 0, credit = 0;
    for (final c in list) {
      final b = await balance(c['id'] as int);
      if (b > 0) {
        totalDebt += b;
        debtors++;
      } else if (b == 0) {
        settled++;
      } else {
        credit++;
      }
    }
    return {'customers': list.length, 'totalDebt': totalDebt, 'debtors': debtors, 'settled': settled, 'credit': credit};
  }

  static Future<List<Map<String, Object?>>> remindersDue() async {
    final db = await instance;
    final today = isoToday();
    return db.rawQuery('SELECT t.*, c.name as customerName, c.phone as customerPhone FROM account_transactions t JOIN customers c ON c.id = t.customerId WHERE t.reminderIso IS NOT NULL AND t.reminderIso != "" AND t.reminderIso <= ? ORDER BY t.reminderIso ASC', [today]);
  }

  static Future<Map<String, dynamic>> backupData() async {
    final db = await instance;
    return {
      'settings': {'pin': await getSetting('pin'), 'activeBusinessId': await getSetting('activeBusinessId')},
      'business': await activeBusiness(),
      'customers': await db.query('customers'),
      'transactions': await db.query('account_transactions'),
      'createdAt': DateTime.now().toIso8601String(),
    };
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading = true, setupDone = false, loggedIn = false;

  @override
  void initState() {
    super.initState();
    check();
  }

  Future<void> check() async {
    await AppDb.instance;
    final pin = await AppDb.getSetting('pin');
    final business = await AppDb.activeBusiness();
    setState(() {
      setupDone = pin != null && business != null;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!setupDone) return SetupScreen(onDone: () async { await check(); setState(() => loggedIn = true); });
    if (!loggedIn) return LoginScreen(onLogin: () => setState(() => loggedIn = true));
    return AppShell(onLogout: () => setState(() => loggedIn = false));
  }
}

class SetupScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SetupScreen({super.key, required this.onDone});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final name = TextEditingController();
  final category = TextEditingController();
  final phone = TextEditingController();
  final pin = TextEditingController();
  final pin2 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: ProBackground(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(18), child: ProCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const AppLogo(),
        const SizedBox(height: 14),
        Text('راه‌اندازی دفتر حساب', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        ProField(controller: name, label: 'نام کسب‌وکار'),
        const SizedBox(height: 10),
        ProField(controller: category, label: 'دسته شغلی'),
        const SizedBox(height: 10),
        ProField(controller: phone, label: 'شماره تماس اختیاری', keyboardType: TextInputType.phone),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: ProField(controller: pin, label: 'رمز ۴ رقمی', obscure: true, keyboardType: TextInputType.number)), const SizedBox(width: 10), Expanded(child: ProField(controller: pin2, label: 'تکرار رمز', obscure: true, keyboardType: TextInputType.number))]),
        const SizedBox(height: 18),
        FilledButton(onPressed: save, child: const Text('ساخت اپ')),
      ]))))),
    ));
  }

  Future<void> save() async {
    if (name.text.trim().isEmpty || category.text.trim().isEmpty) {
      toast(context, 'نام و دسته شغلی را کامل وارد کن');
      return;
    }
    if (!RegExp(r'^\d{4}$').hasMatch(enDigits(pin.text.trim()))) {
      toast(context, 'رمز باید ۴ رقم باشد');
      return;
    }
    if (enDigits(pin.text.trim()) != enDigits(pin2.text.trim())) {
      toast(context, 'تکرار رمز درست نیست');
      return;
    }
    await AppDb.createBusiness(name.text.trim(), category.text.trim(), phone.text.trim());
    await AppDb.setSetting('pin', enDigits(pin.text.trim()));
    widget.onDone();
  }
}

class LoginScreen extends StatefulWidget {
  final VoidCallback onLogin;
  const LoginScreen({super.key, required this.onLogin});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final pin = TextEditingController();
  Map<String, Object?>? business;
  @override
  void initState() {
    super.initState();
    AppDb.activeBusiness().then((b) => setState(() => business = b));
  }
  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: ProBackground(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(18), child: ProCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const AppLogo(),
        const SizedBox(height: 14),
        Text(business?['name']?.toString() ?? 'دفتر حساب', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        ProField(controller: pin, label: 'رمز ورود', obscure: true, keyboardType: TextInputType.number),
        const SizedBox(height: 16),
        FilledButton(onPressed: login, child: const Text('ورود')),
      ]))))),
    ));
  }
  Future<void> login() async {
    final saved = await AppDb.getSetting('pin');
    if (saved == enDigits(pin.text.trim())) {
      widget.onLogin();
    } else {
      toast(context, 'رمز اشتباه است');
    }
  }
}

class AppShell extends StatefulWidget {
  final VoidCallback onLogout;
  const AppShell({super.key, required this.onLogout});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const HomePage(), const CustomersPage(), const RemindersPage(), ReportsPage(), SettingsPage(onLogout: widget.onLogout)];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'مشتری‌ها'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'یادآوری'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'گزارش'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
        ],
      ),
    ));
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Future<Map<String, int>>? statsFuture;
  Future<Map<String, Object?>?>? businessFuture;
  @override
  void initState() {
    super.initState();
    reload();
  }
  void reload() => setState(() { statsFuture = AppDb.stats(); businessFuture = AppDb.activeBusiness(); });

  @override
  Widget build(BuildContext context) {
    return ProScaffold(title: 'داشبورد', child: RefreshIndicator(onRefresh: () async => reload(), child: ListView(padding: const EdgeInsets.all(16), children: [
      FutureBuilder<Map<String, Object?>?>(future: businessFuture, builder: (context, snap) {
        final b = snap.data;
        return Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xff00a98f), Color(0xff0ea5e9)]), borderRadius: BorderRadius.circular(28)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(b?['name']?.toString() ?? 'دفتر حساب', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(b?['category']?.toString() ?? '', style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 18),
          FutureBuilder<Map<String, int>>(future: statsFuture, builder: (context, statsSnap) {
            final s = statsSnap.data ?? {};
            return Row(children: [Expanded(child: HeaderStat(label: 'کل بدهی', value: money(s['totalDebt'] ?? 0))), const SizedBox(width: 10), Expanded(child: HeaderStat(label: 'مشتری‌ها', value: fa('${s['customers'] ?? 0} نفر')))]);
          }),
        ]));
      }),
      const SizedBox(height: 14),
      FutureBuilder<Map<String, int>>(future: statsFuture, builder: (context, snap) {
        final s = snap.data ?? {};
        return GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.05, children: [
          MiniStat(icon: Icons.warning_amber_rounded, label: 'بدهکار', value: fa('${s['debtors'] ?? 0}')),
          MiniStat(icon: Icons.check_circle_outline, label: 'تسویه', value: fa('${s['settled'] ?? 0}')),
          MiniStat(icon: Icons.savings_outlined, label: 'بستانکار', value: fa('${s['credit'] ?? 0}')),
        ]);
      }),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: () async { final ok = await showCustomerDialog(context); if (ok == true) reload(); }, icon: const Icon(Icons.person_add_alt), label: const Text('افزودن مشتری جدید')),
    ])));
  }
}

class HeaderStat extends StatelessWidget {
  final String label, value;
  const HeaderStat({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 8), Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]));
}

class MiniStat extends StatelessWidget {
  final IconData icon;
  final String label, value;
  const MiniStat({super.key, required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => ProCard(padding: const EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8), Text(label, style: const TextStyle(fontSize: 12)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))]));
}

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});
  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  final search = TextEditingController();
  String filter = 'all';
  Future<List<Map<String, dynamic>>>? future;
  @override
  void initState() { super.initState(); reload(); }
  void reload() { future = load(); setState(() {}); }
  Future<List<Map<String, dynamic>>> load() async {
    final rows = await AppDb.customers(query: search.text);
    final out = <Map<String, dynamic>>[];
    for (final c in rows) {
      final balance = await AppDb.balance(c['id'] as int);
      if (filter == 'debt' && balance <= 0) continue;
      if (filter == 'settled' && balance != 0) continue;
      if (filter == 'credit' && balance >= 0) continue;
      out.add({...c, 'balance': balance});
    }
    out.sort((a, b) => (b['balance'] as int).compareTo(a['balance'] as int));
    return out;
  }
  @override
  Widget build(BuildContext context) {
    return ProScaffold(title: 'مشتری‌ها', action: IconButton(onPressed: () async { final ok = await showCustomerDialog(context); if (ok == true) reload(); }, icon: const Icon(Icons.add)), child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 4), child: TextField(controller: search, onChanged: (_) => reload(), decoration: InputDecoration(hintText: 'جستجو...', prefixIcon: const Icon(Icons.search), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)))),
      SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
        FilterChip(label: const Text('همه'), selected: filter == 'all', onSelected: (_) => setFilter('all')), const SizedBox(width: 8),
        FilterChip(label: const Text('بدهکار'), selected: filter == 'debt', onSelected: (_) => setFilter('debt')), const SizedBox(width: 8),
        FilterChip(label: const Text('تسویه'), selected: filter == 'settled', onSelected: (_) => setFilter('settled')), const SizedBox(width: 8),
        FilterChip(label: const Text('بستانکار'), selected: filter == 'credit', onSelected: (_) => setFilter('credit')),
      ])),
      Expanded(child: FutureBuilder<List<Map<String, dynamic>>>(future: future, builder: (context, snap) {
        final list = snap.data ?? [];
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (list.isEmpty) return EmptyState(icon: Icons.people_outline, title: 'هنوز مشتری ثبت نشده', subtitle: 'برای شروع مشتری اضافه کن.', button: 'افزودن مشتری', onTap: () async { final ok = await showCustomerDialog(context); if (ok == true) reload(); });
        return ListView.separated(padding: const EdgeInsets.all(16), itemCount: list.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, i) {
          final c = list[i]; final balance = c['balance'] as int;
          return CustomerCard(customer: c, balance: balance, onOpen: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailsPage(customerId: c['id'] as int))); reload(); }, onDebt: () async { final ok = await showTransactionDialog(context, customerId: c['id'] as int, type: 'debt'); if (ok == true) reload(); }, onPay: () async { final ok = await showTransactionDialog(context, customerId: c['id'] as int, type: 'payment'); if (ok == true) reload(); });
        });
      })),
    ]));
  }
  void setFilter(String value) { filter = value; reload(); }
}

class CustomerCard extends StatelessWidget {
  final Map<String, dynamic> customer; final int balance; final VoidCallback onOpen, onDebt, onPay;
  const CustomerCard({super.key, required this.customer, required this.balance, required this.onOpen, required this.onDebt, required this.onPay});
  @override
  Widget build(BuildContext context) {
    final name = customer['name'].toString(); final phone = customer['phone']?.toString() ?? '';
    final color = balance > 0 ? Colors.orange : balance < 0 ? Colors.blue : Colors.green;
    return InkWell(borderRadius: BorderRadius.circular(22), onTap: onOpen, child: ProCard(child: Column(children: [
      Row(children: [CircleAvatar(backgroundColor: color.withOpacity(.13), child: Text(name.isEmpty ? 'م' : name[0], style: TextStyle(color: color, fontWeight: FontWeight.w900))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), if (phone.isNotEmpty) Text(fa(phone), style: const TextStyle(fontSize: 12, color: Colors.grey))])), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: color.withOpacity(.11), borderRadius: BorderRadius.circular(14)), child: Text(signedMoney(balance), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)))]),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: FilledButton.tonal(onPressed: onDebt, child: const Text('+ بدهی'))), const SizedBox(width: 8), Expanded(child: FilledButton.tonal(onPressed: onPay, child: const Text('پرداخت'))), const SizedBox(width: 8), Expanded(child: OutlinedButton(onPressed: onOpen, child: const Text('جزئیات')))]),
    ])));
  }
}

class CustomerDetailsPage extends StatefulWidget {
  final int customerId;
  const CustomerDetailsPage({super.key, required this.customerId});
  @override
  State<CustomerDetailsPage> createState() => _CustomerDetailsPageState();
}

class _CustomerDetailsPageState extends State<CustomerDetailsPage> {
  Map<String, Object?>? customer; int balance = 0; List<Map<String, Object?>> txs = [];
  @override
  void initState() { super.initState(); reload(); }
  Future<void> reload() async { customer = await AppDb.customer(widget.customerId); balance = await AppDb.balance(widget.customerId); txs = await AppDb.transactions(widget.customerId); setState(() {}); }
  @override
  Widget build(BuildContext context) {
    final c = customer; if (c == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return ProScaffold(title: c['name'].toString(), action: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { final ok = await confirm(context, 'حذف مشتری', 'تمام اطلاعات حذف شود؟'); if (ok) { await AppDb.deleteCustomer(widget.customerId); if (context.mounted) Navigator.pop(context); } }), child: ListView(padding: const EdgeInsets.all(16), children: [
      ProCard(child: Column(children: [InfoLine(label: 'مانده حساب', value: signedMoney(balance)), InfoLine(label: 'موبایل', value: c['phone']?.toString().isEmpty == false ? fa(c['phone'].toString()) : '-'), InfoLine(label: 'یادداشت', value: c['note']?.toString().isEmpty == false ? c['note'].toString() : '-')])),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: FilledButton(onPressed: () => addTx('debt'), child: const Text('+ بدهی'))), const SizedBox(width: 8), Expanded(child: FilledButton.tonal(onPressed: () => addTx('payment'), child: const Text('پرداخت'))), const SizedBox(width: 8), Expanded(child: FilledButton.tonal(onPressed: () => addTx('discount'), child: const Text('تخفیف')))]),
      const SizedBox(height: 8),
      Row(children: [Expanded(child: OutlinedButton.icon(onPressed: sendWhatsApp, icon: const Icon(Icons.chat), label: const Text('واتساپ'))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: exportPdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('PDF')))]),
      const SizedBox(height: 8),
      Row(children: [Expanded(child: OutlinedButton.icon(onPressed: exportWord, icon: const Icon(Icons.description), label: const Text('Word'))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: exportCsv, icon: const Icon(Icons.table_chart), label: const Text('Excel')))]),
      const SizedBox(height: 18),
      Text('ریز تراکنش‌ها', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      if (txs.isEmpty) const EmptyState(icon: Icons.receipt_long, title: 'تراکنشی ثبت نشده', subtitle: 'بدهی یا پرداخت اضافه کن.') else ...txs.map((t) => TransactionTile(t: t, onDelete: () async { final ok = await confirm(context, 'حذف تراکنش', 'این تراکنش حذف شود؟'); if (ok) { await AppDb.deleteTransaction(t['id'] as int); reload(); } })),
    ]));
  }
  Future<void> addTx(String type) async { final ok = await showTransactionDialog(context, customerId: widget.customerId, type: type); if (ok == true) reload(); }
  String invoiceText() => 'صورتحساب مشتری\nنام مشتری: ${customer!['name']}\nمانده حساب: ${signedMoney(balance)}\nتاریخ: ${isoToJalali(isoToday())}\n\n${txs.map((t) => '${typeLabel(t['type'].toString())} - ${money(t['amount'] as int)} - ${isoToJalali(t['dateIso'].toString())}').join('\n')}';
  Future<void> sendWhatsApp() async {
    final phone = customer?['phone']?.toString() ?? ''; final text = Uri.encodeComponent(invoiceText());
    final url = phone.trim().isEmpty ? 'https://wa.me/?text=$text' : 'https://wa.me/${enDigits(phone).replaceAll(RegExp(r'[^0-9]'), '')}?text=$text';
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) await Share.share(invoiceText());
  }
  Future<File> writeFile(String name, String content) async { final dir = await getTemporaryDirectory(); final file = File(p.join(dir.path, name)); return file.writeAsString(content, encoding: utf8); }
  Future<void> exportCsv() async { final c = customer!; final rows = ['\ufeffنوع,مبلغ,تاریخ,یادآوری,توضیح', ...txs.map((t) => '${typeLabel(t['type'].toString())},${t['amount']},${isoToJalali(t['dateIso'].toString())},${isoToJalali(t['reminderIso']?.toString())},${(t['note'] ?? '').toString().replaceAll(',', ' ')}')]; final file = await writeFile('hesab-${c['name']}.csv', rows.join('\n')); await Share.shareXFiles([XFile(file.path)], text: 'خروجی Excel مشتری'); }
  Future<void> exportWord() async { final c = customer!; final html = '<html dir="rtl"><meta charset="utf-8"><body><h2>صورتحساب مشتری</h2><p>نام: ${c['name']}</p><p>مانده حساب: ${signedMoney(balance)}</p><table border="1" cellspacing="0" cellpadding="8"><tr><th>نوع</th><th>مبلغ</th><th>تاریخ</th><th>توضیح</th></tr>${txs.map((t) => '<tr><td>${typeLabel(t['type'].toString())}</td><td>${money(t['amount'] as int)}</td><td>${isoToJalali(t['dateIso'].toString())}</td><td>${t['note'] ?? ''}</td></tr>').join()}</table></body></html>'; final file = await writeFile('hesab-${c['name']}.doc', html); await Share.shareXFiles([XFile(file.path)], text: 'خروجی Word مشتری'); }
  Future<void> exportPdf() async {
    final c = customer!; final font = await PdfGoogleFonts.notoNaskhArabicRegular(); final doc = pw.Document();
    doc.addPage(pw.MultiPage(theme: pw.ThemeData.withFont(base: font), textDirection: pw.TextDirection.rtl, build: (context) => [
      pw.Text('صورتحساب مشتری', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 12), pw.Text('نام: ${c['name']}'), pw.Text('مانده حساب: ${signedMoney(balance)}'), pw.SizedBox(height: 12),
      pw.TableHelper.fromTextArray(headers: ['نوع', 'مبلغ', 'تاریخ', 'توضیح'], data: txs.map((t) => [typeLabel(t['type'].toString()), money(t['amount'] as int), isoToJalali(t['dateIso'].toString()), t['note']?.toString() ?? '']).toList()),
    ]));
    await Printing.sharePdf(bytes: await doc.save(), filename: 'hesab-${c['name']}.pdf');
  }
}

class TransactionTile extends StatelessWidget {
  final Map<String, Object?> t; final VoidCallback onDelete;
  const TransactionTile({super.key, required this.t, required this.onDelete});
  @override
  Widget build(BuildContext context) { final type = t['type'].toString(); final color = type == 'debt' ? Colors.orange : type == 'payment' ? Colors.green : Colors.blue; return Padding(padding: const EdgeInsets.only(bottom: 8), child: ProCard(padding: const EdgeInsets.all(12), child: Row(children: [CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(typeIcon(type), color: color)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${typeLabel(type)} - ${money(t['amount'] as int)}', style: const TextStyle(fontWeight: FontWeight.w900)), Text('تاریخ: ${isoToJalali(t['dateIso'].toString())}', style: const TextStyle(fontSize: 12, color: Colors.grey)), if ((t['reminderIso']?.toString() ?? '').isNotEmpty) Text('یادآوری: ${isoToJalali(t['reminderIso'].toString())}', style: const TextStyle(fontSize: 12, color: Colors.orange)), if ((t['note']?.toString() ?? '').isNotEmpty) Text(t['note'].toString(), style: const TextStyle(fontSize: 12))])), IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline))]))); }
}

class RemindersPage extends StatefulWidget { const RemindersPage({super.key}); @override State<RemindersPage> createState() => _RemindersPageState(); }
class _RemindersPageState extends State<RemindersPage> {
  Future<List<Map<String, Object?>>>? future;
  @override void initState() { super.initState(); future = AppDb.remindersDue(); }
  @override Widget build(BuildContext context) => ProScaffold(title: 'یادآوری‌ها', child: FutureBuilder<List<Map<String, Object?>>>(future: future, builder: (context, snap) { final list = snap.data ?? []; if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator()); if (list.isEmpty) return const EmptyState(icon: Icons.notifications_none, title: 'یادآوری فعالی نیست', subtitle: 'برای بدهی‌ها تاریخ یادآوری بگذار.'); return ListView.separated(padding: const EdgeInsets.all(16), itemCount: list.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, i) { final r = list[i]; return ProCard(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.notifications_active)), title: Text(r['customerName'].toString(), style: const TextStyle(fontWeight: FontWeight.w900)), subtitle: Text('مبلغ: ${money(r['amount'] as int)}\nیادآوری: ${isoToJalali(r['reminderIso'].toString())}'), isThreeLine: true)); }); }));
}

class ReportsPage extends StatefulWidget { ReportsPage({super.key}); @override State<ReportsPage> createState() => _ReportsPageState(); }
class _ReportsPageState extends State<ReportsPage> {
  Future<Map<String, int>>? statsFuture;
  @override void initState() { super.initState(); statsFuture = AppDb.stats(); }
  @override Widget build(BuildContext context) => ProScaffold(title: 'گزارش و خروجی', child: FutureBuilder<Map<String, int>>(future: statsFuture, builder: (context, snap) { final s = snap.data ?? {}; return ListView(padding: const EdgeInsets.all(16), children: [ProCard(child: Column(children: [InfoLine(label: 'کل مشتری‌ها', value: fa('${s['customers'] ?? 0} نفر')), InfoLine(label: 'کل بدهی‌ها', value: money(s['totalDebt'] ?? 0)), InfoLine(label: 'بدهکار', value: fa('${s['debtors'] ?? 0} نفر')), InfoLine(label: 'تسویه', value: fa('${s['settled'] ?? 0} نفر')), InfoLine(label: 'بستانکار', value: fa('${s['credit'] ?? 0} نفر'))])), const SizedBox(height: 12), FilledButton.icon(onPressed: exportJson, icon: const Icon(Icons.backup_outlined), label: const Text('بکاپ JSON')), const SizedBox(height: 8), OutlinedButton.icon(onPressed: exportCsv, icon: const Icon(Icons.table_chart), label: const Text('خروجی Excel / CSV کل')), const SizedBox(height: 8), OutlinedButton.icon(onPressed: exportWord, icon: const Icon(Icons.description), label: const Text('خروجی Word کل'))]); }));
  Future<File> writeFile(String name, String content) async { final dir = await getTemporaryDirectory(); final file = File(p.join(dir.path, name)); return file.writeAsString(content, encoding: utf8); }
  Future<void> exportJson() async { final data = await AppDb.backupData(); final file = await writeFile('backup-customer-account.json', const JsonEncoder.withIndent('  ').convert(data)); await Share.shareXFiles([XFile(file.path)], text: 'بکاپ دفتر حساب مشتریان'); }
  Future<void> exportCsv() async { final customers = await AppDb.customers(); final rows = ['\ufeffنام,موبایل,مانده حساب,توضیح']; for (final c in customers) { final b = await AppDb.balance(c['id'] as int); rows.add('${c['name']},${c['phone'] ?? ''},$b,${(c['note'] ?? '').toString().replaceAll(',', ' ')}'); } final file = await writeFile('customers-report.csv', rows.join('\n')); await Share.shareXFiles([XFile(file.path)], text: 'گزارش Excel دفتر حساب'); }
  Future<void> exportWord() async { final customers = await AppDb.customers(); final rows = <String>[]; for (final c in customers) { final b = await AppDb.balance(c['id'] as int); rows.add('<tr><td>${c['name']}</td><td>${c['phone'] ?? ''}</td><td>${signedMoney(b)}</td><td>${c['note'] ?? ''}</td></tr>'); } final html = '<html dir="rtl"><meta charset="utf-8"><body><h2>گزارش مشتری‌ها</h2><table border="1" cellpadding="8"><tr><th>نام</th><th>موبایل</th><th>مانده</th><th>یادداشت</th></tr>${rows.join()}</table></body></html>'; final file = await writeFile('customers-report.doc', html); await Share.shareXFiles([XFile(file.path)], text: 'گزارش Word دفتر حساب'); }
}

class SettingsPage extends StatefulWidget { final VoidCallback onLogout; const SettingsPage({super.key, required this.onLogout}); @override State<SettingsPage> createState() => _SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage> {
  final name = TextEditingController(); final category = TextEditingController(); final phone = TextEditingController(); final pin = TextEditingController(); int? businessId;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { final b = await AppDb.activeBusiness(); businessId = b?['id'] as int?; name.text = b?['name']?.toString() ?? ''; category.text = b?['category']?.toString() ?? ''; phone.text = b?['phone']?.toString() ?? ''; setState(() {}); }
  @override Widget build(BuildContext context) => ProScaffold(title: 'تنظیمات', child: ListView(padding: const EdgeInsets.all(16), children: [ProCard(child: Column(children: [ProField(controller: name, label: 'نام کسب‌وکار'), const SizedBox(height: 10), ProField(controller: category, label: 'دسته شغلی'), const SizedBox(height: 10), ProField(controller: phone, label: 'شماره تماس کسب‌وکار'), const SizedBox(height: 12), FilledButton(onPressed: saveBusiness, child: const Text('ذخیره اطلاعات کسب‌وکار'))])), const SizedBox(height: 12), ProCard(child: Column(children: [ProField(controller: pin, label: 'رمز جدید ۴ رقمی', obscure: true, keyboardType: TextInputType.number), const SizedBox(height: 12), OutlinedButton(onPressed: savePin, child: const Text('تغییر رمز'))])), const SizedBox(height: 12), FilledButton.tonalIcon(onPressed: widget.onLogout, icon: const Icon(Icons.lock_outline), label: const Text('قفل کردن و خروج'))]));
  Future<void> saveBusiness() async { if (businessId == null) return; await AppDb.updateBusiness(businessId!, name.text.trim(), category.text.trim(), phone.text.trim()); toast(context, 'اطلاعات ذخیره شد'); }
  Future<void> savePin() async { final p = enDigits(pin.text.trim()); if (!RegExp(r'^\d{4}$').hasMatch(p)) { toast(context, 'رمز باید ۴ رقم باشد'); return; } await AppDb.setSetting('pin', p); pin.clear(); toast(context, 'رمز تغییر کرد'); }
}

Future<bool?> showCustomerDialog(BuildContext context, {Map<String, Object?>? customer}) {
  final name = TextEditingController(text: customer?['name']?.toString() ?? ''); final phone = TextEditingController(text: customer?['phone']?.toString() ?? ''); final note = TextEditingController(text: customer?['note']?.toString() ?? '');
  return showDialog<bool>(context: context, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: Text(customer == null ? 'افزودن مشتری' : 'ویرایش مشتری'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [ProField(controller: name, label: 'نام مشتری'), const SizedBox(height: 10), ProField(controller: phone, label: 'موبایل', keyboardType: TextInputType.phone), const SizedBox(height: 10), ProField(controller: note, label: 'یادداشت')])), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')), FilledButton(onPressed: () async { if (name.text.trim().isEmpty) return; if (customer == null) { await AppDb.insertCustomer(name.text.trim(), phone.text.trim(), note.text.trim()); } else { await AppDb.updateCustomer(customer['id'] as int, name.text.trim(), phone.text.trim(), note.text.trim()); } if (context.mounted) Navigator.pop(context, true); }, child: const Text('ذخیره'))])));
}

Future<bool?> showTransactionDialog(BuildContext context, {required int customerId, required String type}) {
  final amount = TextEditingController(); final date = TextEditingController(text: todayJalali()); final reminder = TextEditingController(); final note = TextEditingController(); var selectedType = type;
  return showDialog<bool>(context: context, builder: (context) => StatefulBuilder(builder: (context, setState) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: const Text('ثبت تراکنش'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [DropdownButtonFormField<String>(value: selectedType, decoration: const InputDecoration(labelText: 'نوع تراکنش'), items: const [DropdownMenuItem(value: 'debt', child: Text('بدهی')), DropdownMenuItem(value: 'payment', child: Text('پرداخت')), DropdownMenuItem(value: 'discount', child: Text('تخفیف / اصلاح'))], onChanged: (v) => setState(() => selectedType = v ?? selectedType)), const SizedBox(height: 10), ProField(controller: amount, label: 'مبلغ به تومان', keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: date, label: 'تاریخ شمسی مثل ۱۴۰۳/۰۳/۲۳', keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: reminder, label: 'یادآوری شمسی اختیاری', keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: note, label: 'توضیح')])), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')), FilledButton(onPressed: () async { final a = cleanAmount(amount.text); final iso = jalaliToIso(date.text); final rem = reminder.text.trim().isEmpty ? null : jalaliToIso(reminder.text); if (a <= 0 || iso == null || (reminder.text.trim().isNotEmpty && rem == null)) {
                  toast(context, 'مبلغ یا تاریخ درست نیست');
                  return;
                }
                await AppDb.insertTransaction(customerId: customerId, type: selectedType, amount: a, dateIso: iso, reminderIso: rem, note: note.text.trim());
                if (context.mounted) Navigator.pop(context, true);
              }, child: const Text('ثبت'))]))));
}

}

String typeLabel(String type) {
  if (type == 'debt') return 'بدهی';
  if (type == 'payment') return 'پرداخت';
  return 'تخفیف / اصلاح';
}

IconData typeIcon(String type) {
  if (type == 'debt') return Icons.trending_up;
  if (type == 'payment') return Icons.payments_outlined;
  return Icons.discount_outlined;
}

Future<bool> confirm(BuildContext context, String title, String message) async {
  return await showDialog<bool>(context: context, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: Text(title), content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('نه')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('بله'))]))) ?? false;
}

class ProBackground extends StatelessWidget {
  final Widget child;
  const ProBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xffe0f7f4), Color(0xfff4fbfb), Colors.white])), child: child);
}

class ProScaffold extends StatelessWidget {
  final String title; final Widget child; final Widget? action;
  const ProScaffold({super.key, required this.title, required this.child, this.action});
  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), actions: action == null ? null : [action!]), body: child));
}

class ProCard extends StatelessWidget {
  final Widget child; final EdgeInsetsGeometry padding;
  const ProCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: Padding(padding: padding, child: child));
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Container(width: 76, height: 76, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xff00a98f), Color(0xff0ea5e9)]), borderRadius: BorderRadius.circular(26)), child: const Icon(Icons.account_balance_wallet, color: Colors.white, size: 38)));
}

class ProField extends StatelessWidget {
  final TextEditingController controller; final String label; final bool obscure; final TextInputType? keyboardType;
  const ProField({super.key, required this.controller, required this.label, this.obscure = false, this.keyboardType});
  @override
  Widget build(BuildContext context) => TextField(controller: controller, obscureText: obscure, keyboardType: keyboardType, decoration: InputDecoration(labelText: label, filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)));
}

class InfoLine extends StatelessWidget {
  final String label, value;
  const InfoLine({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Text(label, style: const TextStyle(color: Colors.grey)), const Spacer(), Flexible(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w800)))]));
}

class EmptyState extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final String? button; final VoidCallback? onTap;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle, this.button, this.onTap});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 14), Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 8), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)), if (button != null) ...[const SizedBox(height: 16), FilledButton(onPressed: onTap, child: Text(button!))]])));
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
