import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MoneyApp());
}

class MoneyApp extends StatelessWidget {
  const MoneyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xff087d69);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دفتر حساب مشتریان',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xffeef8f6),
        appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Color(0xffeef8f6), surfaceTintColor: Colors.transparent, elevation: 0),
        cardTheme: CardThemeData(elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xfff4faf8), border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)),
      ),
      darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark)),
      home: const AuthGate(),
    );
  }
}

String fa(String input) {
  const en = ['0','1','2','3','4','5','6','7','8','9'];
  const pr = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  var out = input;
  for (var i = 0; i < en.length; i++) { out = out.replaceAll(en[i], pr[i]); }
  return out;
}

String enDigits(String input) {
  const pr = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  const ar = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
  const en = ['0','1','2','3','4','5','6','7','8','9'];
  var out = input;
  for (var i = 0; i < en.length; i++) { out = out.replaceAll(pr[i], en[i]).replaceAll(ar[i], en[i]); }
  return out;
}

String money(int value) {
  final s = value.abs().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',');
  return '${fa(s)} تومان';
}

String signedMoney(int value) {
  if (value == 0) return 'تسویه';
  if (value < 0) return 'بستانکار: ${money(value)}';
  return money(value);
}

int cleanAmount(String value) => int.tryParse(enDigits(value).replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
int _div(int a, int b) => a ~/ b;
int _mod(int a, int b) => a - (a ~/ b) * b;

int _g2d(int gy, int gm, int gd) {
  var d = _div((gy + _div(gm - 8, 6) + 100100) * 1461, 4) + _div(153 * _mod(gm + 9, 12) + 2, 5) + gd - 34840408;
  d = d - _div(_div(gy + 100100 + _div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

({int gy, int gm, int gd}) _d2g(int jdn) {
  var j = 4 * jdn + 139361631;
  j = j + _div(_div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  final i = _div(_mod(j, 1461), 4) * 5 + 308;
  final gd = _div(_mod(i, 153), 5) + 1;
  final gm = _mod(_div(i, 153), 12) + 1;
  final gy = _div(j, 1461) - 100100 + _div(8 - gm, 6);
  return (gy: gy, gm: gm, gd: gd);
}

({int leap, int gy, int march}) _jalCal(int jy) {
  final breaks = [-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178];
  var gy = jy + 621;
  var leapJ = -14;
  var jp = breaks[0];
  var jump = 0;
  for (var i = 1; i < breaks.length; i++) {
    final jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + _div(jump, 33) * 8 + _div(_mod(jump, 33), 4);
    jp = jm;
  }
  var n = jy - jp;
  leapJ = leapJ + _div(n, 33) * 8 + _div(_mod(n, 33) + 3, 4);
  if (_mod(jump, 33) == 4 && jump - n == 4) leapJ += 1;
  final leapG = _div(gy, 4) - _div((_div(gy, 100) + 1) * 3, 4) - 150;
  final march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + _div(jump + 4, 33) * 33;
  var leap = _mod(_mod(n + 1, 33) - 1, 4);
  if (leap == -1) leap = 4;
  return (leap: leap, gy: gy, march: march);
}

int _j2d(int jy, int jm, int jd) {
  final r = _jalCal(jy);
  return _g2d(r.gy, 3, r.march) + (jm - 1) * 31 - _div(jm, 7) * (jm - 7) + jd - 1;
}

({int jy, int jm, int jd}) _d2j(int jdn) {
  final gy = _d2g(jdn).gy;
  var jy = gy - 621;
  final r = _jalCal(jy);
  final jdn1f = _g2d(gy, 3, r.march);
  var k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) return (jy: jy, jm: 1 + _div(k, 31), jd: _mod(k, 31) + 1);
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap == 1) k += 1;
  }
  return (jy: jy, jm: 7 + _div(k, 30), jd: _mod(k, 30) + 1);
}

String pad2(int n) => n.toString().padLeft(2, '0');
String isoDate(DateTime d) => d.toIso8601String().substring(0, 10);
String todayIso() => isoDate(DateTime.now());

String isoToJalali(String? iso) {
  if (iso == null || iso.trim().isEmpty) return '-';
  final parts = iso.split('-').map((e) => int.tryParse(e) ?? 0).toList();
  if (parts.length != 3 || parts.contains(0)) return '-';
  final j = _d2j(_g2d(parts[0], parts[1], parts[2]));
  return fa('${j.jy}/${pad2(j.jm)}/${pad2(j.jd)}');
}

String todayJalali() => isoToJalali(todayIso());

String? jalaliToIso(String value) {
  final cleaned = enDigits(value.trim()).replaceAll('-', '/').replaceAll('.', '/');
  final parts = cleaned.split('/').map((e) => int.tryParse(e) ?? 0).toList();
  if (parts.length != 3 || parts.contains(0)) return null;
  final jy = parts[0], jm = parts[1], jd = parts[2];
  if (jy < 1200 || jm < 1 || jm > 12 || jd < 1 || jd > 31) return null;
  try {
    final g = _d2g(_j2d(jy, jm, jd));
    return '${g.gy}-${pad2(g.gm)}-${pad2(g.gd)}';
  } catch (_) { return null; }
}

String addDaysIso(String? baseIso, int days) {
  final now = DateTime.now();
  final base = baseIso == null || baseIso.isEmpty ? null : DateTime.tryParse(baseIso);
  final start = base != null && base.isAfter(now) ? base : now;
  return isoDate(start.add(Duration(days: days)));
}

int daysLeft(String? iso) {
  final d = iso == null || iso.isEmpty ? null : DateTime.tryParse(iso);
  if (d == null) return -9999;
  final now = DateTime.now();
  return d.difference(DateTime(now.year, now.month, now.day)).inDays;
}

void toast(BuildContext context, String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

class AppDb {
  static Database? _db;

  static Future<Database> get instance async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'customer_money_v5_jalali_pro.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
        await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, note TEXT, createdAt TEXT NOT NULL)');
        await db.execute('CREATE TABLE account_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER NOT NULL, type TEXT NOT NULL, amount INTEGER NOT NULL, dateIso TEXT NOT NULL, reminderIso TEXT, note TEXT, createdAt TEXT NOT NULL)');
        await db.execute('CREATE TABLE subscription_plans(id INTEGER PRIMARY KEY, title TEXT NOT NULL, months INTEGER NOT NULL, price INTEGER NOT NULL)');
      },
    );
    await seedIfNeeded();
    return _db!;
  }

  static Future<String?> getSettingRaw(Database db, String key) async {
    final rows = await db.query('settings', where: 'key=?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  static Future<void> setSettingRaw(Database db, String key, String value) async {
    await db.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<void> seedIfNeeded() async {
    final db = _db!;
    if (await getSettingRaw(db, 'seeded') == 'yes') return;
    await setSettingRaw(db, 'seeded', 'yes');
    await setSettingRaw(db, 'username', 'admin');
    await setSettingRaw(db, 'password', '1234');
    await setSettingRaw(db, 'adminPin', '2468');
    await setSettingRaw(db, 'businessName', 'دفتر حساب من');
    await setSettingRaw(db, 'businessCategory', 'سوپرمارکت');
    await setSettingRaw(db, 'businessPhone', '');
    await setSettingRaw(db, 'supportPhone', '');
    await setSettingRaw(db, 'paymentCard', '');
    await setSettingRaw(db, 'trialStartIso', todayIso());
    await setSettingRaw(db, 'trialEndIso', isoDate(DateTime.now().add(const Duration(days: 30))));
    await setSettingRaw(db, 'subscriptionUntilIso', '');
    await db.insert('subscription_plans', {'id': 1, 'title': 'اشتراک ۱ ماهه', 'months': 1, 'price': 59000});
    await db.insert('subscription_plans', {'id': 2, 'title': 'اشتراک ۳ ماهه', 'months': 3, 'price': 149000});
    await db.insert('subscription_plans', {'id': 3, 'title': 'اشتراک ۶ ماهه', 'months': 6, 'price': 249000});
    await db.insert('subscription_plans', {'id': 4, 'title': 'اشتراک ۱ ساله', 'months': 12, 'price': 399000});
    final c1 = await db.insert('customers', {'name': 'محمد کدخدایی', 'phone': '09153480704', 'note': 'مشتری تستی بدهکار', 'createdAt': DateTime.now().toIso8601String()});
    final c2 = await db.insert('customers', {'name': 'عبدالله احمدی', 'phone': '09120000001', 'note': 'پرداخت ناقص', 'createdAt': DateTime.now().toIso8601String()});
    final c3 = await db.insert('customers', {'name': 'سارا رضایی', 'phone': '09350000002', 'note': 'تسویه کامل', 'createdAt': DateTime.now().toIso8601String()});
    final c4 = await db.insert('customers', {'name': 'علی محمدی', 'phone': '09150000003', 'note': 'بستانکار تستی', 'createdAt': DateTime.now().toIso8601String()});
    Future<void> tx(int cid, String type, int amount, int daysAgo, {String note = '', int? remindIn}) async {
      await db.insert('account_transactions', {
        'customerId': cid,
        'type': type,
        'amount': amount,
        'dateIso': isoDate(DateTime.now().subtract(Duration(days: daysAgo))),
        'reminderIso': remindIn == null ? '' : isoDate(DateTime.now().add(Duration(days: remindIn))),
        'note': note,
        'createdAt': DateTime.now().toIso8601String(),
      });
    }
    await tx(c1, 'debt', 5000000, 2, remindIn: 1, note: 'خرید تستی عمده');
    await tx(c1, 'payment', 1500000, 1, note: 'پرداخت نقدی');
    await tx(c1, 'payment', 1000000, 0, note: 'واریز کارت');
    await tx(c2, 'debt', 2300000, 4, remindIn: 0, note: 'فروش نسیه');
    await tx(c2, 'payment', 800000, 2, note: 'پرداخت بخشی');
    await tx(c3, 'debt', 750000, 5);
    await tx(c3, 'payment', 750000, 4);
    await tx(c4, 'payment', 400000, 3, note: 'پرداخت اضافه');
  }

  static Future<String?> getSetting(String key) async => getSettingRaw(await instance, key);
  static Future<void> setSetting(String key, String value) async => setSettingRaw(await instance, key, value);

  static Future<bool> login(String username, String password) async {
    final u = await getSetting('username') ?? 'admin';
    final pass = await getSetting('password') ?? '1234';
    return username.trim() == u && enDigits(password.trim()) == pass;
  }

  static Future<List<Map<String, Object?>>> plans() async => (await instance).query('subscription_plans', orderBy: 'months ASC');
  static Future<void> updatePlanPrice(int id, int price) async => (await instance).update('subscription_plans', {'price': price}, where: 'id=?', whereArgs: [id]);

  static Future<String> accessLabel() async {
    final subEnd = await getSetting('subscriptionUntilIso');
    final trialEnd = await getSetting('trialEndIso');
    final subDays = daysLeft(subEnd);
    final trialDays = daysLeft(trialEnd);
    if (subDays >= 0) return 'اشتراک فعال تا ${isoToJalali(subEnd)}';
    if (trialDays >= 0) return 'رایگان: ${fa('$trialDays')} روز باقی‌مانده';
    return 'دوره رایگان تمام شده';
  }

  static Future<bool> hasAccess() async => daysLeft(await getSetting('subscriptionUntilIso')) >= 0 || daysLeft(await getSetting('trialEndIso')) >= 0;
  static Future<void> activateSubscription(int months) async => setSetting('subscriptionUntilIso', addDaysIso(await getSetting('subscriptionUntilIso'), months * 30));

  static Future<List<Map<String, Object?>>> customers({String query = ''}) async {
    final db = await instance;
    if (query.trim().isEmpty) return db.query('customers', orderBy: 'id DESC');
    return db.query('customers', where: 'name LIKE ? OR phone LIKE ? OR note LIKE ?', whereArgs: ['%$query%', '%$query%', '%$query%'], orderBy: 'id DESC');
  }

  static Future<int> insertCustomer(String name, String phone, String note) async => (await instance).insert('customers', {'name': name, 'phone': phone, 'note': note, 'createdAt': DateTime.now().toIso8601String()});
  static Future<void> updateCustomer(int id, String name, String phone, String note) async => (await instance).update('customers', {'name': name, 'phone': phone, 'note': note}, where: 'id=?', whereArgs: [id]);

  static Future<void> deleteCustomer(int id) async {
    final db = await instance;
    await db.delete('account_transactions', where: 'customerId=?', whereArgs: [id]);
    await db.delete('customers', where: 'id=?', whereArgs: [id]);
  }

  static Future<Map<String, Object?>?> customer(int id) async {
    final rows = await (await instance).query('customers', where: 'id=?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<List<Map<String, Object?>>> transactions(int customerId) async => (await instance).query('account_transactions', where: 'customerId=?', whereArgs: [customerId], orderBy: 'dateIso DESC, id DESC');

  static Future<void> insertTransaction({required int customerId, required String type, required int amount, required String dateIso, String? reminderIso, String note = ''}) async {
    await (await instance).insert('account_transactions', {
      'customerId': customerId,
      'type': type,
      'amount': amount,
      'dateIso': dateIso,
      'reminderIso': reminderIso ?? '',
      'note': note,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> deleteTransaction(int id) async => (await instance).delete('account_transactions', where: 'id=?', whereArgs: [id]);

  static Future<int> balance(int customerId) async {
    final txs = await transactions(customerId);
    var total = 0;
    for (final t in txs) {
      total += t['type'] == 'debt' ? t['amount'] as int : -(t['amount'] as int);
    }
    return total;
  }

  static Future<Map<String, int>> stats() async {
    final cs = await customers();
    var totalDebt = 0, debtors = 0, settled = 0, credit = 0;
    for (final c in cs) {
      final b = await balance(c['id'] as int);
      if (b > 0) { totalDebt += b; debtors++; } else if (b == 0) { settled++; } else { credit++; }
    }
    return {'customers': cs.length, 'totalDebt': totalDebt, 'debtors': debtors, 'settled': settled, 'credit': credit};
  }

  static Future<List<Map<String, dynamic>>> customerBalances() async {
    final cs = await customers();
    final out = <Map<String, dynamic>>[];
    for (final c in cs) { out.add({...c, 'balance': await balance(c['id'] as int)}); }
    out.sort((a, b) => (b['balance'] as int).compareTo(a['balance'] as int));
    return out;
  }

  static Future<List<Map<String, Object?>>> remindersDue() async {
    return (await instance).rawQuery('SELECT t.*, c.name as customerName, c.phone as customerPhone FROM account_transactions t JOIN customers c ON c.id = t.customerId WHERE t.reminderIso IS NOT NULL AND t.reminderIso != "" AND t.reminderIso <= ? ORDER BY t.reminderIso ASC', [todayIso()]);
  }

  static Future<String> fullReportText() async {
    final s = await stats();
    final rows = await customerBalances();
    final bName = await getSetting('businessName') ?? 'دفتر حساب';
    final buffer = StringBuffer();
    buffer.writeln('گزارش $bName');
    buffer.writeln('تاریخ گزارش: ${isoToJalali(todayIso())}');
    buffer.writeln('-------------------------');
    buffer.writeln('کل مشتری‌ها: ${fa('${s['customers'] ?? 0}')}');
    buffer.writeln('کل بدهی‌ها: ${money(s['totalDebt'] ?? 0)}');
    buffer.writeln('بدهکارها: ${fa('${s['debtors'] ?? 0}')}');
    buffer.writeln('تسویه‌ها: ${fa('${s['settled'] ?? 0}')}');
    buffer.writeln('بستانکارها: ${fa('${s['credit'] ?? 0}')}');
    buffer.writeln('');
    for (final c in rows) { buffer.writeln('${c['name']} | ${c['phone'] ?? '-'} | ${signedMoney(c['balance'] as int)}'); }
    return buffer.toString();
  }

  static Future<void> updateTransaction({
    required int id,
    required String type,
    required int amount,
    required String dateIso,
    String? reminderIso,
    String note = '',
  }) async {
    final db = await instance;
    await db.update(
      'account_transactions',
      {
        'type': type,
        'amount': amount,
        'dateIso': dateIso,
        'reminderIso': reminderIso ?? '',
        'note': note,
      },
      where: 'id=?',
      whereArgs: [id],
    );
  }

  static Future<String> backupJson() async {
    final db = await instance;
    final data = {
      'app': 'customer_account_money_v6_pro',
      'backupVersion': 1,
      'createdAt': DateTime.now().toIso8601String(),
      'settings': await db.query('settings'),
      'customers': await db.query('customers'),
      'transactions': await db.query('account_transactions'),
      'subscriptionPlans': await db.query('subscription_plans'),
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  static Future<void> restoreJson(String input) async {
    final data = jsonDecode(input) as Map<String, dynamic>;
    final db = await instance;
    final settings = (data['settings'] as List? ?? []).cast<dynamic>();
    final customers = (data['customers'] as List? ?? []).cast<dynamic>();
    final transactions = (data['transactions'] as List? ?? []).cast<dynamic>();
    final plans = (data['subscriptionPlans'] as List? ?? []).cast<dynamic>();
    await db.transaction((txn) async {
      await txn.delete('settings');
      await txn.delete('customers');
      await txn.delete('account_transactions');
      await txn.delete('subscription_plans');
      for (final row in settings) { await txn.insert('settings', Map<String, Object?>.from(row as Map), conflictAlgorithm: ConflictAlgorithm.replace); }
      for (final row in customers) { await txn.insert('customers', Map<String, Object?>.from(row as Map), conflictAlgorithm: ConflictAlgorithm.replace); }
      for (final row in transactions) { await txn.insert('account_transactions', Map<String, Object?>.from(row as Map), conflictAlgorithm: ConflictAlgorithm.replace); }
      for (final row in plans) { await txn.insert('subscription_plans', Map<String, Object?>.from(row as Map), conflictAlgorithm: ConflictAlgorithm.replace); }
    });
  }
}

Future<bool> ensureActive(BuildContext context) async {
  final active = await AppDb.hasAccess();
  if (active) return true;
  if (!context.mounted) return false;
  await showDialog<void>(
    context: context,
    builder: (context) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('نیاز به اشتراک'),
        content: const Text('مشاهده اطلاعات آزاد است، اما ثبت، ویرایش، حذف و خروجی گرفتن بعد از پایان دوره رایگان نیاز به اشتراک دارد.'),
        actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('متوجه شدم'))],
      ),
    ),
  );
  return false;
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  bool loggedIn = false;
  @override
  void initState() { super.initState(); boot(); }
  Future<void> boot() async { await AppDb.instance; setState(() => loading = false); }
  @override
  Widget build(BuildContext context) {
    if (loading) return const Directionality(textDirection: TextDirection.rtl, child: Scaffold(body: Center(child: CircularProgressIndicator())));
    if (!loggedIn) return LoginScreen(onLogin: () => setState(() => loggedIn = true));
    return AppShell(onLogout: () => setState(() => loggedIn = false));
  }
}

class LoginScreen extends StatefulWidget {
  final VoidCallback onLogin;
  const LoginScreen({super.key, required this.onLogin});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController(text: 'admin');
  final password = TextEditingController(text: '1234');
  bool hide = true;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: ProBackground(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const AppLogo(),
                  const SizedBox(height: 20),
                  Text('دفتر حساب مشتریان', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  const Text('ورود به حساب کاربری', style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 24),
                  ProCard(
                    child: Column(
                      children: [
                        ProField(controller: username, label: 'نام کاربری', icon: Icons.person_outline),
                        const SizedBox(height: 12),
                        TextField(
                          controller: password,
                          obscureText: hide,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'رمز عبور',
                            prefixIcon: const Icon(Icons.lock_outline),
                            suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => setState(() => hide = !hide)),
                          ),
                        ),
                        const SizedBox(height: 18),
                        SizedBox(width: double.infinity, child: FilledButton(onPressed: login, child: const Text('ورود'))),
                        const SizedBox(height: 10),
                        const Text('ورود تستی: admin / 1234', style: TextStyle(fontSize: 12, color: Colors.grey)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> login() async {
    if (await AppDb.login(username.text, password.text)) { widget.onLogin(); } else { toast(context, 'نام کاربری یا رمز اشتباه است'); }
  }
}

class AppShell extends StatefulWidget {
  final VoidCallback onLogout;
  const AppShell({super.key, required this.onLogout});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onRefresh: () => setState(() {})),
      CustomersPage(),
      const RemindersPage(),
      ReportsPage(),
      SubscriptionPage(onChanged: () => setState(() {})),
      SettingsPage(onLogout: widget.onLogout),
    ];
    return FutureBuilder<bool>(
      future: AppDb.hasAccess(),
      builder: (context, snap) {
        final hasAccess = snap.data ?? true;
        final body = pages[index];
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            body: body,
            bottomNavigationBar: NavigationBar(
              selectedIndex: index,
              onDestinationSelected: (i) => setState(() => index = i),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'خانه'),
                NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'مشتری'),
                NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'یادآوری'),
                NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'گزارش'),
                NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'اشتراک'),
                NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
              ],
            ),
          ),
        );
      },
    );
  }
}

class HomePage extends StatefulWidget {
  final VoidCallback onRefresh;
  const HomePage({super.key, required this.onRefresh});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Future<Map<String, int>>? statsFuture;
  Future<String>? accessFuture;
  Future<String?>? businessFuture;
  @override
  void initState() { super.initState(); reload(); }
  void reload() { statsFuture = AppDb.stats(); accessFuture = AppDb.accessLabel(); businessFuture = AppDb.getSetting('businessName'); setState(() {}); }
  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'خانه',
      child: RefreshIndicator(
        onRefresh: () async => reload(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            FutureBuilder<String?>(
              future: businessFuture,
              builder: (context, snap) => DashboardHero(title: snap.data ?? 'دفتر حساب من', accessFuture: accessFuture, statsFuture: statsFuture),
            ),
            const SizedBox(height: 14),
            FutureBuilder<Map<String, int>>(
              future: statsFuture,
              builder: (context, snap) {
                final s = snap.data ?? {};
                return GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.05, children: [
                  MiniStat(icon: Icons.groups_2_outlined, label: 'مشتری', value: fa('${s['customers'] ?? 0}')),
                  MiniStat(icon: Icons.warning_amber_rounded, label: 'بدهکار', value: fa('${s['debtors'] ?? 0}')),
                  MiniStat(icon: Icons.check_circle_outline, label: 'تسویه', value: fa('${s['settled'] ?? 0}')),
                ]);
              },
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: addCustomer, icon: const Icon(Icons.person_add_alt), label: const Text('مشتری جدید'))),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(onPressed: copyReport, icon: const Icon(Icons.copy), label: const Text('کپی گزارش'))),
            ]),
          ],
        ),
      ),
    );
  }
  Future<void> addCustomer() async { if (!await ensureActive(context)) return; final ok = await showCustomerDialog(context); if (ok == true) { reload(); widget.onRefresh(); } }
  Future<void> copyReport() async { if (!await ensureActive(context)) return; await Clipboard.setData(ClipboardData(text: await AppDb.fullReportText())); if (mounted) toast(context, 'گزارش کپی شد'); }
}

class DashboardHero extends StatelessWidget {
  final String title;
  final Future<String>? accessFuture;
  final Future<Map<String, int>>? statsFuture;
  const DashboardHero({super.key, required this.title, required this.accessFuture, required this.statsFuture});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xff087d69), Color(0xff0ea5e9)]), borderRadius: BorderRadius.circular(30), boxShadow: [BoxShadow(color: const Color(0xff087d69).withOpacity(.16), blurRadius: 28, offset: const Offset(0, 14))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      FutureBuilder<String>(future: accessFuture, builder: (context, snap) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(16)), child: Row(children: [const Icon(Icons.workspace_premium, color: Colors.white, size: 18), const SizedBox(width: 8), Expanded(child: Text(snap.data ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)))]))),
      const SizedBox(height: 18),
      FutureBuilder<Map<String, int>>(future: statsFuture, builder: (context, snap) { final s = snap.data ?? {}; return Row(children: [Expanded(child: HeaderStat(label: 'کل بدهی', value: money(s['totalDebt'] ?? 0))), const SizedBox(width: 10), Expanded(child: HeaderStat(label: 'بستانکار', value: fa('${s['credit'] ?? 0} نفر')))]); }),
    ]),
  );
}

class HeaderStat extends StatelessWidget {
  final String label, value;
  const HeaderStat({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 8), Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]));
}

class MiniStat extends StatelessWidget {
  final IconData icon; final String label, value;
  const MiniStat({super.key, required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => ProCard(padding: const EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8), Text(label, style: const TextStyle(fontSize: 12)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))]));
}

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});
  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  final search = TextEditingController();
  String filter = 'all';
  Future<List<Map<String, dynamic>>>? future;
  @override
  void initState() { super.initState(); reload(); }
  void reload() { future = load(); setState(() {}); }
  Future<List<Map<String, dynamic>>> load() async {
    final rows = await AppDb.customers(query: search.text);
    final out = <Map<String, dynamic>>[];
    for (final c in rows) {
      final b = await AppDb.balance(c['id'] as int);
      if (filter == 'debt' && b <= 0) continue;
      if (filter == 'settled' && b != 0) continue;
      if (filter == 'credit' && b >= 0) continue;
      out.add({...c, 'balance': b});
    }
    out.sort((a, b) => (b['balance'] as int).compareTo(a['balance'] as int));
    return out;
  }
  @override
  Widget build(BuildContext context) => ProScaffold(
    title: 'مشتری‌ها',
    action: IconButton(onPressed: add, icon: const Icon(Icons.add)),
    child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 4), child: TextField(controller: search, onChanged: (_) => reload(), decoration: const InputDecoration(hintText: 'جستجوی مشتری...', prefixIcon: Icon(Icons.search)))),
      SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [chip('all', 'همه'), const SizedBox(width: 8), chip('debt', 'بدهکار'), const SizedBox(width: 8), chip('settled', 'تسویه'), const SizedBox(width: 8), chip('credit', 'بستانکار')])),
      Expanded(child: FutureBuilder<List<Map<String, dynamic>>>(future: future, builder: (context, snap) {
        final list = snap.data ?? [];
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (list.isEmpty) return EmptyState(icon: Icons.people_outline, title: 'مشتری پیدا نشد', subtitle: 'مشتری جدید اضافه کن یا فیلتر را تغییر بده.', button: 'افزودن مشتری', onTap: add);
        return ListView.separated(padding: const EdgeInsets.all(16), itemCount: list.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, i) {
          final c = list[i]; final b = c['balance'] as int;
          return CustomerCard(customer: c, balance: b, onOpen: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailsPage(customerId: c['id'] as int))); reload(); }, onDebt: () async { if (!await ensureActive(context)) return; final ok = await showTransactionDialog(context, customerId: c['id'] as int, type: 'debt'); if (ok == true) reload(); }, onPay: () async { if (!await ensureActive(context)) return; final ok = await showTransactionDialog(context, customerId: c['id'] as int, type: 'payment'); if (ok == true) reload(); });
        });
      })),
    ]),
  );
  Widget chip(String value, String label) => FilterChip(label: Text(label), selected: filter == value, onSelected: (_) { filter = value; reload(); });
  Future<void> add() async { if (!await ensureActive(context)) return; final ok = await showCustomerDialog(context); if (ok == true) reload(); }
}

class CustomerCard extends StatelessWidget {
  final Map<String, dynamic> customer; final int balance; final VoidCallback onOpen, onDebt, onPay;
  const CustomerCard({super.key, required this.customer, required this.balance, required this.onOpen, required this.onDebt, required this.onPay});
  @override
  Widget build(BuildContext context) {
    final name = customer['name'].toString(); final phone = customer['phone']?.toString() ?? ''; final color = balance > 0 ? Colors.orange : balance < 0 ? Colors.blue : Colors.green;
    return InkWell(borderRadius: BorderRadius.circular(26), onTap: onOpen, child: ProCard(child: Column(children: [
      Row(children: [CircleAvatar(backgroundColor: color.withOpacity(.13), child: Text(name.isEmpty ? 'م' : name[0], style: TextStyle(color: color, fontWeight: FontWeight.w900))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), if (phone.isNotEmpty) Text(fa(phone), style: const TextStyle(fontSize: 12, color: Colors.grey))])), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: color.withOpacity(.11), borderRadius: BorderRadius.circular(14)), child: Text(signedMoney(balance), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)))]),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: FilledButton.tonal(onPressed: onDebt, child: const Text('+ بدهی'))), const SizedBox(width: 8), Expanded(child: FilledButton.tonal(onPressed: onPay, child: const Text('پرداخت'))), const SizedBox(width: 8), Expanded(child: OutlinedButton(onPressed: onOpen, child: const Text('جزئیات')))]),
    ])));
  }
}

class CustomerDetailsPage extends StatefulWidget {
  final int customerId;
  const CustomerDetailsPage({super.key, required this.customerId});
  @override
  State<CustomerDetailsPage> createState() => _CustomerDetailsPageState();
}

class _CustomerDetailsPageState extends State<CustomerDetailsPage> {
  Map<String, Object?>? customer;
  int balance = 0;
  List<Map<String, Object?>> txs = [];
  @override
  void initState() { super.initState(); reload(); }
  Future<void> reload() async { customer = await AppDb.customer(widget.customerId); balance = await AppDb.balance(widget.customerId); txs = await AppDb.transactions(widget.customerId); setState(() {}); }
  @override
  Widget build(BuildContext context) {
    final c = customer;
    if (c == null) return const ProScaffold(title: 'مشتری', child: Center(child: CircularProgressIndicator()));
    return ProScaffold(
      title: c['name'].toString(),
      action: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { if (!await ensureActive(context)) return; final ok = await confirm(context, 'حذف مشتری', 'تمام اطلاعات این مشتری حذف شود؟'); if (ok) { await AppDb.deleteCustomer(widget.customerId); if (context.mounted) Navigator.pop(context); } }),
      child: ListView(padding: const EdgeInsets.all(16), children: [
        ProCard(child: Column(children: [InfoLine(label: 'مانده حساب', value: signedMoney(balance)), InfoLine(label: 'موبایل', value: c['phone']?.toString().isNotEmpty == true ? fa(c['phone'].toString()) : '-'), InfoLine(label: 'یادداشت', value: c['note']?.toString().isNotEmpty == true ? c['note'].toString() : '-')])),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: editCustomer, icon: const Icon(Icons.edit_outlined), label: const Text('ویرایش اطلاعات مشتری')),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: FilledButton(onPressed: () => addTx('debt'), child: const Text('+ بدهی'))), const SizedBox(width: 8), Expanded(child: FilledButton.tonal(onPressed: () => addTx('payment'), child: const Text('پرداخت'))), const SizedBox(width: 8), Expanded(child: FilledButton.tonal(onPressed: () => addTx('discount'), child: const Text('تخفیف')))]),
        const SizedBox(height: 8),
        Row(children: [Expanded(child: OutlinedButton.icon(onPressed: sendInvoiceWhatsApp, icon: const Icon(Icons.chat), label: const Text('ارسال فاکتور'))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: copyInvoiceText, icon: const Icon(Icons.copy), label: const Text('کپی فاکتور')))]),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: exportInvoicePdf, icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('خروجی PDF رسمی')),
        const SizedBox(height: 18),
        Text('ریز تراکنش‌ها', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        if (txs.isEmpty) const EmptyState(icon: Icons.receipt_long, title: 'تراکنشی ثبت نشده', subtitle: 'بدهی یا پرداخت اضافه کن.') else ...txs.map((t) => TransactionTile(
          t: t,
          onEdit: () async {
            if (!await ensureActive(context)) return;
            final ok = await showTransactionDialog(context, customerId: widget.customerId, type: t['type'].toString(), transaction: t);
            if (ok == true) reload();
          },
          onDelete: () async { if (!await ensureActive(context)) return; final ok = await confirm(context, 'حذف تراکنش', 'این تراکنش حذف شود؟'); if (ok) { await AppDb.deleteTransaction(t['id'] as int); reload(); } },
        )) ,
      ]),
    );
  }
  String invoiceText() {
    final c = customer!;
    final b = StringBuffer();
    b.writeln('صورتحساب مشتری');
    b.writeln('-------------------------');
    b.writeln('نام مشتری: ${c['name']}');
    b.writeln('موبایل: ${c['phone'] ?? '-'}');
    b.writeln('مانده حساب: ${signedMoney(balance)}');
    b.writeln('تاریخ صدور: ${isoToJalali(todayIso())}');
    b.writeln('');
    b.writeln('ریز تراکنش‌ها:');
    if (txs.isEmpty) { b.writeln('تراکنشی ثبت نشده است.'); } else { for (final t in txs) { b.writeln('${typeLabel(t['type'].toString())} | ${money(t['amount'] as int)} | ${isoToJalali(t['dateIso']?.toString())}'); } }
    return b.toString();
  }
  Future<void> copyInvoiceText() async { if (!await ensureActive(context)) return; await Clipboard.setData(ClipboardData(text: invoiceText())); if (mounted) toast(context, 'متن فاکتور کپی شد'); }
  Future<void> sendInvoiceWhatsApp() async {
    if (!await ensureActive(context)) return;
    final phone = customer?['phone']?.toString() ?? '';
    final text = Uri.encodeComponent(invoiceText());
    final cleanPhone = enDigits(phone).replaceAll(RegExp(r'[^0-9]'), '');
    final url = cleanPhone.isEmpty ? 'https://wa.me/?text=$text' : 'https://wa.me/$cleanPhone?text=$text';
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) { await copyInvoiceText(); toast(context, 'واتساپ باز نشد؛ متن فاکتور کپی شد'); }
  }

  Future<void> exportInvoicePdf() async {
    if (!await ensureActive(context)) return;
    final c = customer!;
    final font = await PdfGoogleFonts.notoNaskhArabicRegular();
    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: font),
        textDirection: pw.TextDirection.rtl,
        build: (pdfContext) => [
          pw.Text('صورتحساب مشتری', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 10),
          pw.Text('نام مشتری: ${c['name']}'),
          pw.Text('موبایل: ${c['phone'] ?? '-'}'),
          pw.Text('تاریخ صدور: ${isoToJalali(todayIso())}'),
          pw.Text('مانده نهایی: ${signedMoney(balance)}'),
          pw.SizedBox(height: 14),
          pw.TableHelper.fromTextArray(
            headers: ['نوع', 'مبلغ', 'تاریخ', 'توضیح'],
            data: txs.map((t) => [typeLabel(t['type'].toString()), money(t['amount'] as int), isoToJalali(t['dateIso']?.toString()), t['note']?.toString() ?? '']).toList(),
          ),
        ],
      ),
    );
    await Printing.sharePdf(bytes: await doc.save(), filename: 'invoice-${widget.customerId}.pdf');
  }

  Future<void> editCustomer() async {
    if (!await ensureActive(context)) return;
    final ok = await showCustomerDialog(context, customer: customer);
    if (ok == true) reload();
  }

  Future<void> addTx(String type) async { if (!await ensureActive(context)) return; final ok = await showTransactionDialog(context, customerId: widget.customerId, type: type); if (ok == true) reload(); }
}

class TransactionTile extends StatelessWidget {
  final Map<String, Object?> t; final VoidCallback? onDelete; final VoidCallback? onEdit;
  const TransactionTile({super.key, required this.t, this.onDelete, this.onEdit});
  @override
  Widget build(BuildContext context) {
    final type = t['type'].toString(); final color = type == 'debt' ? Colors.orange : type == 'payment' ? Colors.green : Colors.blue;
    return Padding(padding: const EdgeInsets.only(bottom: 8), child: ProCard(padding: const EdgeInsets.all(12), child: Row(children: [
      CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(typeIcon(type), color: color)), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${typeLabel(type)} - ${money(t['amount'] as int)}', style: const TextStyle(fontWeight: FontWeight.w900)), Text('تاریخ: ${isoToJalali(t['dateIso']?.toString())}', style: const TextStyle(fontSize: 12, color: Colors.grey)), if ((t['reminderIso']?.toString() ?? '').isNotEmpty) Text('یادآوری: ${isoToJalali(t['reminderIso']?.toString())}', style: const TextStyle(fontSize: 12, color: Colors.orange)), if ((t['note']?.toString() ?? '').isNotEmpty) Text(t['note'].toString(), style: const TextStyle(fontSize: 12))])),
      if (onEdit != null) IconButton(onPressed: onEdit, icon: const Icon(Icons.edit_outlined)),
      if (onDelete != null) IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline)),
    ])));
  }
}

class RemindersPage extends StatefulWidget {
  const RemindersPage({super.key});
  @override
  State<RemindersPage> createState() => _RemindersPageState();
}

class _RemindersPageState extends State<RemindersPage> {
  Future<List<Map<String, Object?>>>? future;
  @override
  void initState() { super.initState(); reload(); }
  void reload() { future = AppDb.remindersDue(); setState(() {}); }
  @override
  Widget build(BuildContext context) => ProScaffold(title: 'یادآوری‌ها', child: RefreshIndicator(onRefresh: () async => reload(), child: FutureBuilder<List<Map<String, Object?>>>(future: future, builder: (context, snap) {
    final list = snap.data ?? [];
    if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (list.isEmpty) return const EmptyState(icon: Icons.notifications_none, title: 'یادآوری فعالی نیست', subtitle: 'تاریخ یادآوری را با تاریخ شمسی ثبت کن.');
    return ListView.separated(padding: const EdgeInsets.all(16), itemCount: list.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, i) { final r = list[i]; return ProCard(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.notifications_active)), title: Text(r['customerName'].toString(), style: const TextStyle(fontWeight: FontWeight.w900)), subtitle: Text('مبلغ: ${money(r['amount'] as int)}\nیادآوری: ${isoToJalali(r['reminderIso']?.toString())}'), isThreeLine: true)); });
  })));
}

class ReportsPage extends StatefulWidget {
  ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  Future<Map<String, int>>? statsFuture;
  Future<List<Map<String, dynamic>>>? customersFuture;
  @override
  void initState() { super.initState(); reload(); }
  void reload() { statsFuture = AppDb.stats(); customersFuture = AppDb.customerBalances(); setState(() {}); }
  @override
  Widget build(BuildContext context) => ProScaffold(title: 'گزارش', child: RefreshIndicator(onRefresh: () async => reload(), child: ListView(padding: const EdgeInsets.all(16), children: [
    FutureBuilder<Map<String, int>>(future: statsFuture, builder: (context, snap) { final s = snap.data ?? {}; return ProCard(child: Column(children: [InfoLine(label: 'کل مشتری‌ها', value: fa('${s['customers'] ?? 0} نفر')), InfoLine(label: 'کل بدهی‌ها', value: money(s['totalDebt'] ?? 0)), InfoLine(label: 'بدهکارها', value: fa('${s['debtors'] ?? 0} نفر')), InfoLine(label: 'تسویه‌ها', value: fa('${s['settled'] ?? 0} نفر')), InfoLine(label: 'بستانکارها', value: fa('${s['credit'] ?? 0} نفر'))])); }),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: copyReport, icon: const Icon(Icons.copy), label: const Text('کپی گزارش کامل')),
    const SizedBox(height: 14),
    Text('مشتری‌ها بر اساس مانده حساب', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    FutureBuilder<List<Map<String, dynamic>>>(future: customersFuture, builder: (context, snap) { final list = snap.data ?? []; if (list.isEmpty) return const EmptyState(icon: Icons.bar_chart, title: 'گزارشی وجود ندارد', subtitle: 'اول مشتری و تراکنش ثبت کن.'); return Column(children: list.map((c) { final b = c['balance'] as int; return Padding(padding: const EdgeInsets.only(bottom: 8), child: ProCard(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: Text(c['name'].toString(), style: const TextStyle(fontWeight: FontWeight.w900))), Text(signedMoney(b), style: const TextStyle(fontWeight: FontWeight.w800))]))); }).toList()); }),
  ])));
  Future<void> copyReport() async { if (!await ensureActive(context)) return; await Clipboard.setData(ClipboardData(text: await AppDb.fullReportText())); if (mounted) toast(context, 'گزارش کامل کپی شد'); }
}

class SubscriptionExpiredPage extends StatelessWidget {
  final VoidCallback onGoSubscription;
  const SubscriptionExpiredPage({super.key, required this.onGoSubscription});
  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'اشتراک تمام شده',
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: ProCard(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_clock, size: 64, color: Colors.orange),
                const SizedBox(height: 14),
                const Text('دوره رایگان تمام شده', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                const SizedBox(height: 8),
                const Text('برای ادامه استفاده از امکانات اصلی، اشتراک را فعال کن.', textAlign: TextAlign.center),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: onGoSubscription,
                  icon: const Icon(Icons.workspace_premium),
                  label: const Text('مشاهده پلن‌ها'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SubscriptionPage extends StatefulWidget {
  final VoidCallback onChanged;
  const SubscriptionPage({super.key, required this.onChanged});
  @override
  State<SubscriptionPage> createState() => _SubscriptionPageState();
}

class _SubscriptionPageState extends State<SubscriptionPage> {
  Future<List<Map<String, Object?>>>? plansFuture;
  Future<String>? labelFuture;
  String supportPhone = '';
  String paymentCard = '';
  @override
  void initState() { super.initState(); reload(); }
  Future<void> reload() async { plansFuture = AppDb.plans(); labelFuture = AppDb.accessLabel(); supportPhone = await AppDb.getSetting('supportPhone') ?? ''; paymentCard = await AppDb.getSetting('paymentCard') ?? ''; setState(() {}); }
  @override
  Widget build(BuildContext context) => ProScaffold(
    title: 'اشتراک',
    action: IconButton(icon: const Icon(Icons.admin_panel_settings_outlined), onPressed: openAdminPanel),
    child: FutureBuilder<List<Map<String, Object?>>>(future: plansFuture, builder: (context, snap) {
      final plans = snap.data ?? [];
      return ListView(padding: const EdgeInsets.all(16), children: [
        ProCard(child: Column(children: [const Icon(Icons.workspace_premium, size: 54, color: Colors.orange), const SizedBox(height: 10), FutureBuilder<String>(future: labelFuture, builder: (context, s) => Text(s.data ?? '', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16), textAlign: TextAlign.center)), const SizedBox(height: 8), const Text('۳۰ روز اول رایگان است. بعد از پایان دوره رایگان، ثبت اطلاعات جدید نیاز به اشتراک دارد.', textAlign: TextAlign.center), if (paymentCard.isNotEmpty) ...[const SizedBox(height: 8), Text('شماره کارت: ${fa(paymentCard)}', style: const TextStyle(fontWeight: FontWeight.w800))]])),
        const SizedBox(height: 12),
        ...plans.map((p) => PlanCard(plan: p, onBuy: () => buyPlan(p))),
      ]);
    }),
  );
  Future<void> buyPlan(Map<String, Object?> plan) async {
    final months = plan['months'] as int; final price = plan['price'] as int; final title = plan['title'].toString();
    await showModalBottomSheet(context: context, showDragHandle: true, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: const EdgeInsets.all(18), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text('مبلغ: ${money(price)}'), const SizedBox(height: 8), Text(paymentCard.isEmpty ? 'شماره کارت هنوز تنظیم نشده.' : 'پرداخت به کارت: ${fa(paymentCard)}', textAlign: TextAlign.center), const SizedBox(height: 12), if (supportPhone.isNotEmpty) FilledButton.icon(onPressed: () async { final text = Uri.encodeComponent('سلام، درخواست خرید $title به مبلغ ${money(price)} را دارم.'); await launchUrl(Uri.parse('https://wa.me/${enDigits(supportPhone).replaceAll(RegExp(r'[^0-9]'), '')}?text=$text'), mode: LaunchMode.externalApplication); }, icon: const Icon(Icons.chat), label: const Text('درخواست خرید در واتساپ')), const SizedBox(height: 8), OutlinedButton.icon(onPressed: () async { Navigator.pop(context); await activateWithAdmin(months); }, icon: const Icon(Icons.admin_panel_settings), label: const Text('فعال‌سازی با رمز ادمین'))]))));
  }
  Future<void> activateWithAdmin(int months) async {
    final pin = TextEditingController();
    final ok = await askPin(context, pin, 'تأیید ادمین');
    if (!ok) return;
    if ((await AppDb.getSetting('adminPin')) != enDigits(pin.text.trim())) { if (mounted) toast(context, 'رمز ادمین اشتباه است'); return; }
    await AppDb.activateSubscription(months); await reload(); widget.onChanged(); if (mounted) toast(context, 'اشتراک فعال شد');
  }
  Future<void> openAdminPanel() async {
    final pin = TextEditingController();
    final ok = await askPin(context, pin, 'ورود ادمین');
    if (!ok) return;
    if ((await AppDb.getSetting('adminPin')) != enDigits(pin.text.trim())) { if (mounted) toast(context, 'رمز ادمین اشتباه است'); return; }
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminSubscriptionPage()));
    await reload(); widget.onChanged();
  }
}

class PlanCard extends StatelessWidget {
  final Map<String, Object?> plan; final VoidCallback onBuy;
  const PlanCard({super.key, required this.plan, required this.onBuy});
  @override
  Widget build(BuildContext context) { final months = plan['months'] as int; final price = plan['price'] as int; final title = plan['title'].toString(); return Padding(padding: const EdgeInsets.only(bottom: 10), child: ProCard(child: Row(children: [CircleAvatar(backgroundColor: Colors.orange.withOpacity(.14), child: Text(fa('$months'), style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.w900))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(money(price), style: const TextStyle(color: Colors.grey))])), FilledButton(onPressed: onBuy, child: const Text('خرید'))]))); }
}

class AdminSubscriptionPage extends StatefulWidget {
  const AdminSubscriptionPage({super.key});
  @override
  State<AdminSubscriptionPage> createState() => _AdminSubscriptionPageState();
}

class _AdminSubscriptionPageState extends State<AdminSubscriptionPage> {
  List<Map<String, Object?>> plans = [];
  final support = TextEditingController();
  final card = TextEditingController();
  final newPin = TextEditingController();
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async { plans = await AppDb.plans(); support.text = await AppDb.getSetting('supportPhone') ?? ''; card.text = await AppDb.getSetting('paymentCard') ?? ''; setState(() {}); }
  @override
  Widget build(BuildContext context) => ProScaffold(title: 'پنل ادمین اشتراک', child: ListView(padding: const EdgeInsets.all(16), children: [const Text('قیمت پلن‌ها', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(height: 10), ...plans.map((p) => PriceEditor(plan: p, onSaved: load)), const SizedBox(height: 14), ProCard(child: Column(children: [ProField(controller: card, label: 'شماره کارت پرداخت', icon: Icons.credit_card, keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: support, label: 'شماره واتساپ پشتیبانی با کد کشور', icon: Icons.support_agent, keyboardType: TextInputType.phone), const SizedBox(height: 10), ProField(controller: newPin, label: 'رمز جدید ادمین اختیاری', icon: Icons.admin_panel_settings, obscure: true, keyboardType: TextInputType.number), const SizedBox(height: 12), FilledButton(onPressed: save, child: const Text('ذخیره تنظیمات ادمین'))]))]));
  Future<void> save() async { await AppDb.setSetting('paymentCard', enDigits(card.text.trim())); await AppDb.setSetting('supportPhone', enDigits(support.text.trim())); if (newPin.text.trim().isNotEmpty) { final p = enDigits(newPin.text.trim()); if (!RegExp(r'^\d{4}$').hasMatch(p)) { toast(context, 'رمز ادمین باید ۴ رقم باشد'); return; } await AppDb.setSetting('adminPin', p); } if (mounted) toast(context, 'ذخیره شد'); }
}

class PriceEditor extends StatefulWidget {
  final Map<String, Object?> plan; final VoidCallback onSaved;
  const PriceEditor({super.key, required this.plan, required this.onSaved});
  @override
  State<PriceEditor> createState() => _PriceEditorState();
}

class _PriceEditorState extends State<PriceEditor> {
  late TextEditingController price;
  @override
  void initState() { super.initState(); price = TextEditingController(text: '${widget.plan['price']}'); }
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 8), child: ProCard(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: Text(widget.plan['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w900))), SizedBox(width: 120, child: TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت'))), IconButton(onPressed: save, icon: const Icon(Icons.save_outlined))])));
  Future<void> save() async { final a = cleanAmount(price.text); if (a <= 0) { toast(context, 'قیمت درست نیست'); return; } await AppDb.updatePlanPrice(widget.plan['id'] as int, a); widget.onSaved(); if (mounted) toast(context, 'قیمت ذخیره شد'); }
}

class SettingsPage extends StatefulWidget {
  final VoidCallback onLogout;
  const SettingsPage({super.key, required this.onLogout});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final business = TextEditingController(); final category = TextEditingController(); final phone = TextEditingController(); final username = TextEditingController(); final password = TextEditingController();
  final backupPaste = TextEditingController();
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async { business.text = await AppDb.getSetting('businessName') ?? ''; category.text = await AppDb.getSetting('businessCategory') ?? ''; phone.text = await AppDb.getSetting('businessPhone') ?? ''; username.text = await AppDb.getSetting('username') ?? ''; password.text = await AppDb.getSetting('password') ?? ''; setState(() {}); }
  @override
  Widget build(BuildContext context) => ProScaffold(title: 'تنظیمات', child: ListView(padding: const EdgeInsets.all(16), children: [ProCard(child: Column(children: [ProField(controller: business, label: 'نام کسب‌وکار', icon: Icons.storefront), const SizedBox(height: 10), ProField(controller: category, label: 'دسته شغلی', icon: Icons.category_outlined), const SizedBox(height: 10), ProField(controller: phone, label: 'شماره تماس کسب‌وکار', icon: Icons.phone_outlined, keyboardType: TextInputType.phone), const SizedBox(height: 12), FilledButton(onPressed: saveBusiness, child: const Text('ذخیره اطلاعات کسب‌وکار'))])), const SizedBox(height: 12), ProCard(child: Column(children: [ProField(controller: username, label: 'نام کاربری ورود', icon: Icons.person_outline), const SizedBox(height: 10), ProField(controller: password, label: 'رمز ورود', icon: Icons.lock_outline, keyboardType: TextInputType.number), const SizedBox(height: 12), OutlinedButton(onPressed: saveLogin, child: const Text('ذخیره اطلاعات ورود'))])), const SizedBox(height: 12), FilledButton.tonalIcon(onPressed: widget.onLogout, icon: const Icon(Icons.lock_outline), label: const Text('قفل کردن و خروج'))]));
  Future<void> saveBusiness() async { await AppDb.setSetting('businessName', business.text.trim().isEmpty ? 'دفتر حساب من' : business.text.trim()); await AppDb.setSetting('businessCategory', category.text.trim()); await AppDb.setSetting('businessPhone', phone.text.trim()); if (mounted) toast(context, 'اطلاعات کسب‌وکار ذخیره شد'); }
  Future<void> saveLogin() async { if (username.text.trim().isEmpty || password.text.trim().isEmpty) { toast(context, 'نام کاربری و رمز را کامل وارد کن'); return; } await AppDb.setSetting('username', username.text.trim()); await AppDb.setSetting('password', enDigits(password.text.trim())); if (mounted) toast(context, 'اطلاعات ورود ذخیره شد'); }

  Future<void> copyBackup() async {
    if (!await ensureActive(context)) return;
    final json = await AppDb.backupJson();
    await Clipboard.setData(ClipboardData(text: json));
    if (mounted) toast(context, 'بکاپ کامل کپی شد');
  }

  Future<void> restoreBackup() async {
    if (!await ensureActive(context)) return;
    backupPaste.clear();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('بازیابی بکاپ'),
          content: TextField(
            controller: backupPaste,
            maxLines: 8,
            decoration: const InputDecoration(labelText: 'متن JSON بکاپ را اینجا جایگذاری کن'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('بازیابی')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await AppDb.restoreJson(backupPaste.text.trim());
      await load();
      if (mounted) toast(context, 'بکاپ بازیابی شد');
    } catch (_) {
      if (mounted) toast(context, 'متن بکاپ معتبر نیست');
    }
  }
}

Future<bool?> showCustomerDialog(BuildContext context, {Map<String, Object?>? customer}) {
  final name = TextEditingController(text: customer?['name']?.toString() ?? '');
  final phone = TextEditingController(text: customer?['phone']?.toString() ?? '');
  final note = TextEditingController(text: customer?['note']?.toString() ?? '');
  return showDialog<bool>(context: context, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: Text(customer == null ? 'افزودن مشتری' : 'ویرایش مشتری'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [ProField(controller: name, label: 'نام مشتری', icon: Icons.person_outline), const SizedBox(height: 10), ProField(controller: phone, label: 'موبایل', icon: Icons.phone_outlined, keyboardType: TextInputType.phone), const SizedBox(height: 10), ProField(controller: note, label: 'یادداشت', icon: Icons.note_alt_outlined)])), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')), FilledButton(onPressed: () async { if (name.text.trim().isEmpty) return; if (customer == null) { await AppDb.insertCustomer(name.text.trim(), phone.text.trim(), note.text.trim()); } else { await AppDb.updateCustomer(customer['id'] as int, name.text.trim(), phone.text.trim(), note.text.trim()); } if (context.mounted) Navigator.pop(context, true); }, child: const Text('ذخیره'))])));
}

Future<bool?> showTransactionDialog(BuildContext context, {required int customerId, required String type, Map<String, Object?>? transaction}) {
  final amount = TextEditingController(text: transaction == null ? '' : '${transaction['amount']}');
  final date = TextEditingController(text: transaction == null ? todayJalali() : isoToJalali(transaction['dateIso']?.toString()));
  final reminder = TextEditingController(text: transaction == null ? '' : (transaction['reminderIso']?.toString().isEmpty == true ? '' : isoToJalali(transaction['reminderIso']?.toString())));
  final note = TextEditingController(text: transaction?['note']?.toString() ?? '');
  var selectedType = transaction?['type']?.toString() ?? type;
  return showDialog<bool>(context: context, builder: (context) => StatefulBuilder(builder: (context, setState) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: Text(transaction == null ? 'ثبت تراکنش' : 'ویرایش تراکنش'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [DropdownButtonFormField<String>(value: selectedType, decoration: const InputDecoration(labelText: 'نوع تراکنش'), items: const [DropdownMenuItem(value: 'debt', child: Text('بدهی')), DropdownMenuItem(value: 'payment', child: Text('پرداخت')), DropdownMenuItem(value: 'discount', child: Text('تخفیف / اصلاح'))], onChanged: (v) => setState(() => selectedType = v ?? selectedType)), const SizedBox(height: 10), ProField(controller: amount, label: 'مبلغ به تومان', icon: Icons.payments_outlined, keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: date, label: 'تاریخ شمسی مثل ۱۴۰۳/۰۳/۲۳', icon: Icons.calendar_month, keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: reminder, label: 'یادآوری شمسی اختیاری', icon: Icons.notifications_none, keyboardType: TextInputType.number), const SizedBox(height: 10), ProField(controller: note, label: 'توضیح', icon: Icons.note_alt_outlined)])), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')), FilledButton(onPressed: () async { final a = cleanAmount(amount.text); final iso = jalaliToIso(date.text); final rem = reminder.text.trim().isEmpty ? null : jalaliToIso(reminder.text); if (a <= 0 || iso == null || (reminder.text.trim().isNotEmpty && rem == null)) { toast(context, 'مبلغ یا تاریخ شمسی درست نیست'); return; } if (transaction == null) { await AppDb.insertTransaction(customerId: customerId, type: selectedType, amount: a, dateIso: iso, reminderIso: rem, note: note.text.trim()); } else { await AppDb.updateTransaction(id: transaction['id'] as int, type: selectedType, amount: a, dateIso: iso, reminderIso: rem, note: note.text.trim()); } if (context.mounted) Navigator.pop(context, true); }, child: const Text('ثبت'))]))));
}

Future<bool> askPin(BuildContext context, TextEditingController controller, String title) async {
  return await showDialog<bool>(context: context, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: Text(title), content: ProField(controller: controller, label: 'رمز ادمین', icon: Icons.admin_panel_settings, obscure: true, keyboardType: TextInputType.number), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأیید'))]))) ?? false;
}

String typeLabel(String type) {
  if (type == 'debt') return 'بدهی';
  if (type == 'payment') return 'پرداخت';
  return 'تخفیف / اصلاح';
}

IconData typeIcon(String type) {
  if (type == 'debt') return Icons.trending_up;
  if (type == 'payment') return Icons.payments_outlined;
  return Icons.discount_outlined;
}

Future<bool> confirm(BuildContext context, String title, String message) async {
  return await showDialog<bool>(context: context, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: Text(title), content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('نه')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('بله'))]))) ?? false;
}

class ProBackground extends StatelessWidget {
  final Widget child;
  const ProBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xffdff5ef), Color(0xffeef8f6), Colors.white])), child: child);
}

class ProScaffold extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? action;
  const ProScaffold({super.key, required this.title, required this.child, this.action});
  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), actions: action == null ? null : [action!]), body: child));
}

class ProCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const ProCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: padding, child: child));
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Container(width: 82, height: 82, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xff087d69), Color(0xff0ea5e9)]), borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: const Color(0xff087d69).withOpacity(.22), blurRadius: 28, offset: const Offset(0, 14))]), child: const Icon(Icons.account_balance_wallet_rounded, color: Colors.white, size: 42)));
}

class ProField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData? icon;
  final bool obscure;
  final TextInputType? keyboardType;
  const ProField({super.key, required this.controller, required this.label, this.icon, this.obscure = false, this.keyboardType});
  @override
  Widget build(BuildContext context) => TextField(controller: controller, obscureText: obscure, keyboardType: keyboardType, decoration: InputDecoration(labelText: label, prefixIcon: icon == null ? null : Icon(icon)));
}

class InfoLine extends StatelessWidget {
  final String label, value;
  const InfoLine({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Text(label, style: const TextStyle(color: Colors.grey)), const Spacer(), Flexible(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w800)))]));
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? button;
  final VoidCallback? onTap;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle, this.button, this.onTap});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 14), Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 8), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)), if (button != null) ...[const SizedBox(height: 16), FilledButton(onPressed: onTap, child: Text(button!))]])));
}
