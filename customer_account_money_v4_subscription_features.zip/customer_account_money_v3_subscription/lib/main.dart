
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MoneyApp());
}

class MoneyApp extends StatelessWidget {
  const MoneyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xff00a98f);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دفتر حساب مشتریان',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xfff4fbfb),
        cardTheme: CardThemeData(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
      ),
      home: const AuthGate(),
    );
  }
}

// -------------------- Helpers --------------------

String fa(String input) {
  const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const pr = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  var out = input;
  for (var i = 0; i < en.length; i++) {
    out = out.replaceAll(en[i], pr[i]);
  }
  return out;
}

String enDigits(String input) {
  const pr = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const ar = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  var out = input;
  for (var i = 0; i < en.length; i++) {
    out = out.replaceAll(pr[i], en[i]).replaceAll(ar[i], en[i]);
  }
  return out;
}

String money(int value) {
  final s = value.abs().toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'),
        (_) => ',',
      );
  return '${fa(s)} تومان';
}

String signedMoney(int value) {
  if (value == 0) return 'تسویه';
  if (value < 0) return 'بستانکار: ${money(value)}';
  return money(value);
}

int cleanAmount(String value) {
  return int.tryParse(enDigits(value).replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
}

String isoDate(DateTime d) => d.toIso8601String().substring(0, 10);
String todayIso() => isoDate(DateTime.now());
String faDate(String? iso) => iso == null || iso.isEmpty ? '-' : fa(iso);

DateTime? parseIso(String? iso) {
  if (iso == null || iso.isEmpty) return null;
  return DateTime.tryParse(iso);
}

String addDaysIso(String? baseIso, int days) {
  final now = DateTime.now();
  final base = parseIso(baseIso);
  final start = base != null && base.isAfter(now) ? base : now;
  return isoDate(start.add(Duration(days: days)));
}

int daysLeft(String? iso) {
  final d = parseIso(iso);
  if (d == null) return -9999;
  final now = DateTime.now();
  return d.difference(DateTime(now.year, now.month, now.day)).inDays;
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}

// -------------------- DB --------------------

class AppDb {
  static Database? _db;

  static Future<Database> get instance async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'customer_money_v3_subscription.db');

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
        await db.execute('CREATE TABLE businesses(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, phone TEXT)');
        await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, businessId INTEGER NOT NULL, name TEXT NOT NULL, phone TEXT, note TEXT, createdAt TEXT NOT NULL)');
        await db.execute('CREATE TABLE account_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER NOT NULL, type TEXT NOT NULL, amount INTEGER NOT NULL, dateIso TEXT NOT NULL, reminderIso TEXT, note TEXT, createdAt TEXT NOT NULL)');
        await db.execute('CREATE TABLE subscription_plans(id INTEGER PRIMARY KEY, title TEXT NOT NULL, months INTEGER NOT NULL, price INTEGER NOT NULL)');
      },
    );

    await seedPlans();
    return _db!;
  }

  static Future<void> seedPlans() async {
    final db = _db!;
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM subscription_plans')) ?? 0;
    if (count > 0) return;

    await db.insert('subscription_plans', {'id': 1, 'title': 'اشتراک ۱ ماهه', 'months': 1, 'price': 59000});
    await db.insert('subscription_plans', {'id': 2, 'title': 'اشتراک ۳ ماهه', 'months': 3, 'price': 149000});
    await db.insert('subscription_plans', {'id': 3, 'title': 'اشتراک ۶ ماهه', 'months': 6, 'price': 249000});
    await db.insert('subscription_plans', {'id': 4, 'title': 'اشتراک ۱ ساله', 'months': 12, 'price': 399000});
  }

  static Future<String?> getSetting(String key) async {
    final db = await instance;
    final rows = await db.query('settings', where: 'key=?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  static Future<void> setSetting(String key, String value) async {
    final db = await instance;
    await db.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<int?> activeBusinessId() async {
    final id = await getSetting('activeBusinessId');
    return id == null ? null : int.tryParse(id);
  }

  static Future<Map<String, Object?>?> activeBusiness() async {
    final db = await instance;
    final id = await activeBusinessId();
    if (id == null) return null;
    final rows = await db.query('businesses', where: 'id=?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<int> createBusiness(String name, String category, String phone) async {
    final db = await instance;
    final id = await db.insert('businesses', {'name': name, 'category': category, 'phone': phone});
    await setSetting('activeBusinessId', '$id');
    return id;
  }

  static Future<void> updateBusiness(int id, String name, String category, String phone) async {
    final db = await instance;
    await db.update('businesses', {'name': name, 'category': category, 'phone': phone}, where: 'id=?', whereArgs: [id]);
  }

  static Future<List<Map<String, Object?>>> plans() async {
    final db = await instance;
    return db.query('subscription_plans', orderBy: 'months ASC');
  }

  static Future<void> updatePlanPrice(int id, int price) async {
    final db = await instance;
    await db.update('subscription_plans', {'price': price}, where: 'id=?', whereArgs: [id]);
  }

  static Future<bool> hasAccess() async {
    final trialEnd = await getSetting('trialEndIso');
    final subEnd = await getSetting('subscriptionUntilIso');
    final trial = daysLeft(trialEnd) >= 0;
    final sub = daysLeft(subEnd) >= 0;
    return trial || sub;
  }

  static Future<String> accessLabel() async {
    final trialEnd = await getSetting('trialEndIso');
    final subEnd = await getSetting('subscriptionUntilIso');
    final trialDays = daysLeft(trialEnd);
    final subDays = daysLeft(subEnd);

    if (subDays >= 0) return 'اشتراک فعال تا ${faDate(subEnd)}';
    if (trialDays >= 0) return 'دوره رایگان: ${fa('$trialDays')} روز باقی‌مانده';
    return 'دوره رایگان تمام شده';
  }

  static Future<int> activateSubscription(int months) async {
    final current = await getSetting('subscriptionUntilIso');
    final until = addDaysIso(current, months * 30);
    await setSetting('subscriptionUntilIso', until);
    return daysLeft(until);
  }

  static Future<List<Map<String, Object?>>> customers({String query = ''}) async {
    final db = await instance;
    final businessId = await activeBusinessId();
    if (businessId == null) return [];

    if (query.trim().isEmpty) {
      return db.query('customers', where: 'businessId=?', whereArgs: [businessId], orderBy: 'id DESC');
    }

    return db.query(
      'customers',
      where: 'businessId=? AND (name LIKE ? OR phone LIKE ? OR note LIKE ?)',
      whereArgs: [businessId, '%$query%', '%$query%', '%$query%'],
      orderBy: 'id DESC',
    );
  }

  static Future<int> insertCustomer(String name, String phone, String note) async {
    final db = await instance;
    final businessId = await activeBusinessId();
    if (businessId == null) throw Exception('No business');
    return db.insert('customers', {
      'businessId': businessId,
      'name': name,
      'phone': phone,
      'note': note,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> deleteCustomer(int id) async {
    final db = await instance;
    await db.delete('account_transactions', where: 'customerId=?', whereArgs: [id]);
    await db.delete('customers', where: 'id=?', whereArgs: [id]);
  }

  static Future<Map<String, Object?>?> customer(int id) async {
    final db = await instance;
    final rows = await db.query('customers', where: 'id=?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<List<Map<String, Object?>>> transactions(int customerId) async {
    final db = await instance;
    return db.query('account_transactions', where: 'customerId=?', whereArgs: [customerId], orderBy: 'id DESC');
  }

  static Future<void> insertTransaction({
    required int customerId,
    required String type,
    required int amount,
    required String dateIso,
    String? reminderIso,
    String note = '',
  }) async {
    final db = await instance;
    await db.insert('account_transactions', {
      'customerId': customerId,
      'type': type,
      'amount': amount,
      'dateIso': dateIso,
      'reminderIso': reminderIso,
      'note': note,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<int> balance(int customerId) async {
    final txs = await transactions(customerId);
    var total = 0;
    for (final t in txs) {
      final type = t['type'] as String;
      final amount = t['amount'] as int;
      total += type == 'debt' ? amount : -amount;
    }
    return total;
  }

  static Future<Map<String, int>> stats() async {
    final cs = await customers();
    var totalDebt = 0;
    var debtors = 0;
    var settled = 0;

    for (final c in cs) {
      final b = await balance(c['id'] as int);
      if (b > 0) {
        totalDebt += b;
        debtors++;
      } else if (b == 0) {
        settled++;
      }
    }

    return {'customers': cs.length, 'totalDebt': totalDebt, 'debtors': debtors, 'settled': settled};
  }

  static Future<void> deleteTransaction(int id) async {
    final db = await instance;
    await db.delete('account_transactions', where: 'id=?', whereArgs: [id]);
  }

  static Future<List<Map<String, Object?>>> remindersDue() async {
    final db = await instance;
    final today = todayIso();
    return db.rawQuery(
      'SELECT t.*, c.name as customerName, c.phone as customerPhone FROM account_transactions t JOIN customers c ON c.id = t.customerId WHERE t.reminderIso IS NOT NULL AND t.reminderIso != "" AND t.reminderIso <= ? ORDER BY t.reminderIso ASC',
      [today],
    );
  }

  static Future<List<Map<String, dynamic>>> customerBalances() async {
    final list = await customers();
    final out = <Map<String, dynamic>>[];
    for (final c in list) {
      final b = await balance(c['id'] as int);
      out.add({...c, 'balance': b});
    }
    out.sort((a, b) => (b['balance'] as int).compareTo(a['balance'] as int));
    return out;
  }

  static Future<String> fullReportText() async {
    final s = await stats();
    final rows = await customerBalances();
    final buffer = StringBuffer();
    buffer.writeln('گزارش دفتر حساب مشتریان');
    buffer.writeln('تاریخ گزارش: ${faDate(todayIso())}');
    buffer.writeln('');
    buffer.writeln('کل مشتری‌ها: ${fa('${s['customers'] ?? 0}')}');
    buffer.writeln('کل بدهی‌ها: ${money(s['totalDebt'] ?? 0)}');
    buffer.writeln('بدهکارها: ${fa('${s['debtors'] ?? 0}')}');
    buffer.writeln('تسویه‌ها: ${fa('${s['settled'] ?? 0}')}');
    buffer.writeln('');
    buffer.writeln('لیست مشتری‌ها:');
    for (final c in rows) {
      buffer.writeln('${c['name']} | ${c['phone'] ?? '-'} | ${signedMoney(c['balance'] as int)}');
    }
    return buffer.toString();
  }
}

// -------------------- Auth --------------------

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  bool setupDone = false;
  bool loggedIn = false;

  @override
  void initState() {
    super.initState();
    check();
  }

  Future<void> check() async {
    await AppDb.instance;
    final pin = await AppDb.getSetting('pin');
    final business = await AppDb.activeBusiness();
    setState(() {
      setupDone = pin != null && business != null;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Directionality(textDirection: TextDirection.rtl, child: Scaffold(body: Center(child: CircularProgressIndicator())));
    if (!setupDone) {
      return SetupScreen(onDone: () async {
        await check();
        setState(() => loggedIn = true);
      });
    }
    if (!loggedIn) return LoginScreen(onLogin: () => setState(() => loggedIn = true));
    return AppShell(onLogout: () => setState(() => loggedIn = false));
  }
}

class SetupScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SetupScreen({super.key, required this.onDone});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final name = TextEditingController();
  final category = TextEditingController();
  final phone = TextEditingController();
  final pin = TextEditingController();
  final pin2 = TextEditingController();
  final adminPin = TextEditingController(text: '2468');

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: ProBackground(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: ProCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const AppLogo(),
                    const SizedBox(height: 14),
                    Text('راه‌اندازی اپ', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    const Text('۳۰ روز اول رایگان است. بعد از پایان دوره رایگان، کاربر برای ادامه باید اشتراک تهیه کند.', textAlign: TextAlign.center),
                    const SizedBox(height: 18),
                    ProField(controller: name, label: 'نام کسب‌وکار'),
                    const SizedBox(height: 10),
                    ProField(controller: category, label: 'دسته شغلی'),
                    const SizedBox(height: 10),
                    ProField(controller: phone, label: 'شماره تماس اختیاری', keyboardType: TextInputType.phone),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: ProField(controller: pin, label: 'رمز ورود', obscure: true, keyboardType: TextInputType.number)),
                      const SizedBox(width: 10),
                      Expanded(child: ProField(controller: pin2, label: 'تکرار رمز', obscure: true, keyboardType: TextInputType.number)),
                    ]),
                    const SizedBox(height: 10),
                    ProField(controller: adminPin, label: 'رمز ادمین برای تنظیم قیمت و فعال‌سازی', obscure: true, keyboardType: TextInputType.number),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: save, child: const Text('شروع دوره رایگان')),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> save() async {
    if (name.text.trim().isEmpty || category.text.trim().isEmpty) {
      toast(context, 'نام و دسته شغلی را کامل وارد کن');
      return;
    }
    if (!RegExp(r'^\d{4}$').hasMatch(enDigits(pin.text.trim()))) {
      toast(context, 'رمز ورود باید ۴ رقم باشد');
      return;
    }
    if (enDigits(pin.text.trim()) != enDigits(pin2.text.trim())) {
      toast(context, 'تکرار رمز درست نیست');
      return;
    }
    if (!RegExp(r'^\d{4}$').hasMatch(enDigits(adminPin.text.trim()))) {
      toast(context, 'رمز ادمین باید ۴ رقم باشد');
      return;
    }

    await AppDb.createBusiness(name.text.trim(), category.text.trim(), phone.text.trim());
    await AppDb.setSetting('pin', enDigits(pin.text.trim()));
    await AppDb.setSetting('adminPin', enDigits(adminPin.text.trim()));
    await AppDb.setSetting('trialStartIso', todayIso());
    await AppDb.setSetting('trialEndIso', isoDate(DateTime.now().add(const Duration(days: 30))));
    await AppDb.setSetting('subscriptionUntilIso', '');
    await AppDb.setSetting('supportPhone', '');
    await AppDb.setSetting('paymentCard', '');

    widget.onDone();
  }
}

class LoginScreen extends StatefulWidget {
  final VoidCallback onLogin;
  const LoginScreen({super.key, required this.onLogin});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final pin = TextEditingController();
  Map<String, Object?>? business;

  @override
  void initState() {
    super.initState();
    AppDb.activeBusiness().then((b) => setState(() => business = b));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: ProBackground(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: ProCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const AppLogo(),
                    const SizedBox(height: 14),
                    Text(business?['name']?.toString() ?? 'دفتر حساب', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 18),
                    ProField(controller: pin, label: 'رمز ورود', obscure: true, keyboardType: TextInputType.number),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: login, child: const Text('ورود')),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> login() async {
    final saved = await AppDb.getSetting('pin');
    if (saved == enDigits(pin.text.trim())) {
      widget.onLogin();
    } else {
      toast(context, 'رمز اشتباه است');
    }
  }
}

// -------------------- Shell --------------------

class AppShell extends StatefulWidget {
  final VoidCallback onLogout;
  const AppShell({super.key, required this.onLogout});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onRefresh: () => setState(() {})),
      CustomersPage(),
      const RemindersPage(),
      ReportsPage(),
      SubscriptionPage(onChanged: () => setState(() {})),
      SettingsPage(onLogout: widget.onLogout),
    ];

    return FutureBuilder<bool>(
      future: AppDb.hasAccess(),
      builder: (context, snap) {
        final hasAccess = snap.data ?? true;
        Widget body;

        if (!hasAccess && index != 4 && index != 5) {
          body = SubscriptionExpiredPage(onGoSubscription: () => setState(() => index = 4));
        } else {
          body = pages[index];
        }

        return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            body: body,
            bottomNavigationBar: NavigationBar(
              selectedIndex: index,
              onDestinationSelected: (i) => setState(() => index = i),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'خانه'),
                NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'مشتری‌ها'),
                NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'یادآوری'),
                NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'گزارش'),
                NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'اشتراک'),
                NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
              ],
            ),
          ),
        );
      },
    );
  }
}

class SubscriptionExpiredPage extends StatelessWidget {
  final VoidCallback onGoSubscription;
  const SubscriptionExpiredPage({super.key, required this.onGoSubscription});

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'اشتراک تمام شده',
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: ProCard(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_clock, size: 64, color: Colors.orange),
                const SizedBox(height: 14),
                const Text('دوره رایگان شما تمام شده', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                const SizedBox(height: 8),
                const Text('برای ادامه استفاده از برنامه، یکی از پلن‌های اشتراک را انتخاب و فعال کنید.', textAlign: TextAlign.center),
                const SizedBox(height: 18),
                FilledButton.icon(onPressed: onGoSubscription, icon: const Icon(Icons.workspace_premium), label: const Text('خرید / فعال‌سازی اشتراک')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// -------------------- Home --------------------

class HomePage extends StatefulWidget {
  final VoidCallback onRefresh;
  const HomePage({super.key, required this.onRefresh});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Future<Map<String, int>>? statsFuture;
  Future<Map<String, Object?>?>? businessFuture;
  Future<String>? accessFuture;

  @override
  void initState() {
    super.initState();
    reload();
  }

  void reload() {
    setState(() {
      statsFuture = AppDb.stats();
      businessFuture = AppDb.activeBusiness();
      accessFuture = AppDb.accessLabel();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'داشبورد',
      child: RefreshIndicator(
        onRefresh: () async => reload(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            FutureBuilder<Map<String, Object?>?>(
              future: businessFuture,
              builder: (context, snap) {
                final b = snap.data;
                return Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xff00a98f), Color(0xff0ea5e9)]),
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(b?['name']?.toString() ?? 'دفتر حساب', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      Text(b?['category']?.toString() ?? '', style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 14),
                      FutureBuilder<String>(
                        future: accessFuture,
                        builder: (context, snap) {
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(16)),
                            child: Row(
                              children: [
                                const Icon(Icons.workspace_premium, color: Colors.white, size: 18),
                                const SizedBox(width: 8),
                                Expanded(child: Text(snap.data ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 18),
                      FutureBuilder<Map<String, int>>(
                        future: statsFuture,
                        builder: (context, statsSnap) {
                          final s = statsSnap.data ?? {};
                          return Row(
                            children: [
                              Expanded(child: HeaderStat(label: 'کل بدهی', value: money(s['totalDebt'] ?? 0))),
                              const SizedBox(width: 10),
                              Expanded(child: HeaderStat(label: 'مشتری‌ها', value: fa('${s['customers'] ?? 0} نفر'))),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 14),
            FutureBuilder<Map<String, int>>(
              future: statsFuture,
              builder: (context, snap) {
                final s = snap.data ?? {};
                return GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.05,
                  children: [
                    MiniStat(icon: Icons.warning_amber_rounded, label: 'بدهکار', value: fa('${s['debtors'] ?? 0}')),
                    MiniStat(icon: Icons.check_circle_outline, label: 'تسویه', value: fa('${s['settled'] ?? 0}')),
                    MiniStat(icon: Icons.groups_2_outlined, label: 'کل مشتری', value: fa('${s['customers'] ?? 0}')),
                  ],
                );
              },
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: () async {
                final ok = await showCustomerDialog(context);
                if (ok == true) {
                  reload();
                  widget.onRefresh();
                }
              },
              icon: const Icon(Icons.person_add_alt),
              label: const Text('افزودن مشتری جدید'),
            ),
          ],
        ),
      ),
    );
  }
}

class HeaderStat extends StatelessWidget {
  final String label;
  final String value;
  const HeaderStat({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(18)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const MiniStat({super.key, required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return ProCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ],
      ),
    );
  }
}

// -------------------- Customers --------------------

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});
  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  final search = TextEditingController();
  String filter = 'all';
  Future<List<Map<String, dynamic>>>? future;

  @override
  void initState() {
    super.initState();
    reload();
  }

  void reload() {
    future = load();
    setState(() {});
  }

  Future<List<Map<String, dynamic>>> load() async {
    final rows = await AppDb.customers(query: search.text);
    final out = <Map<String, dynamic>>[];
    for (final c in rows) {
      final balance = await AppDb.balance(c['id'] as int);
      if (filter == 'debt' && balance <= 0) continue;
      if (filter == 'settled' && balance != 0) continue;
      out.add({...c, 'balance': balance});
    }
    out.sort((a, b) => (b['balance'] as int).compareTo(a['balance'] as int));
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'مشتری‌ها',
      action: IconButton(
        onPressed: () async {
          final ok = await showCustomerDialog(context);
          if (ok == true) reload();
        },
        icon: const Icon(Icons.add),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              controller: search,
              onChanged: (_) => reload(),
              decoration: InputDecoration(
                hintText: 'جستجوی مشتری...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
              ),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                FilterChip(label: const Text('همه'), selected: filter == 'all', onSelected: (_) => setFilter('all')),
                const SizedBox(width: 8),
                FilterChip(label: const Text('بدهکار'), selected: filter == 'debt', onSelected: (_) => setFilter('debt')),
                const SizedBox(width: 8),
                FilterChip(label: const Text('تسویه'), selected: filter == 'settled', onSelected: (_) => setFilter('settled')),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: future,
              builder: (context, snap) {
                final list = snap.data ?? [];
                if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                if (list.isEmpty) {
                  return EmptyState(
                    icon: Icons.people_outline,
                    title: 'مشتری ثبت نشده',
                    subtitle: 'برای شروع مشتری جدید اضافه کن.',
                    button: 'افزودن مشتری',
                    onTap: () async {
                      final ok = await showCustomerDialog(context);
                      if (ok == true) reload();
                    },
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final c = list[i];
                    return CustomerCard(
                      customer: c,
                      balance: c['balance'] as int,
                      onOpen: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerDetailsPage(customerId: c['id'] as int)));
                        reload();
                      },
                      onDebt: () async {
                        final ok = await showTransactionDialog(context, customerId: c['id'] as int, type: 'debt');
                        if (ok == true) reload();
                      },
                      onPay: () async {
                        final ok = await showTransactionDialog(context, customerId: c['id'] as int, type: 'payment');
                        if (ok == true) reload();
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void setFilter(String value) {
    filter = value;
    reload();
  }
}

class CustomerCard extends StatelessWidget {
  final Map<String, dynamic> customer;
  final int balance;
  final VoidCallback onOpen;
  final VoidCallback onDebt;
  final VoidCallback onPay;

  const CustomerCard({
    super.key,
    required this.customer,
    required this.balance,
    required this.onOpen,
    required this.onDebt,
    required this.onPay,
  });

  @override
  Widget build(BuildContext context) {
    final name = customer['name'].toString();
    final phone = customer['phone']?.toString() ?? '';
    final color = balance > 0 ? Colors.orange : Colors.green;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onOpen,
      child: ProCard(
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(backgroundColor: color.withOpacity(.13), child: Text(name.isEmpty ? 'م' : name[0], style: TextStyle(color: color, fontWeight: FontWeight.w900))),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    if (phone.isNotEmpty) Text(fa(phone), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(color: color.withOpacity(.11), borderRadius: BorderRadius.circular(14)),
                  child: Text(signedMoney(balance), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: FilledButton.tonal(onPressed: onDebt, child: const Text('+ بدهی'))),
                const SizedBox(width: 8),
                Expanded(child: FilledButton.tonal(onPressed: onPay, child: const Text('پرداخت'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(onPressed: onOpen, child: const Text('جزئیات'))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------- Details --------------------

class CustomerDetailsPage extends StatefulWidget {
  final int customerId;
  const CustomerDetailsPage({super.key, required this.customerId});
  @override
  State<CustomerDetailsPage> createState() => _CustomerDetailsPageState();
}

class _CustomerDetailsPageState extends State<CustomerDetailsPage> {
  Map<String, Object?>? customer;
  int balance = 0;
  List<Map<String, Object?>> txs = [];

  @override
  void initState() {
    super.initState();
    reload();
  }

  Future<void> reload() async {
    customer = await AppDb.customer(widget.customerId);
    balance = await AppDb.balance(widget.customerId);
    txs = await AppDb.transactions(widget.customerId);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final c = customer;
    if (c == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return ProScaffold(
      title: c['name'].toString(),
      action: IconButton(
        icon: const Icon(Icons.delete_outline),
        onPressed: () async {
          final ok = await confirm(context, 'حذف مشتری', 'تمام اطلاعات این مشتری حذف شود؟');
          if (ok) {
            await AppDb.deleteCustomer(widget.customerId);
            if (context.mounted) Navigator.pop(context);
          }
        },
      ),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ProCard(
            child: Column(
              children: [
                InfoLine(label: 'مانده حساب', value: signedMoney(balance)),
                InfoLine(label: 'موبایل', value: c['phone']?.toString().isEmpty == false ? fa(c['phone'].toString()) : '-'),
                InfoLine(label: 'یادداشت', value: c['note']?.toString().isEmpty == false ? c['note'].toString() : '-'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: FilledButton(onPressed: () => addTx('debt'), child: const Text('+ بدهی'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton.tonal(onPressed: () => addTx('payment'), child: const Text('پرداخت'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton.tonal(onPressed: () => addTx('discount'), child: const Text('تخفیف'))),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: OutlinedButton.icon(onPressed: sendInvoiceWhatsApp, icon: const Icon(Icons.chat), label: const Text('ارسال فاکتور'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: copyInvoiceText, icon: const Icon(Icons.copy), label: const Text('کپی فاکتور'))),
            ],
          ),
          const SizedBox(height: 18),
          Text('ریز تراکنش‌ها', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          if (txs.isEmpty)
            const EmptyState(icon: Icons.receipt_long, title: 'تراکنشی ثبت نشده', subtitle: 'بدهی یا پرداخت اضافه کن.')
          else
            ...txs.map((t) => TransactionTile(
                  t: t,
                  onDelete: () async {
                    final ok = await confirm(context, 'حذف تراکنش', 'این تراکنش حذف شود؟');
                    if (ok) {
                      await AppDb.deleteTransaction(t['id'] as int);
                      reload();
                    }
                  },
                )),
        ],
      ),
    );
  }

  String invoiceText() {
    final c = customer!;
    final buffer = StringBuffer();
    buffer.writeln('صورتحساب مشتری');
    buffer.writeln('-------------------------');
    buffer.writeln('نام مشتری: ${c['name']}');
    buffer.writeln('موبایل: ${c['phone'] ?? '-'}');
    buffer.writeln('مانده حساب: ${signedMoney(balance)}');
    buffer.writeln('تاریخ صدور: ${faDate(todayIso())}');
    buffer.writeln('');
    buffer.writeln('ریز تراکنش‌ها:');
    if (txs.isEmpty) {
      buffer.writeln('تراکنشی ثبت نشده است.');
    } else {
      for (final t in txs) {
        buffer.writeln('${typeLabel(t['type'].toString())} | ${money(t['amount'] as int)} | ${faDate(t['dateIso']?.toString())}');
      }
    }
    return buffer.toString();
  }

  Future<void> copyInvoiceText() async {
    await Clipboard.setData(ClipboardData(text: invoiceText()));
    if (mounted) toast(context, 'متن فاکتور کپی شد');
  }

  Future<void> sendInvoiceWhatsApp() async {
    final phone = customer?['phone']?.toString() ?? '';
    final text = Uri.encodeComponent(invoiceText());
    final cleanPhone = enDigits(phone).replaceAll(RegExp(r'[^0-9]'), '');
    final url = cleanPhone.isEmpty ? 'https://wa.me/?text=$text' : 'https://wa.me/$cleanPhone?text=$text';
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      await copyInvoiceText();
      toast(context, 'واتساپ باز نشد؛ متن فاکتور کپی شد');
    }
  }

  Future<void> addTx(String type) async {
    final ok = await showTransactionDialog(context, customerId: widget.customerId, type: type);
    if (ok == true) reload();
  }
}

class TransactionTile extends StatelessWidget {
  final Map<String, Object?> t;
  final VoidCallback? onDelete;
  const TransactionTile({super.key, required this.t, this.onDelete});

  @override
  Widget build(BuildContext context) {
    final type = t['type'].toString();
    final color = type == 'debt' ? Colors.orange : type == 'payment' ? Colors.green : Colors.blue;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: ProCard(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(typeIcon(type), color: color)),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${typeLabel(type)} - ${money(t['amount'] as int)}', style: const TextStyle(fontWeight: FontWeight.w900)),
                Text('تاریخ: ${faDate(t['dateIso']?.toString())}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                if ((t['reminderIso']?.toString() ?? '').isNotEmpty) Text('یادآوری: ${faDate(t['reminderIso']?.toString())}', style: const TextStyle(fontSize: 12, color: Colors.orange)),
                if ((t['note']?.toString() ?? '').isNotEmpty) Text(t['note'].toString(), style: const TextStyle(fontSize: 12)),
              ]),
            ),
            if (onDelete != null) IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline)),
          ],
        ),
      ),
    );
  }
}


// -------------------- Reminders / Reports --------------------

class RemindersPage extends StatefulWidget {
  const RemindersPage({super.key});

  @override
  State<RemindersPage> createState() => _RemindersPageState();
}

class _RemindersPageState extends State<RemindersPage> {
  Future<List<Map<String, Object?>>>? future;

  @override
  void initState() {
    super.initState();
    future = AppDb.remindersDue();
  }

  Future<void> reload() async {
    setState(() {
      future = AppDb.remindersDue();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'یادآوری‌ها',
      child: RefreshIndicator(
        onRefresh: reload,
        child: FutureBuilder<List<Map<String, Object?>>>(
          future: future,
          builder: (context, snap) {
            final list = snap.data ?? [];
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (list.isEmpty) {
              return const EmptyState(
                icon: Icons.notifications_none,
                title: 'یادآوری فعالی نیست',
                subtitle: 'برای بدهی‌ها تاریخ یادآوری بگذار تا اینجا نمایش داده شود.',
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final r = list[i];
                return ProCard(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.notifications_active)),
                    title: Text(r['customerName'].toString(), style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text('مبلغ: ${money(r['amount'] as int)}\nتاریخ یادآوری: ${faDate(r['reminderIso']?.toString())}'),
                    isThreeLine: true,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class ReportsPage extends StatefulWidget {
  ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  Future<Map<String, int>>? statsFuture;
  Future<List<Map<String, dynamic>>>? customersFuture;

  @override
  void initState() {
    super.initState();
    reload();
  }

  void reload() {
    statsFuture = AppDb.stats();
    customersFuture = AppDb.customerBalances();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'گزارش',
      child: RefreshIndicator(
        onRefresh: () async => reload(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            FutureBuilder<Map<String, int>>(
              future: statsFuture,
              builder: (context, snap) {
                final s = snap.data ?? {};
                return ProCard(
                  child: Column(
                    children: [
                      InfoLine(label: 'کل مشتری‌ها', value: fa('${s['customers'] ?? 0} نفر')),
                      InfoLine(label: 'کل بدهی‌ها', value: money(s['totalDebt'] ?? 0)),
                      InfoLine(label: 'بدهکارها', value: fa('${s['debtors'] ?? 0} نفر')),
                      InfoLine(label: 'تسویه‌ها', value: fa('${s['settled'] ?? 0} نفر')),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: copyFullReport,
              icon: const Icon(Icons.copy),
              label: const Text('کپی گزارش کامل'),
            ),
            const SizedBox(height: 12),
            Text('بیشترین بدهکارها', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: customersFuture,
              builder: (context, snap) {
                final list = snap.data ?? [];
                if (list.isEmpty) {
                  return const EmptyState(icon: Icons.bar_chart, title: 'داده‌ای برای گزارش نیست', subtitle: 'اول مشتری و تراکنش ثبت کن.');
                }
                return Column(
                  children: list.take(20).map((c) {
                    final b = c['balance'] as int;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ProCard(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            Expanded(child: Text(c['name'].toString(), style: const TextStyle(fontWeight: FontWeight.w900))),
                            Text(signedMoney(b), style: const TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> copyFullReport() async {
    final report = await AppDb.fullReportText();
    await Clipboard.setData(ClipboardData(text: report));
    if (mounted) toast(context, 'گزارش کامل کپی شد');
  }
}


// -------------------- Subscription --------------------

class SubscriptionPage extends StatefulWidget {
  final VoidCallback onChanged;
  const SubscriptionPage({super.key, required this.onChanged});
  @override
  State<SubscriptionPage> createState() => _SubscriptionPageState();
}

class _SubscriptionPageState extends State<SubscriptionPage> {
  Future<List<Map<String, Object?>>>? plansFuture;
  Future<String>? labelFuture;
  String supportPhone = '';
  String paymentCard = '';

  @override
  void initState() {
    super.initState();
    reload();
  }

  Future<void> reload() async {
    plansFuture = AppDb.plans();
    labelFuture = AppDb.accessLabel();
    supportPhone = await AppDb.getSetting('supportPhone') ?? '';
    paymentCard = await AppDb.getSetting('paymentCard') ?? '';
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'اشتراک',
      action: IconButton(icon: const Icon(Icons.admin_panel_settings_outlined), onPressed: openAdminPanel),
      child: FutureBuilder<List<Map<String, Object?>>>(
        future: plansFuture,
        builder: (context, snap) {
          final plans = snap.data ?? [];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              ProCard(
                child: Column(
                  children: [
                    const Icon(Icons.workspace_premium, size: 50, color: Colors.orange),
                    const SizedBox(height: 10),
                    FutureBuilder<String>(
                      future: labelFuture,
                      builder: (context, s) => Text(s.data ?? '', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16), textAlign: TextAlign.center),
                    ),
                    const SizedBox(height: 8),
                    const Text('بعد از پایان دوره رایگان ۳۰ روزه، برنامه برای ادامه استفاده اشتراک می‌خواهد.', textAlign: TextAlign.center),
                    if (paymentCard.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text('شماره کارت پرداخت: ${fa(paymentCard)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 12),
              ...plans.map((p) => PlanCard(plan: p, onBuy: () => buyPlan(p))),
            ],
          );
        },
      ),
    );
  }

  Future<void> buyPlan(Map<String, Object?> plan) async {
    final months = plan['months'] as int;
    final price = plan['price'] as int;
    final title = plan['title'].toString();

    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('مبلغ: ${money(price)}'),
              const SizedBox(height: 8),
              Text(paymentCard.isEmpty ? 'شماره کارت پرداخت هنوز توسط ادمین تنظیم نشده.' : 'پرداخت به کارت: ${fa(paymentCard)}', textAlign: TextAlign.center),
              const SizedBox(height: 12),
              if (supportPhone.isNotEmpty)
                FilledButton.icon(
                  onPressed: () async {
                    final text = Uri.encodeComponent('سلام، درخواست خرید $title به مبلغ ${money(price)} را دارم.');
                    await launchUrl(Uri.parse('https://wa.me/${enDigits(supportPhone).replaceAll(RegExp(r'[^0-9]'), '')}?text=$text'), mode: LaunchMode.externalApplication);
                  },
                  icon: const Icon(Icons.chat),
                  label: const Text('ارسال درخواست در واتساپ'),
                ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  Navigator.pop(context);
                  await activateWithAdmin(months);
                },
                icon: const Icon(Icons.admin_panel_settings),
                label: const Text('فعال‌سازی توسط ادمین بعد از پرداخت'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> activateWithAdmin(int months) async {
    final pin = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تأیید ادمین'),
          content: ProField(controller: pin, label: 'رمز ادمین', obscure: true, keyboardType: TextInputType.number),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('فعال‌سازی')),
          ],
        ),
      ),
    );

    if (ok != true) return;
    final saved = await AppDb.getSetting('adminPin');
    if (saved != enDigits(pin.text.trim())) {
      toast(context, 'رمز ادمین اشتباه است');
      return;
    }

    await AppDb.activateSubscription(months);
    await reload();
    widget.onChanged();
    toast(context, 'اشتراک فعال شد');
  }

  Future<void> openAdminPanel() async {
    final pin = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('ورود ادمین'),
          content: ProField(controller: pin, label: 'رمز ادمین', obscure: true, keyboardType: TextInputType.number),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ورود')),
          ],
        ),
      ),
    );

    if (ok != true) return;
    final saved = await AppDb.getSetting('adminPin');
    if (saved != enDigits(pin.text.trim())) {
      toast(context, 'رمز ادمین اشتباه است');
      return;
    }

    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminSubscriptionPage()));
    await reload();
    widget.onChanged();
  }
}

class PlanCard extends StatelessWidget {
  final Map<String, Object?> plan;
  final VoidCallback onBuy;
  const PlanCard({super.key, required this.plan, required this.onBuy});

  @override
  Widget build(BuildContext context) {
    final months = plan['months'] as int;
    final price = plan['price'] as int;
    final title = plan['title'].toString();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ProCard(
        child: Row(
          children: [
            CircleAvatar(backgroundColor: Colors.orange.withOpacity(.14), child: Text(fa('$months'), style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.w900))),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(money(price), style: const TextStyle(color: Colors.grey)),
              ]),
            ),
            FilledButton(onPressed: onBuy, child: const Text('خرید')),
          ],
        ),
      ),
    );
  }
}

class AdminSubscriptionPage extends StatefulWidget {
  const AdminSubscriptionPage({super.key});
  @override
  State<AdminSubscriptionPage> createState() => _AdminSubscriptionPageState();
}

class _AdminSubscriptionPageState extends State<AdminSubscriptionPage> {
  List<Map<String, Object?>> plans = [];
  final support = TextEditingController();
  final card = TextEditingController();
  final newPin = TextEditingController();

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    plans = await AppDb.plans();
    support.text = await AppDb.getSetting('supportPhone') ?? '';
    card.text = await AppDb.getSetting('paymentCard') ?? '';
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'پنل ادمین اشتراک',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('تنظیم قیمت پلن‌ها', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 10),
          ...plans.map((p) => PriceEditor(plan: p, onSaved: load)),
          const SizedBox(height: 16),
          ProCard(
            child: Column(
              children: [
                ProField(controller: card, label: 'شماره کارت پرداخت'),
                const SizedBox(height: 10),
                ProField(controller: support, label: 'شماره واتساپ پشتیبانی با کد کشور'),
                const SizedBox(height: 10),
                ProField(controller: newPin, label: 'رمز جدید ادمین اختیاری', obscure: true, keyboardType: TextInputType.number),
                const SizedBox(height: 12),
                FilledButton(onPressed: saveSettings, child: const Text('ذخیره تنظیمات ادمین')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> saveSettings() async {
    await AppDb.setSetting('paymentCard', enDigits(card.text.trim()));
    await AppDb.setSetting('supportPhone', enDigits(support.text.trim()));
    if (newPin.text.trim().isNotEmpty) {
      final p = enDigits(newPin.text.trim());
      if (!RegExp(r'^\d{4}$').hasMatch(p)) {
        toast(context, 'رمز ادمین باید ۴ رقم باشد');
        return;
      }
      await AppDb.setSetting('adminPin', p);
    }
    toast(context, 'تنظیمات ذخیره شد');
  }
}

class PriceEditor extends StatefulWidget {
  final Map<String, Object?> plan;
  final VoidCallback onSaved;
  const PriceEditor({super.key, required this.plan, required this.onSaved});
  @override
  State<PriceEditor> createState() => _PriceEditorState();
}

class _PriceEditorState extends State<PriceEditor> {
  late TextEditingController price;

  @override
  void initState() {
    super.initState();
    price = TextEditingController(text: '${widget.plan['price']}');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ProCard(
        child: Row(
          children: [
            Expanded(child: Text(widget.plan['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w900))),
            SizedBox(width: 125, child: TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت'))),
            IconButton(onPressed: save, icon: const Icon(Icons.save_outlined)),
          ],
        ),
      ),
    );
  }

  Future<void> save() async {
    final amount = cleanAmount(price.text);
    if (amount <= 0) {
      toast(context, 'قیمت درست نیست');
      return;
    }
    await AppDb.updatePlanPrice(widget.plan['id'] as int, amount);
    widget.onSaved();
    toast(context, 'قیمت ذخیره شد');
  }
}

// -------------------- Settings --------------------

class SettingsPage extends StatefulWidget {
  final VoidCallback onLogout;
  const SettingsPage({super.key, required this.onLogout});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final name = TextEditingController();
  final category = TextEditingController();
  final phone = TextEditingController();
  final pin = TextEditingController();
  int? businessId;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final b = await AppDb.activeBusiness();
    businessId = b?['id'] as int?;
    name.text = b?['name']?.toString() ?? '';
    category.text = b?['category']?.toString() ?? '';
    phone.text = b?['phone']?.toString() ?? '';
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(
      title: 'تنظیمات',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ProCard(
            child: Column(
              children: [
                ProField(controller: name, label: 'نام کسب‌وکار'),
                const SizedBox(height: 10),
                ProField(controller: category, label: 'دسته شغلی'),
                const SizedBox(height: 10),
                ProField(controller: phone, label: 'شماره تماس کسب‌وکار'),
                const SizedBox(height: 12),
                FilledButton(onPressed: saveBusiness, child: const Text('ذخیره اطلاعات کسب‌وکار')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          ProCard(
            child: Column(
              children: [
                ProField(controller: pin, label: 'رمز جدید ورود', obscure: true, keyboardType: TextInputType.number),
                const SizedBox(height: 12),
                OutlinedButton(onPressed: savePin, child: const Text('تغییر رمز ورود')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.tonalIcon(onPressed: widget.onLogout, icon: const Icon(Icons.lock_outline), label: const Text('قفل کردن و خروج')),
        ],
      ),
    );
  }

  Future<void> saveBusiness() async {
    if (businessId == null) return;
    await AppDb.updateBusiness(businessId!, name.text.trim(), category.text.trim(), phone.text.trim());
    toast(context, 'اطلاعات ذخیره شد');
  }

  Future<void> savePin() async {
    final p = enDigits(pin.text.trim());
    if (!RegExp(r'^\d{4}$').hasMatch(p)) {
      toast(context, 'رمز باید ۴ رقم باشد');
      return;
    }
    await AppDb.setSetting('pin', p);
    pin.clear();
    toast(context, 'رمز تغییر کرد');
  }
}

// -------------------- Dialogs --------------------

Future<bool?> showCustomerDialog(BuildContext context) {
  final name = TextEditingController();
  final phone = TextEditingController();
  final note = TextEditingController();

  return showDialog<bool>(
    context: context,
    builder: (context) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('افزودن مشتری'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ProField(controller: name, label: 'نام مشتری'),
              const SizedBox(height: 10),
              ProField(controller: phone, label: 'موبایل', keyboardType: TextInputType.phone),
              const SizedBox(height: 10),
              ProField(controller: note, label: 'یادداشت'),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              await AppDb.insertCustomer(name.text.trim(), phone.text.trim(), note.text.trim());
              if (context.mounted) Navigator.pop(context, true);
            },
            child: const Text('ذخیره'),
          ),
        ],
      ),
    ),
  );
}

Future<bool?> showTransactionDialog(BuildContext context, {required int customerId, required String type}) {
  final amount = TextEditingController();
  final date = TextEditingController(text: todayIso());
  final reminder = TextEditingController();
  final note = TextEditingController();
  var selectedType = type;

  return showDialog<bool>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, setState) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('ثبت تراکنش'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedType,
                  decoration: const InputDecoration(labelText: 'نوع تراکنش'),
                  items: const [
                    DropdownMenuItem(value: 'debt', child: Text('بدهی')),
                    DropdownMenuItem(value: 'payment', child: Text('پرداخت')),
                    DropdownMenuItem(value: 'discount', child: Text('تخفیف / اصلاح')),
                  ],
                  onChanged: (v) => setState(() => selectedType = v ?? selectedType),
                ),
                const SizedBox(height: 10),
                ProField(controller: amount, label: 'مبلغ به تومان', keyboardType: TextInputType.number),
                const SizedBox(height: 10),
                ProField(controller: date, label: 'تاریخ میلادی مثل 2026-06-14', keyboardType: TextInputType.datetime),
                const SizedBox(height: 10),
                ProField(controller: reminder, label: 'یادآوری اختیاری مثل 2026-07-01', keyboardType: TextInputType.datetime),
                const SizedBox(height: 10),
                ProField(controller: note, label: 'توضیح'),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(
              onPressed: () async {
                final a = cleanAmount(amount.text);
                if (a <= 0 || DateTime.tryParse(date.text.trim()) == null || (reminder.text.trim().isNotEmpty && DateTime.tryParse(reminder.text.trim()) == null)) {
                  toast(context, 'مبلغ یا تاریخ درست نیست');
                  return;
                }
                await AppDb.insertTransaction(
                  customerId: customerId,
                  type: selectedType,
                  amount: a,
                  dateIso: date.text.trim(),
                  reminderIso: reminder.text.trim().isEmpty ? null : reminder.text.trim(),
                  note: note.text.trim(),
                );
                if (context.mounted) Navigator.pop(context, true);
              },
              child: const Text('ثبت'),
            ),
          ],
        ),
      ),
    ),
  );
}

String typeLabel(String type) {
  if (type == 'debt') return 'بدهی';
  if (type == 'payment') return 'پرداخت';
  return 'تخفیف / اصلاح';
}

IconData typeIcon(String type) {
  if (type == 'debt') return Icons.trending_up;
  if (type == 'payment') return Icons.payments_outlined;
  return Icons.discount_outlined;
}

Future<bool> confirm(BuildContext context, String title, String message) async {
  return await showDialog<bool>(
        context: context,
        builder: (context) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text(title),
            content: Text(message),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('نه')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('بله')),
            ],
          ),
        ),
      ) ??
      false;
}

// -------------------- UI --------------------

class ProBackground extends StatelessWidget {
  final Widget child;
  const ProBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xffe0f7f4), Color(0xfff4fbfb), Colors.white]),
      ),
      child: child,
    );
  }
}

class ProScaffold extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? action;
  const ProScaffold({super.key, required this.title, required this.child, this.action});
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), actions: action == null ? null : [action!]),
        body: child,
      ),
    );
  }
}

class ProCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const ProCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: padding, child: child));
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 76,
        height: 76,
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xff00a98f), Color(0xff0ea5e9)]), borderRadius: BorderRadius.circular(26)),
        child: const Icon(Icons.account_balance_wallet, color: Colors.white, size: 38),
      ),
    );
  }
}

class ProField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool obscure;
  final TextInputType? keyboardType;
  const ProField({super.key, required this.controller, required this.label, this.obscure = false, this.keyboardType});
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      decoration: InputDecoration(labelText: label, filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)),
    );
  }
}

class InfoLine extends StatelessWidget {
  final String label;
  final String value;
  const InfoLine({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          const Spacer(),
          Flexible(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? button;
  final VoidCallback? onTap;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle, this.button, this.onTap});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 14),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            const SizedBox(height: 8),
            Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)),
            if (button != null) ...[const SizedBox(height: 16), FilledButton(onPressed: onTap, child: Text(button!))],
          ],
        ),
      ),
    );
  }
}
