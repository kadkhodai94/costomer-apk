# دفتر حساب مشتریان - Flutter

این پروژه نسخه Flutter اپ مدیریت حساب مشتریان است.

## امکانات نسخه فعلی

- ثبت اطلاعات کسب‌وکار
- ورود با رمز ۴ رقمی
- ثبت مشتری
- ثبت بدهی، پرداخت و تخفیف / اصلاح حساب
- تاریخ شمسی بدون نیاز به پکیج اضافه
- یادآوری بدهی‌ها
- وضعیت خودکار مشتری: بدهکار، تسویه، بستانکار
- جستجو و فیلتر
- ارسال صورتحساب در واتساپ
- خروجی JSON
- خروجی Word با فایل `.doc`
- خروجی Excel با فایل `.xls`
- خروجی PDF با پکیج `pdf` و `printing`

## نکته PDF فارسی

برای PDF فارسی از `PdfGoogleFonts.notoNaskhArabicRegular()` استفاده شده است. این روش برای دریافت فونت به اینترنت یا کش فونت نیاز دارد. اگر PDF در گوشی فارسی را درست نساخت، Word و Excel همچنان کار می‌کنند.

## گرفتن APK با GitHub Actions

1. یک ریپوی جدید بساز.
2. فایل‌های این ZIP را داخل ریپو آپلود کن.
3. از تب Actions، workflow با نام `Build Android APK` را اجرا کن.
4. بعد از اتمام، از بخش Artifacts فایل APK را دانلود کن.

## اجرای محلی

```bash
flutter pub get
flutter run
```

برای ساخت APK:

```bash
flutter build apk --release
```

## ساختار

- `lib/main.dart`: کل منطق و UI نسخه MVP
- `.github/workflows/build-apk.yml`: ساخت APK در GitHub
- `docs/flutter_next_steps.md`: قدم‌های بعدی برای حرفه‌ای‌تر شدن
