
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CustomerAccountApp());
}

class CustomerAccountApp extends StatefulWidget {
  const CustomerAccountApp({super.key});

  @override
  State<CustomerAccountApp> createState() => _CustomerAccountAppState();
}

class _CustomerAccountAppState extends State<CustomerAccountApp> {
  final AppStore store = AppStore();
  bool loading = true;
  bool loggedIn = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await store.load();
    setState(() => loading = false);
  }

  Future<void> _refresh() async {
    await store.save();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'دفتر حساب مشتریان',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xff10b981),
          primary: const Color(0xff10b981),
          secondary: const Color(0xff0ea5e9),
        ),
        scaffoldBackgroundColor: const Color(0xfff4fbfb),
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: loading
            ? const SplashView()
            : !store.settings.setupDone
                ? SetupView(store: store, onDone: () => setState(() => loggedIn = true))
                : !loggedIn
                    ? LoginView(store: store, onLogin: () => setState(() => loggedIn = true))
                    : MainShell(
                        store: store,
                        onChanged: _refresh,
                        onLogout: () => setState(() => loggedIn = false),
                      ),
      ),
    );
  }
}

class SplashView extends StatelessWidget {
  const SplashView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

class BusinessSettings {
  bool setupDone;
  String businessName;
  String businessCategory;
  String pin;

  BusinessSettings({
    required this.setupDone,
    required this.businessName,
    required this.businessCategory,
    required this.pin,
  });

  factory BusinessSettings.empty() => BusinessSettings(setupDone: false, businessName: '', businessCategory: '', pin: '');

  Map<String, dynamic> toJson() => {
        'setupDone': setupDone,
        'businessName': businessName,
        'businessCategory': businessCategory,
        'pin': pin,
      };

  factory BusinessSettings.fromJson(Map<String, dynamic> json) => BusinessSettings(
        setupDone: json['setupDone'] == true,
        businessName: (json['businessName'] ?? '').toString(),
        businessCategory: (json['businessCategory'] ?? '').toString(),
        pin: (json['pin'] ?? '').toString(),
      );
}

enum AccountTxType { debt, payment, discount }

class AccountTx {
  String id;
  AccountTxType type;
  int amount;
  DateTime date;
  DateTime? reminderDate;
  String note;
  DateTime createdAt;
  DateTime? updatedAt;

  AccountTx({
    required this.id,
    required this.type,
    required this.amount,
    required this.date,
    required this.reminderDate,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
  });

  int get signedAmount => type == AccountTxType.debt ? amount : -amount;

  String get label {
    switch (type) {
      case AccountTxType.debt:
        return 'بدهی';
      case AccountTxType.payment:
        return 'پرداخت';
      case AccountTxType.discount:
        return 'تخفیف / اصلاح';
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'amount': amount,
        'date': date.toIso8601String(),
        'reminderDate': reminderDate?.toIso8601String(),
        'note': note,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt?.toIso8601String(),
      };

  factory AccountTx.fromJson(Map<String, dynamic> json) => AccountTx(
        id: (json['id'] ?? DateTime.now().microsecondsSinceEpoch.toString()).toString(),
        type: AccountTxType.values.firstWhere((e) => e.name == json['type'], orElse: () => AccountTxType.debt),
        amount: _toInt(json['amount']),
        date: DateTime.tryParse((json['date'] ?? '').toString()) ?? DateTime.now(),
        reminderDate: DateTime.tryParse((json['reminderDate'] ?? '').toString()),
        note: (json['note'] ?? '').toString(),
        createdAt: DateTime.tryParse((json['createdAt'] ?? '').toString()) ?? DateTime.now(),
        updatedAt: DateTime.tryParse((json['updatedAt'] ?? '').toString()),
      );
}

class Customer {
  String id;
  String name;
  String phone;
  String note;
  DateTime createdAt;
  List<AccountTx> transactions;

  Customer({
    required this.id,
    required this.name,
    required this.phone,
    required this.note,
    required this.createdAt,
    required this.transactions,
  });

  int get balance => transactions.fold<int>(0, (sum, tx) => sum + tx.signedAmount);
  int get totalDebt => transactions.where((e) => e.type == AccountTxType.debt).fold<int>(0, (sum, tx) => sum + tx.amount);
  int get totalPaymentsAndDiscounts => transactions.where((e) => e.type != AccountTxType.debt).fold<int>(0, (sum, tx) => sum + tx.amount);
  bool get isDebtor => balance > 0;
  bool get isSettled => balance == 0;
  bool get isCreditor => balance < 0;

  String get statusLabel {
    if (isDebtor) return 'بدهکار';
    if (isCreditor) return 'بستانکار';
    return 'تسویه';
  }

  bool get hasTodayReminder {
    final today = DateUtils.dateOnly(DateTime.now());
    return isDebtor && transactions.any((tx) => tx.reminderDate != null && DateUtils.isSameDay(tx.reminderDate, today));
  }

  bool get hasOverdueReminder {
    final today = DateUtils.dateOnly(DateTime.now());
    return isDebtor && transactions.any((tx) {
      final r = tx.reminderDate;
      if (r == null) return false;
      return DateUtils.dateOnly(r).isBefore(today);
    });
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'note': note,
        'createdAt': createdAt.toIso8601String(),
        'transactions': transactions.map((e) => e.toJson()).toList(),
      };

  factory Customer.fromJson(Map<String, dynamic> json) => Customer(
        id: (json['id'] ?? DateTime.now().microsecondsSinceEpoch.toString()).toString(),
        name: (json['name'] ?? '').toString(),
        phone: (json['phone'] ?? '').toString(),
        note: (json['note'] ?? '').toString(),
        createdAt: DateTime.tryParse((json['createdAt'] ?? '').toString()) ?? DateTime.now(),
        transactions: ((json['transactions'] as List?) ?? [])
            .whereType<Map>()
            .map((e) => AccountTx.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class AppStore {
  static const String _storageKey = 'customer_account_flutter_v1';

  BusinessSettings settings = BusinessSettings.empty();
  List<Customer> customers = [];

  int get totalDebt => customers.fold<int>(0, (sum, c) => sum + (c.balance > 0 ? c.balance : 0));
  int get totalCredit => customers.fold<int>(0, (sum, c) => sum + (c.balance < 0 ? c.balance.abs() : 0));
  int get debtorsCount => customers.where((c) => c.isDebtor).length;
  int get settledCount => customers.where((c) => c.isSettled).length;
  int get creditCount => customers.where((c) => c.isCreditor).length;

  List<ReminderItem> get reminders {
    final today = DateUtils.dateOnly(DateTime.now());
    final items = <ReminderItem>[];
    for (final c in customers) {
      if (!c.isDebtor) continue;
      for (final tx in c.transactions) {
        final r = tx.reminderDate;
        if (r == null) continue;
        if (!DateUtils.dateOnly(r).isAfter(today)) {
          items.add(ReminderItem(customer: c, transaction: tx, overdue: DateUtils.dateOnly(r).isBefore(today)));
        }
      }
    }
    items.sort((a, b) => a.transaction.reminderDate!.compareTo(b.transaction.reminderDate!));
    return items;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.trim().isEmpty) return;
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      settings = BusinessSettings.fromJson(Map<String, dynamic>.from(decoded['settings'] ?? {}));
      customers = ((decoded['customers'] as List?) ?? [])
          .whereType<Map>()
          .map((e) => Customer.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      settings = BusinessSettings.empty();
      customers = [];
    }
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    final data = {
      'settings': settings.toJson(),
      'customers': customers.map((e) => e.toJson()).toList(),
    };
    await prefs.setString(_storageKey, const JsonEncoder.withIndent('  ').convert(data));
  }

  Future<void> reset() async {
    settings = BusinessSettings.empty();
    customers = [];
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_storageKey);
  }

  Map<String, dynamic> exportJson() => {
        'settings': settings.toJson(),
        'customers': customers.map((e) => e.toJson()).toList(),
      };

  Future<void> importJson(Map<String, dynamic> data) async {
    settings = BusinessSettings.fromJson(Map<String, dynamic>.from(data['settings'] ?? data));
    settings.setupDone = true;
    if (settings.pin.isEmpty) settings.pin = '1234';
    customers = ((data['customers'] as List?) ?? [])
        .whereType<Map>()
        .map((e) => Customer.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    await save();
  }
}

class ReminderItem {
  final Customer customer;
  final AccountTx transaction;
  final bool overdue;

  ReminderItem({required this.customer, required this.transaction, required this.overdue});
}

enum CustomerFilter { all, debtors, settled, credit, todayReminders, overdue }

class SetupView extends StatefulWidget {
  final AppStore store;
  final VoidCallback onDone;

  const SetupView({super.key, required this.store, required this.onDone});

  @override
  State<SetupView> createState() => _SetupViewState();
}

class _SetupViewState extends State<SetupView> {
  final businessName = TextEditingController();
  final businessCategory = TextEditingController();
  final pin = TextEditingController();
  final pinRepeat = TextEditingController();

  @override
  void dispose() {
    businessName.dispose();
    businessCategory.dispose();
    pin.dispose();
    pinRepeat.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (businessName.text.trim().isEmpty) return toast(context, 'نام کسب‌وکار را وارد کن');
    if (businessCategory.text.trim().isEmpty) return toast(context, 'دسته شغلی را وارد کن');
    if (!RegExp(r'^\d{4}$').hasMatch(pin.text.trim())) return toast(context, 'رمز باید ۴ رقم باشد');
    if (pin.text.trim() != pinRepeat.text.trim()) return toast(context, 'تکرار رمز درست نیست');

    widget.store.settings = BusinessSettings(
      setupDone: true,
      businessName: businessName.text.trim(),
      businessCategory: businessCategory.text.trim(),
      pin: pin.text.trim(),
    );
    await widget.store.save();
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AuthScaffold(
        title: 'دفتر حساب مشتریان',
        subtitle: 'اطلاعات کسب‌وکار و رمز ورود را ثبت کن.',
        child: Column(
          children: [
            AppTextField(controller: businessName, label: 'نام کسب‌وکار', hint: 'مثلاً کافه مهر'),
            AppTextField(controller: businessCategory, label: 'دسته شغلی', hint: 'مثلاً سوپرمارکت، باشگاه، سالن زیبایی'),
            Row(
              children: [
                Expanded(child: AppTextField(controller: pin, label: 'رمز ۴ رقمی', keyboardType: TextInputType.number, obscure: true, maxLength: 4)),
                const SizedBox(width: 10),
                Expanded(child: AppTextField(controller: pinRepeat, label: 'تکرار رمز', keyboardType: TextInputType.number, obscure: true, maxLength: 4)),
              ],
            ),
            const SizedBox(height: 14),
            FilledButton(onPressed: submit, child: const Text('ساخت دفتر حساب')),
          ],
        ),
      ),
    );
  }
}

class LoginView extends StatefulWidget {
  final AppStore store;
  final VoidCallback onLogin;

  const LoginView({super.key, required this.store, required this.onLogin});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final pin = TextEditingController();

  @override
  void dispose() {
    pin.dispose();
    super.dispose();
  }

  void submit() {
    if (pin.text.trim() == widget.store.settings.pin) {
      widget.onLogin();
    } else {
      toast(context, 'رمز اشتباه است');
    }
  }

  Future<void> reset() async {
    final ok = await confirm(context, 'همه اطلاعات حذف شود و از اول شروع کنی؟');
    if (!ok) return;
    await widget.store.reset();
    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const CustomerAccountApp()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AuthScaffold(
        title: widget.store.settings.businessName,
        subtitle: '${widget.store.settings.businessCategory} · رمز ورود را وارد کن',
        child: Column(
          children: [
            AppTextField(
              controller: pin,
              label: 'رمز ورود',
              keyboardType: TextInputType.number,
              obscure: true,
              maxLength: 4,
              onSubmitted: (_) => submit(),
            ),
            const SizedBox(height: 14),
            FilledButton(onPressed: submit, child: const Text('ورود')),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: reset, child: const Text('فراموشی رمز / شروع دوباره')),
          ],
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  final AppStore store;
  final Future<void> Function() onChanged;
  final VoidCallback onLogout;

  const MainShell({super.key, required this.store, required this.onChanged, required this.onLogout});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  String search = '';
  CustomerFilter filter = CustomerFilter.all;

  Future<void> saveAndRefresh() async {
    await widget.onChanged();
    setState(() {});
  }

  List<Customer> get filteredCustomers {
    var list = [...widget.store.customers];

    if (search.trim().isNotEmpty) {
      final q = search.trim().toLowerCase();
      list = list.where((c) => c.name.toLowerCase().contains(q) || c.phone.contains(q) || c.note.toLowerCase().contains(q)).toList();
    }

    switch (filter) {
      case CustomerFilter.all:
        break;
      case CustomerFilter.debtors:
        list = list.where((c) => c.isDebtor).toList();
        break;
      case CustomerFilter.settled:
        list = list.where((c) => c.isSettled).toList();
        break;
      case CustomerFilter.credit:
        list = list.where((c) => c.isCreditor).toList();
        break;
      case CustomerFilter.todayReminders:
        list = list.where((c) => c.hasTodayReminder).toList();
        break;
      case CustomerFilter.overdue:
        list = list.where((c) => c.hasOverdueReminder).toList();
        break;
    }

    list.sort((a, b) => b.balance.compareTo(a.balance));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        store: widget.store,
        customers: filteredCustomers,
        searchChanged: (v) => setState(() => search = v),
        filter: filter,
        onFilter: (v) => setState(() => filter = v),
        onChanged: saveAndRefresh,
      ),
      CustomerFormShortcut(store: widget.store, onChanged: saveAndRefresh),
      RemindersPage(store: widget.store, onChanged: saveAndRefresh),
      ReportsPage(store: widget.store, onChanged: saveAndRefresh),
    ];

    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) async {
          if (i == 1) {
            await showCustomerForm(context, widget.store, onChanged: saveAndRefresh);
            setState(() => tab = 0);
          } else {
            setState(() => tab = i);
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'ثبت'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'یادآوری'),
          NavigationDestination(icon: Icon(Icons.bar_chart), selectedIcon: Icon(Icons.bar_chart), label: 'گزارش'),
        ],
      ),
      floatingActionButton: tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => showCustomerForm(context, widget.store, onChanged: saveAndRefresh),
              icon: const Icon(Icons.person_add_alt),
              label: const Text('مشتری'),
            )
          : null,
    );
  }
}

class HomePage extends StatelessWidget {
  final AppStore store;
  final List<Customer> customers;
  final ValueChanged<String> searchChanged;
  final CustomerFilter filter;
  final ValueChanged<CustomerFilter> onFilter;
  final Future<void> Function() onChanged;

  const HomePage({
    super.key,
    required this.store,
    required this.customers,
    required this.searchChanged,
    required this.filter,
    required this.onFilter,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        children: [
          DashboardHeader(store: store, onChanged: onChanged),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: searchChanged,
                  decoration: inputDecoration('جستجوی مشتری...', icon: Icons.search),
                ),
              ),
              const SizedBox(width: 10),
              FilledButton.icon(
                onPressed: () => showCustomerForm(context, store, onChanged: onChanged),
                icon: const Icon(Icons.add),
                label: const Text('مشتری'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: CustomerFilter.values.map((f) {
                return Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ChoiceChip(
                    label: Text(filterLabel(f)),
                    selected: filter == f,
                    onSelected: (_) => onFilter(f),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Text('لیست مشتری‌ها', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const Spacer(),
              Text('${fa(customers.length)} مورد', style: const TextStyle(color: Colors.grey)),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: customers.isEmpty
                ? const EmptyBox(text: 'موردی برای نمایش نیست.\nمشتری جدید اضافه کن یا فیلتر را تغییر بده.')
                : ListView.separated(
                    itemCount: customers.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => CustomerCard(customer: customers[i], store: store, onChanged: onChanged),
                  ),
          ),
        ],
      ),
    );
  }
}

class DashboardHeader extends StatelessWidget {
  final AppStore store;
  final Future<void> Function() onChanged;

  const DashboardHeader({super.key, required this.store, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xff10b981), Color(0xff0ea5e9)]),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [BoxShadow(color: Color(0x2010b981), blurRadius: 24, offset: Offset(0, 10))],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(store.settings.businessName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(999)),
                    child: Text(store.settings.businessCategory, style: const TextStyle(color: Colors.white)),
                  ),
                ]),
              ),
              IconButton.filledTonal(
                onPressed: () => showSettings(context, store, onChanged: onChanged),
                icon: const Icon(Icons.edit),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: StatBox(label: 'کل بدهی‌ها', value: toman(store.totalDebt), bright: true)),
              const SizedBox(width: 10),
              Expanded(child: StatBox(label: 'مشتری‌ها', value: '${fa(store.customers.length)} نفر', bright: true)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: StatBox(label: 'بدهکار', value: fa(store.debtorsCount), mini: true)),
              const SizedBox(width: 8),
              Expanded(child: StatBox(label: 'تسویه', value: fa(store.settledCount), mini: true)),
              const SizedBox(width: 8),
              Expanded(child: StatBox(label: 'یادآوری', value: fa(store.reminders.length), mini: true)),
            ],
          ),
        ],
      ),
    );
  }
}

class StatBox extends StatelessWidget {
  final String label;
  final String value;
  final bool bright;
  final bool mini;

  const StatBox({super.key, required this.label, required this.value, this.bright = false, this.mini = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(mini ? 10 : 12),
      decoration: BoxDecoration(
        color: bright ? Colors.white.withOpacity(.18) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: bright ? Colors.white.withOpacity(.25) : const Color(0xffdbeafe)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: bright ? Colors.white.withOpacity(.9) : Colors.grey, fontSize: mini ? 10 : 11)),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(color: bright ? Colors.white : const Color(0xff0f172a), fontWeight: FontWeight.w900, fontSize: mini ? 13 : 16)),
        ],
      ),
    );
  }
}

class CustomerCard extends StatelessWidget {
  final Customer customer;
  final AppStore store;
  final Future<void> Function() onChanged;

  const CustomerCard({super.key, required this.customer, required this.store, required this.onChanged});

  Color get statusColor {
    if (customer.isDebtor) return const Color(0xfff59e0b);
    if (customer.isCreditor) return const Color(0xff0ea5e9);
    return const Color(0xff10b981);
  }

  @override
  Widget build(BuildContext context) {
    final last = customer.transactions.isEmpty ? null : customer.transactions.last;
    return InkWell(
      onTap: () => showCustomerDetails(context, store, customer, onChanged: onChanged),
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: cardDecoration(),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xffd1fae5),
                  foregroundColor: const Color(0xff059669),
                  child: Text(customer.name.isEmpty ? 'م' : customer.name.substring(0, 1)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(customer.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 3),
                    Text(
                      '${customer.phone.isNotEmpty ? 'موبایل: ${fa(customer.phone)}\n' : ''}${last == null ? 'بدون تراکنش' : 'آخرین ثبت: ${jalaliText(last.date)}'}',
                      style: const TextStyle(color: Colors.grey, height: 1.6, fontSize: 12),
                    ),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(.10),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: statusColor.withOpacity(.35)),
                  ),
                  child: Text(
                    customer.isSettled ? 'تسویه' : balanceText(customer.balance),
                    style: TextStyle(color: statusColor, fontWeight: FontWeight.w900, fontSize: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                StatusChip(label: customer.statusLabel, color: statusColor),
                if (customer.hasTodayReminder) const StatusChip(label: 'یادآوری امروز', color: Color(0xfff59e0b)),
                if (customer.hasOverdueReminder) const StatusChip(label: 'عقب‌افتاده', color: Color(0xffef4444)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: SmallActionButton(label: '+ بدهی', color: const Color(0xfff59e0b), onTap: () => showTransactionForm(context, store, customer, initialType: AccountTxType.debt, onChanged: onChanged))),
                const SizedBox(width: 8),
                Expanded(child: SmallActionButton(label: 'پرداخت', color: const Color(0xff10b981), onTap: () => showTransactionForm(context, store, customer, initialType: AccountTxType.payment, onChanged: onChanged))),
                const SizedBox(width: 8),
                Expanded(child: SmallActionButton(label: 'جزئیات', color: const Color(0xff0ea5e9), onTap: () => showCustomerDetails(context, store, customer, onChanged: onChanged))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String label;
  final Color color;

  const StatusChip({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(999), border: Border.all(color: color.withOpacity(.30))),
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 11)),
    );
  }
}

class SmallActionButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;

  const SmallActionButton({super.key, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return FilledButton(
      style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
      onPressed: onTap,
      child: Text(label, style: const TextStyle(fontSize: 12)),
    );
  }
}

class CustomerFormShortcut extends StatefulWidget {
  final AppStore store;
  final Future<void> Function() onChanged;

  const CustomerFormShortcut({super.key, required this.store, required this.onChanged});

  @override
  State<CustomerFormShortcut> createState() => _CustomerFormShortcutState();
}

class _CustomerFormShortcutState extends State<CustomerFormShortcut> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => showCustomerForm(context, widget.store, onChanged: widget.onChanged));
  }

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('ثبت مشتری'));
  }
}

class RemindersPage extends StatelessWidget {
  final AppStore store;
  final Future<void> Function() onChanged;

  const RemindersPage({super.key, required this.store, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DashboardHeader(store: store, onChanged: onChanged),
          const SizedBox(height: 14),
          const Text('یادآوری‌ها', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          const SizedBox(height: 8),
          Expanded(
            child: store.reminders.isEmpty
                ? const EmptyBox(text: 'برای امروز یا تاریخ‌های گذشته یادآوری فعالی نیست.')
                : ListView.separated(
                    itemCount: store.reminders.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final item = store.reminders[i];
                      return Container(
                        decoration: cardDecoration(),
                        padding: const EdgeInsets.all(14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(child: Text(item.customer.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
                            StatusChip(label: item.overdue ? 'عقب‌افتاده' : 'امروز', color: item.overdue ? const Color(0xffef4444) : const Color(0xfff59e0b)),
                          ]),
                          const SizedBox(height: 8),
                          Text('مانده حساب: ${balanceText(item.customer.balance)}', style: const TextStyle(color: Colors.grey)),
                          Text('تاریخ یادآوری: ${jalaliText(item.transaction.reminderDate!)}', style: const TextStyle(color: Colors.grey)),
                          if (item.transaction.note.isNotEmpty) Text(item.transaction.note, style: const TextStyle(color: Colors.grey)),
                          const SizedBox(height: 10),
                          Row(children: [
                            Expanded(child: SmallActionButton(label: 'ثبت پرداخت', color: const Color(0xff10b981), onTap: () => showTransactionForm(context, store, item.customer, initialType: AccountTxType.payment, onChanged: onChanged))),
                            const SizedBox(width: 8),
                            Expanded(child: SmallActionButton(label: 'جزئیات', color: const Color(0xff0ea5e9), onTap: () => showCustomerDetails(context, store, item.customer, onChanged: onChanged))),
                          ]),
                        ]),
                      );
                    },
                  ),
          )
        ],
      ),
    );
  }
}

class ReportsPage extends StatelessWidget {
  final AppStore store;
  final Future<void> Function() onChanged;

  const ReportsPage({super.key, required this.store, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: ListView(
        children: [
          DashboardHeader(store: store, onChanged: onChanged),
          const SizedBox(height: 14),
          Container(
            decoration: cardDecoration(),
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('گزارش کلی', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 10),
              ReportLine(label: 'نام کسب‌وکار', value: store.settings.businessName),
              ReportLine(label: 'دسته شغلی', value: store.settings.businessCategory),
              ReportLine(label: 'کل بدهی‌ها', value: toman(store.totalDebt)),
              ReportLine(label: 'کل بستانکاری', value: toman(store.totalCredit)),
              ReportLine(label: 'مشتری بدهکار', value: '${fa(store.debtorsCount)} نفر'),
              ReportLine(label: 'تسویه', value: '${fa(store.settledCount)} نفر'),
              ReportLine(label: 'بستانکار', value: '${fa(store.creditCount)} نفر'),
              ReportLine(label: 'یادآوری فعال', value: '${fa(store.reminders.length)} مورد'),
            ]),
          ),
          const SizedBox(height: 12),
          ExportButtons(store: store),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => importBackup(context, store, onChanged),
            icon: const Icon(Icons.restore),
            label: const Text('بازیابی بکاپ JSON از متن کپی‌شده'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => showSettings(context, store, onChanged: onChanged),
            icon: const Icon(Icons.settings),
            label: const Text('تنظیمات'),
          ),
        ],
      ),
    );
  }
}

class ExportButtons extends StatelessWidget {
  final AppStore store;
  final Customer? customer;

  const ExportButtons({super.key, required this.store, this.customer});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: cardDecoration(),
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(customer == null ? 'خروجی کل اطلاعات' : 'خروجی ${customer!.name}', style: const TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.icon(onPressed: () => exportJson(context, store), icon: const Icon(Icons.data_object), label: const Text('JSON')),
            FilledButton.icon(onPressed: () => exportPdf(context, store, customer: customer), icon: const Icon(Icons.picture_as_pdf), label: const Text('PDF')),
            FilledButton.icon(onPressed: () => exportHtmlDoc(context, store, customer: customer, extension: 'doc'), icon: const Icon(Icons.description), label: const Text('Word')),
            FilledButton.icon(onPressed: () => exportHtmlDoc(context, store, customer: customer, extension: 'xls'), icon: const Icon(Icons.table_chart), label: const Text('Excel')),
          ],
        ),
      ]),
    );
  }
}

class ReportLine extends StatelessWidget {
  final String label;
  final String value;

  const ReportLine({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xffeef6f8)))),
      child: Row(children: [
        Text(label, style: const TextStyle(color: Colors.grey)),
        const Spacer(),
        Flexible(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w900), textAlign: TextAlign.end)),
      ]),
    );
  }
}

class AppShell extends StatelessWidget {
  final Widget child;

  const AppShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 0), child: child);
  }
}

class AuthScaffold extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const AuthScaffold({super.key, required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(maxWidth: 460),
          padding: const EdgeInsets.all(22),
          decoration: cardDecoration(radius: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 74,
                height: 74,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xff10b981), Color(0xff0ea5e9)]),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Center(child: Text('ح', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 32))),
              ),
              const SizedBox(height: 16),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 23)),
              const SizedBox(height: 8),
              Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, height: 1.8)),
              const SizedBox(height: 18),
              child,
            ],
          ),
        ),
      ),
    );
  }
}

class AppTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final bool obscure;
  final int? maxLength;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onSubmitted;
  final int maxLines;

  const AppTextField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.obscure = false,
    this.maxLength,
    this.keyboardType,
    this.onSubmitted,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        maxLength: maxLength,
        keyboardType: keyboardType,
        maxLines: obscure ? 1 : maxLines,
        onSubmitted: onSubmitted,
        decoration: inputDecoration(label, hint: hint),
      ),
    );
  }
}

class EmptyBox extends StatelessWidget {
  final String text;

  const EmptyBox({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xffbae6fd), style: BorderStyle.solid),
      ),
      child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, height: 1.9)),
    );
  }
}

Future<void> showCustomerForm(BuildContext context, AppStore store, {Customer? customer, required Future<void> Function() onChanged}) async {
  final name = TextEditingController(text: customer?.name ?? '');
  final phone = TextEditingController(text: customer?.phone ?? '');
  final note = TextEditingController(text: customer?.note ?? '');

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(customer == null ? 'افزودن مشتری' : 'ویرایش مشتری', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              AppTextField(controller: name, label: 'نام مشتری', hint: 'مثلاً محمد کدخدایی'),
              AppTextField(controller: phone, label: 'شماره موبایل اختیاری', keyboardType: TextInputType.phone),
              AppTextField(controller: note, label: 'آدرس یا توضیح اختیاری', maxLines: 3),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () async {
                  if (name.text.trim().isEmpty) {
                    toast(ctx, 'نام مشتری را وارد کن');
                    return;
                  }

                  if (customer == null) {
                    store.customers.add(Customer(
                      id: newId(),
                      name: name.text.trim(),
                      phone: phone.text.trim(),
                      note: note.text.trim(),
                      createdAt: DateTime.now(),
                      transactions: [],
                    ));
                  } else {
                    customer.name = name.text.trim();
                    customer.phone = phone.text.trim();
                    customer.note = note.text.trim();
                  }

                  await onChanged();
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('ذخیره مشتری'),
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      );
    },
  );

  name.dispose();
  phone.dispose();
  note.dispose();
}

Future<void> showTransactionForm(
  BuildContext context,
  AppStore store,
  Customer customer, {
  AccountTx? tx,
  AccountTxType initialType = AccountTxType.debt,
  required Future<void> Function() onChanged,
}) async {
  AccountTxType type = tx?.type ?? initialType;
  final amount = TextEditingController(text: tx?.amount.toString() ?? '');
  final date = TextEditingController(text: jalaliText(tx?.date ?? DateTime.now()));
  final reminder = TextEditingController(text: tx?.reminderDate == null ? '' : jalaliText(tx!.reminderDate!));
  final note = TextEditingController(text: tx?.note ?? '');

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) {
      return StatefulBuilder(builder: (ctx, setLocal) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tx == null ? 'ثبت تراکنش برای ${customer.name}' : 'ویرایش تراکنش', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 10),
                DropdownButtonFormField<AccountTxType>(
                  value: type,
                  items: const [
                    DropdownMenuItem(value: AccountTxType.debt, child: Text('بدهی')),
                    DropdownMenuItem(value: AccountTxType.payment, child: Text('پرداخت')),
                    DropdownMenuItem(value: AccountTxType.discount, child: Text('تخفیف / اصلاح حساب')),
                  ],
                  onChanged: (v) => setLocal(() => type = v ?? type),
                  decoration: inputDecoration('نوع تراکنش'),
                ),
                AppTextField(controller: amount, label: 'مبلغ به تومان', keyboardType: TextInputType.number),
                Row(children: [
                  Expanded(child: AppTextField(controller: date, label: 'تاریخ شمسی', hint: '۱۴۰۳/۰۳/۲۳')),
                  const SizedBox(width: 10),
                  Expanded(child: AppTextField(controller: reminder, label: 'یادآوری شمسی', hint: 'اختیاری')),
                ]),
                AppTextField(controller: note, label: 'توضیح', maxLines: 3),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () async {
                    final parsedAmount = parseMoney(amount.text);
                    final parsedDate = JalaliUtil.parse(date.text);
                    final parsedReminder = reminder.text.trim().isEmpty ? null : JalaliUtil.parse(reminder.text);

                    if (parsedAmount <= 0) return toast(ctx, 'مبلغ را درست وارد کن');
                    if (parsedDate == null) return toast(ctx, 'تاریخ شمسی درست نیست');
                    if (reminder.text.trim().isNotEmpty && parsedReminder == null) return toast(ctx, 'تاریخ یادآوری درست نیست');

                    if (tx == null) {
                      customer.transactions.add(AccountTx(
                        id: newId(),
                        type: type,
                        amount: parsedAmount,
                        date: parsedDate,
                        reminderDate: parsedReminder,
                        note: note.text.trim(),
                        createdAt: DateTime.now(),
                        updatedAt: null,
                      ));
                    } else {
                      tx.type = type;
                      tx.amount = parsedAmount;
                      tx.date = parsedDate;
                      tx.reminderDate = parsedReminder;
                      tx.note = note.text.trim();
                      tx.updatedAt = DateTime.now();
                    }

                    await onChanged();
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: Text(tx == null ? 'ثبت' : 'ذخیره ویرایش'),
                ),
                const SizedBox(height: 16),
              ]),
            ),
          ),
        );
      });
    },
  );

  amount.dispose();
  date.dispose();
  reminder.dispose();
  note.dispose();
}

Future<void> showCustomerDetails(BuildContext context, AppStore store, Customer customer, {required Future<void> Function() onChanged}) async {
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) {
      return StatefulBuilder(builder: (ctx, setLocal) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
            child: SizedBox(
              height: MediaQuery.of(ctx).size.height * .86,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(customer.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20))),
                  IconButton(onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close)),
                ]),
                Container(
                  decoration: cardDecoration(),
                  padding: const EdgeInsets.all(14),
                  child: Column(children: [
                    ReportLine(label: 'وضعیت', value: customer.statusLabel),
                    ReportLine(label: 'مانده حساب', value: balanceText(customer.balance)),
                    ReportLine(label: 'مجموع بدهی', value: toman(customer.totalDebt)),
                    ReportLine(label: 'مجموع پرداخت / تخفیف', value: toman(customer.totalPaymentsAndDiscounts)),
                    ReportLine(label: 'موبایل', value: customer.phone.isEmpty ? '-' : fa(customer.phone)),
                    if (customer.note.isNotEmpty) ReportLine(label: 'توضیح', value: customer.note),
                  ]),
                ),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  FilledButton(onPressed: () => showTransactionForm(ctx, store, customer, initialType: AccountTxType.debt, onChanged: () async { await onChanged(); setLocal(() {}); }), child: const Text('+ بدهی')),
                  FilledButton(onPressed: () => showTransactionForm(ctx, store, customer, initialType: AccountTxType.payment, onChanged: () async { await onChanged(); setLocal(() {}); }), child: const Text('پرداخت')),
                  OutlinedButton(onPressed: () => shareWhatsApp(customer, store), child: const Text('واتساپ')),
                  OutlinedButton(onPressed: () => showCustomerForm(ctx, store, customer: customer, onChanged: () async { await onChanged(); setLocal(() {}); }), child: const Text('ویرایش')),
                ]),
                const SizedBox(height: 10),
                ExportButtons(store: store, customer: customer),
                const SizedBox(height: 10),
                const Text('ریز تراکنش‌ها', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Expanded(
                  child: customer.transactions.isEmpty
                      ? const EmptyBox(text: 'هنوز بدهی یا پرداختی ثبت نشده.')
                      : ListView.separated(
                          itemCount: customer.transactions.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (_, i) {
                            final tx = customer.transactions.reversed.toList()[i];
                            final color = tx.type == AccountTxType.debt ? const Color(0xffef4444) : const Color(0xff10b981);
                            return Container(
                              decoration: cardDecoration(radius: 18),
                              padding: const EdgeInsets.all(12),
                              child: Row(children: [
                                Expanded(
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text('${tx.label}: ${toman(tx.amount)}', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
                                    const SizedBox(height: 4),
                                    Text('تاریخ: ${jalaliText(tx.date)}${tx.reminderDate == null ? '' : '\nیادآوری: ${jalaliText(tx.reminderDate!)}'}${tx.note.isEmpty ? '' : '\n${tx.note}'}',
                                        style: const TextStyle(color: Colors.grey, height: 1.6, fontSize: 12)),
                                  ]),
                                ),
                                Column(children: [
                                  IconButton(
                                    onPressed: () => showTransactionForm(ctx, store, customer, tx: tx, onChanged: () async { await onChanged(); setLocal(() {}); }),
                                    icon: const Icon(Icons.edit),
                                  ),
                                  IconButton(
                                    onPressed: () async {
                                      final ok = await confirm(ctx, 'این تراکنش حذف شود؟');
                                      if (!ok) return;
                                      customer.transactions.removeWhere((e) => e.id == tx.id);
                                      await onChanged();
                                      setLocal(() {});
                                    },
                                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                                  ),
                                ]),
                              ]),
                            );
                          },
                        ),
                ),
                TextButton.icon(
                  onPressed: () async {
                    final ok = await confirm(ctx, 'این مشتری کامل حذف شود؟');
                    if (!ok) return;
                    store.customers.removeWhere((e) => e.id == customer.id);
                    await onChanged();
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  icon: const Icon(Icons.delete, color: Colors.red),
                  label: const Text('حذف کامل مشتری', style: TextStyle(color: Colors.red)),
                ),
              ]),
            ),
          ),
        );
      });
    },
  );
}

Future<void> showSettings(BuildContext context, AppStore store, {required Future<void> Function() onChanged}) async {
  final name = TextEditingController(text: store.settings.businessName);
  final category = TextEditingController(text: store.settings.businessCategory);
  final pin = TextEditingController();
  final pinRepeat = TextEditingController();

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              const Text('تنظیمات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              AppTextField(controller: name, label: 'نام کسب‌وکار'),
              AppTextField(controller: category, label: 'دسته شغلی'),
              Row(children: [
                Expanded(child: AppTextField(controller: pin, label: 'رمز جدید', obscure: true, keyboardType: TextInputType.number, maxLength: 4)),
                const SizedBox(width: 10),
                Expanded(child: AppTextField(controller: pinRepeat, label: 'تکرار رمز', obscure: true, keyboardType: TextInputType.number, maxLength: 4)),
              ]),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () async {
                  if (name.text.trim().isEmpty || category.text.trim().isEmpty) return toast(ctx, 'نام و دسته شغلی را وارد کن');
                  if (pin.text.trim().isNotEmpty || pinRepeat.text.trim().isNotEmpty) {
                    if (!RegExp(r'^\d{4}$').hasMatch(pin.text.trim())) return toast(ctx, 'رمز جدید باید ۴ رقم باشد');
                    if (pin.text.trim() != pinRepeat.text.trim()) return toast(ctx, 'تکرار رمز درست نیست');
                    store.settings.pin = pin.text.trim();
                  }
                  store.settings.businessName = name.text.trim();
                  store.settings.businessCategory = category.text.trim();
                  await onChanged();
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('ذخیره تنظیمات'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () async {
                  final ok = await confirm(ctx, 'همه اطلاعات اپ حذف شود؟');
                  if (!ok) return;
                  await store.reset();
                  if (ctx.mounted) {
                    Navigator.of(ctx).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const CustomerAccountApp()),
                      (_) => false,
                    );
                  }
                },
                icon: const Icon(Icons.delete_forever, color: Colors.red),
                label: const Text('حذف همه اطلاعات', style: TextStyle(color: Colors.red)),
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      );
    },
  );

  name.dispose();
  category.dispose();
  pin.dispose();
  pinRepeat.dispose();
}

Future<void> importBackup(BuildContext context, AppStore store, Future<void> Function() onChanged) async {
  final controller = TextEditingController();
  await showDialog(
    context: context,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('بازیابی بکاپ JSON'),
        content: TextField(
          controller: controller,
          maxLines: 8,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'محتوای فایل JSON را اینجا کپی کن...',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
          FilledButton(
            onPressed: () async {
              try {
                final decoded = jsonDecode(controller.text.trim()) as Map<String, dynamic>;
                await store.importJson(decoded);
                await onChanged();
                if (ctx.mounted) Navigator.pop(ctx);
                if (context.mounted) toast(context, 'بکاپ بازیابی شد');
              } catch (_) {
                toast(ctx, 'JSON معتبر نیست');
              }
            },
            child: const Text('بازیابی'),
          ),
        ],
      ),
    ),
  );
  controller.dispose();
}

Future<void> shareWhatsApp(Customer customer, AppStore store) async {
  final text = '${customer.name} عزیز\nصورتحساب شما در ${store.settings.businessName}\n\n'
      'وضعیت: ${customer.statusLabel}\n'
      'مانده حساب: ${balanceText(customer.balance)}\n'
      'تاریخ: ${jalaliText(DateTime.now())}\n\n'
      'با تشکر';
  final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}

Future<void> exportJson(BuildContext context, AppStore store) async {
  final content = const JsonEncoder.withIndent('  ').convert(store.exportJson());
  final file = await writeTempFile('customer-account-backup.json', content);
  await Share.shareXFiles([XFile(file.path)], text: 'بکاپ JSON دفتر حساب مشتریان');
}

Future<void> exportHtmlDoc(BuildContext context, AppStore store, {Customer? customer, required String extension}) async {
  final html = customer == null ? fullReportHtml(store) : customerReportHtml(store, customer);
  final fileName = customer == null ? 'customer-account-report.$extension' : 'hesab-${safeFile(customer.name)}.$extension';
  final file = await writeTempFile(fileName, html);
  await Share.shareXFiles([XFile(file.path)], text: extension == 'xls' ? 'خروجی Excel' : 'خروجی Word');
}

Future<void> exportPdf(BuildContext context, AppStore store, {Customer? customer}) async {
  try {
    final font = await PdfGoogleFonts.notoNaskhArabicRegular();
    final doc = pw.Document();

    doc.addPage(
      pw.MultiPage(
        textDirection: pw.TextDirection.rtl,
        theme: pw.ThemeData.withFont(base: font, bold: font),
        pageFormat: PdfPageFormat.a4,
        build: (pdfContext) => customer == null ? buildFullPdf(store) : buildCustomerPdf(store, customer),
      ),
    );

    await Printing.sharePdf(
      bytes: await doc.save(),
      filename: customer == null ? 'customer-account-report.pdf' : 'hesab-${safeFile(customer.name)}.pdf',
    );
  } catch (e) {
    if (context.mounted) toast(context, 'ساخت PDF به اینترنت یا کش فونت نیاز دارد. Word/Excel را استفاده کن.');
  }
}

List<pw.Widget> buildFullPdf(AppStore store) {
  return [
    pw.Text('گزارش کامل حساب مشتریان', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
    pw.SizedBox(height: 10),
    pw.Text('${store.settings.businessName} - ${store.settings.businessCategory}'),
    pw.SizedBox(height: 14),
    pw.TableHelper.fromTextArray(
      headers: ['عنوان', 'مقدار'],
      data: [
        ['تاریخ خروجی', jalaliText(DateTime.now())],
        ['تعداد مشتری‌ها', fa(store.customers.length)],
        ['کل بدهی‌ها', toman(store.totalDebt)],
        ['کل بستانکاری', toman(store.totalCredit)],
        ['مشتری بدهکار', fa(store.debtorsCount)],
        ['تسویه', fa(store.settledCount)],
      ],
    ),
    pw.SizedBox(height: 20),
    pw.Text('لیست مشتری‌ها', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16)),
    pw.TableHelper.fromTextArray(
      headers: ['نام', 'موبایل', 'مانده', 'تراکنش'],
      data: store.customers.map((c) => [c.name, c.phone, balanceText(c.balance), fa(c.transactions.length)]).toList(),
    ),
  ];
}

List<pw.Widget> buildCustomerPdf(AppStore store, Customer c) {
  return [
    pw.Text('صورتحساب مشتری', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
    pw.SizedBox(height: 10),
    pw.Text('${store.settings.businessName} - ${store.settings.businessCategory}'),
    pw.SizedBox(height: 14),
    pw.TableHelper.fromTextArray(
      headers: ['عنوان', 'مقدار'],
      data: [
        ['نام مشتری', c.name],
        ['موبایل', c.phone],
        ['وضعیت', c.statusLabel],
        ['مانده حساب', balanceText(c.balance)],
        ['مجموع بدهی', toman(c.totalDebt)],
        ['مجموع پرداخت / تخفیف', toman(c.totalPaymentsAndDiscounts)],
        ['تاریخ خروجی', jalaliText(DateTime.now())],
      ],
    ),
    pw.SizedBox(height: 20),
    pw.Text('ریز تراکنش‌ها', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16)),
    pw.TableHelper.fromTextArray(
      headers: ['نوع', 'مبلغ', 'تاریخ', 'یادآوری', 'توضیح'],
      data: c.transactions.map((tx) => [tx.label, toman(tx.amount), jalaliText(tx.date), tx.reminderDate == null ? '-' : jalaliText(tx.reminderDate!), tx.note]).toList(),
    ),
  ];
}

String fullReportHtml(AppStore store) {
  final rows = store.customers.map((c) {
    return '<tr><td>${h(c.name)}</td><td>${h(fa(c.phone))}</td><td>${h(balanceText(c.balance))}</td><td>${fa(c.transactions.length)}</td><td>${h(c.note)}</td></tr>';
  }).join();

  return htmlShell(
    title: 'گزارش کامل حساب مشتریان',
    body: '''
      <h1>گزارش کامل حساب مشتریان</h1>
      <p>${h(store.settings.businessName)} - ${h(store.settings.businessCategory)}</p>
      <table>
        <tr><th>تاریخ خروجی</th><td>${jalaliText(DateTime.now())}</td></tr>
        <tr><th>تعداد مشتری‌ها</th><td>${fa(store.customers.length)}</td></tr>
        <tr><th>کل بدهی‌ها</th><td>${toman(store.totalDebt)}</td></tr>
        <tr><th>کل بستانکاری‌ها</th><td>${toman(store.totalCredit)}</td></tr>
      </table>
      <h2>لیست مشتری‌ها</h2>
      <table>
        <thead><tr><th>نام</th><th>موبایل</th><th>مانده</th><th>تراکنش</th><th>یادداشت</th></tr></thead>
        <tbody>$rows</tbody>
      </table>
    ''',
  );
}

String customerReportHtml(AppStore store, Customer c) {
  final rows = c.transactions.map((tx) {
    return '<tr><td>${h(tx.label)}</td><td>${toman(tx.amount)}</td><td>${jalaliText(tx.date)}</td><td>${tx.reminderDate == null ? '-' : jalaliText(tx.reminderDate!)}</td><td>${h(tx.note)}</td></tr>';
  }).join();

  return htmlShell(
    title: 'صورتحساب ${c.name}',
    body: '''
      <h1>صورتحساب مشتری</h1>
      <p>${h(store.settings.businessName)} - ${h(store.settings.businessCategory)}</p>
      <table>
        <tr><th>نام مشتری</th><td>${h(c.name)}</td></tr>
        <tr><th>موبایل</th><td>${h(fa(c.phone))}</td></tr>
        <tr><th>وضعیت</th><td>${h(c.statusLabel)}</td></tr>
        <tr><th>مانده حساب</th><td>${h(balanceText(c.balance))}</td></tr>
        <tr><th>مجموع بدهی</th><td>${toman(c.totalDebt)}</td></tr>
        <tr><th>مجموع پرداخت / تخفیف</th><td>${toman(c.totalPaymentsAndDiscounts)}</td></tr>
        <tr><th>تاریخ خروجی</th><td>${jalaliText(DateTime.now())}</td></tr>
      </table>
      <h2>ریز تراکنش‌ها</h2>
      <table>
        <thead><tr><th>نوع</th><th>مبلغ</th><th>تاریخ</th><th>یادآوری</th><th>توضیح</th></tr></thead>
        <tbody>$rows</tbody>
      </table>
    ''',
  );
}

String htmlShell({required String title, required String body}) {
  return '''
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>${h(title)}</title>
  <style>
    body{font-family:Tahoma,Arial,sans-serif;direction:rtl;padding:24px;color:#0f172a;line-height:1.9}
    h1{font-size:24px;margin:0 0 12px}
    h2{font-size:18px;margin:24px 0 10px}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th,td{border:1px solid #dbeafe;padding:9px;text-align:right;font-size:13px;vertical-align:top}
    th{background:#e0f2fe;color:#075985}
  </style>
</head>
<body>$body</body>
</html>
''';
}

Future<File> writeTempFile(String fileName, String content) async {
  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/$fileName');
  return file.writeAsString(content, encoding: utf8);
}

InputDecoration inputDecoration(String label, {String? hint, IconData? icon}) {
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: icon == null ? null : Icon(icon),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
    filled: true,
    fillColor: Colors.white,
    counterText: '',
  );
}

BoxDecoration cardDecoration({double radius = 24}) {
  return BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: const Color(0xffdbeafe)),
    boxShadow: const [BoxShadow(color: Color(0x120f766e), blurRadius: 20, offset: Offset(0, 8))],
  );
}

Future<bool> confirm(BuildContext context, String message) async {
  return await showDialog<bool>(
        context: context,
        builder: (ctx) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('تأیید'),
            content: Text(message),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('نه')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('بله')),
            ],
          ),
        ),
      ) ??
      false;
}

void toast(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

String filterLabel(CustomerFilter f) {
  switch (f) {
    case CustomerFilter.all:
      return 'همه';
    case CustomerFilter.debtors:
      return 'بدهکارها';
    case CustomerFilter.settled:
      return 'تسویه';
    case CustomerFilter.credit:
      return 'بستانکار';
    case CustomerFilter.todayReminders:
      return 'یادآوری امروز';
    case CustomerFilter.overdue:
      return 'عقب‌افتاده';
  }
}

String newId() => DateTime.now().microsecondsSinceEpoch.toString();

int _toInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value.toString()) ?? 0;
}

int parseMoney(String input) {
  final en = input
      .replaceAll('۰', '0')
      .replaceAll('۱', '1')
      .replaceAll('۲', '2')
      .replaceAll('۳', '3')
      .replaceAll('۴', '4')
      .replaceAll('۵', '5')
      .replaceAll('۶', '6')
      .replaceAll('۷', '7')
      .replaceAll('۸', '8')
      .replaceAll('۹', '9')
      .replaceAll(RegExp(r'[^\d]'), '');
  return int.tryParse(en) ?? 0;
}

String fa(Object? input) {
  return input.toString().replaceAll('0', '۰').replaceAll('1', '۱').replaceAll('2', '۲').replaceAll('3', '۳').replaceAll('4', '۴').replaceAll('5', '۵').replaceAll('6', '۶').replaceAll('7', '۷').replaceAll('8', '۸').replaceAll('9', '۹');
}

String toman(int amount) => '${fa(formatNumber(amount.abs()))} تومان';

String balanceText(int balance) {
  if (balance < 0) return 'بستانکار: ${toman(balance)}';
  if (balance == 0) return 'تسویه';
  return toman(balance);
}

String formatNumber(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return b.toString();
}

String safeFile(String name) {
  return name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '-').replaceAll(RegExp(r'\s+'), '-');
}

String h(String value) {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

String jalaliText(DateTime date) {
  final j = JalaliUtil.fromGregorian(date);
  return fa('${j.year}/${j.month.toString().padLeft(2, '0')}/${j.day.toString().padLeft(2, '0')}');
}

class JalaliDate {
  final int year;
  final int month;
  final int day;

  const JalaliDate(this.year, this.month, this.day);
}

class JalaliUtil {
  static DateTime? parse(String input) {
    final en = input
        .trim()
        .replaceAll('۰', '0')
        .replaceAll('۱', '1')
        .replaceAll('۲', '2')
        .replaceAll('۳', '3')
        .replaceAll('۴', '4')
        .replaceAll('۵', '5')
        .replaceAll('۶', '6')
        .replaceAll('۷', '7')
        .replaceAll('۸', '8')
        .replaceAll('۹', '9')
        .replaceAll('-', '/');

    final parts = en.split('/').map((e) => int.tryParse(e)).toList();
    if (parts.length != 3 || parts.any((e) => e == null)) return null;
    try {
      return toGregorian(parts[0]!, parts[1]!, parts[2]!);
    } catch (_) {
      return null;
    }
  }

  static JalaliDate fromGregorian(DateTime date) {
    final jdn = _g2d(date.year, date.month, date.day);
    final g = _d2g(jdn);
    var jy = g.year - 621;
    final r = _jalCal(jy);
    final jdn1f = _g2d(g.year, 3, r.march);
    var k = jdn - jdn1f;
    int jm;
    int jd;

    if (k >= 0) {
      if (k <= 185) {
        jm = 1 + _div(k, 31);
        jd = _mod(k, 31) + 1;
        return JalaliDate(jy, jm, jd);
      } else {
        k -= 186;
      }
    } else {
      jy -= 1;
      k += 179;
      if (r.leap == 1) k += 1;
    }

    jm = 7 + _div(k, 30);
    jd = _mod(k, 30) + 1;
    return JalaliDate(jy, jm, jd);
  }

  static DateTime toGregorian(int jy, int jm, int jd) {
    final jdn = _j2d(jy, jm, jd);
    final g = _d2g(jdn);
    return DateTime(g.year, g.month, g.day);
  }

  static int _div(int a, int b) => a ~/ b;
  static int _mod(int a, int b) => a - (a ~/ b) * b;

  static int _g2d(int gy, int gm, int gd) {
    var d = _div((gy + _div(gm - 8, 6) + 100100) * 1461, 4) +
        _div(153 * _mod(gm + 9, 12) + 2, 5) +
        gd -
        34840408;
    d = d - _div(_div(gy + 100100 + _div(gm - 8, 6), 100) * 3, 4) + 752;
    return d;
  }

  static _GDate _d2g(int jdn) {
    var j = 4 * jdn + 139361631;
    j = j + _div(_div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
    final i = _div(_mod(j, 1461), 4) * 5 + 308;
    final gd = _div(_mod(i, 153), 5) + 1;
    final gm = _mod(_div(i, 153), 12) + 1;
    final gy = _div(j, 1461) - 100100 + _div(8 - gm, 6);
    return _GDate(gy, gm, gd);
  }

  static int _j2d(int jy, int jm, int jd) {
    final r = _jalCal(jy);
    return _g2d(r.gy, 3, r.march) + (jm - 1) * 31 - _div(jm, 7) * (jm - 7) + jd - 1;
  }

  static _JalCal _jalCal(int jy) {
    final breaks = [
      -61,
      9,
      38,
      199,
      426,
      686,
      756,
      818,
      1111,
      1181,
      1210,
      1635,
      2060,
      2097,
      2192,
      2262,
      2324,
      2394,
      2456,
      3178
    ];

    final gy = jy + 621;
    var leapJ = -14;
    var jp = breaks[0];
    var jump = 0;

    if (jy < jp || jy >= breaks[breaks.length - 1]) {
      throw ArgumentError('Invalid Jalali year');
    }

    for (var i = 1; i < breaks.length; i++) {
      final jm = breaks[i];
      jump = jm - jp;
      if (jy < jm) break;
      leapJ = leapJ + _div(jump, 33) * 8 + _div(_mod(jump, 33), 4);
      jp = jm;
    }

    var n = jy - jp;
    leapJ = leapJ + _div(n, 33) * 8 + _div(_mod(n, 33) + 3, 4);
    if (_mod(jump, 33) == 4 && jump - n == 4) leapJ += 1;

    final leapG = _div(gy, 4) - _div((_div(gy, 100) + 1) * 3, 4) - 150;
    final march = 20 + leapJ - leapG;

    if (jump - n < 6) {
      n = n - jump + _div(jump + 4, 33) * 33;
    }

    var leap = _mod(_mod(n + 1, 33) - 1, 4);
    if (leap == -1) leap = 4;

    return _JalCal(leap, gy, march);
  }
}

class _GDate {
  final int year;
  final int month;
  final int day;

  const _GDate(this.year, this.month, this.day);
}

class _JalCal {
  final int leap;
  final int gy;
  final int march;

  const _JalCal(this.leap, this.gy, this.march);
}
