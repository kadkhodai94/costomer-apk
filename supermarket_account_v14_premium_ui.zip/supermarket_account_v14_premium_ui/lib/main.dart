
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:url_launcher/url_launcher.dart';


class Brand {
  static const deep = Color(0xff083B3A);
  static const teal = Color(0xff087D69);
  static const cyan = Color(0xff0EA5A4);
  static const navy = Color(0xff0F172A);
  static const cream = Color(0xffF7F3EA);
  static const paper = Color(0xffFBFAF6);
  static const amber = Color(0xffF59E0B);
  static const red = Color(0xffDC2626);
  static const green = Color(0xff16A34A);

  static const premiumGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [Color(0xff083B3A), Color(0xff087D69), Color(0xff0EA5A4)],
  );

  static List<BoxShadow> softShadow = [
    BoxShadow(color: Color(0xff083B3A).withOpacity(.08), blurRadius: 24, offset: Offset(0, 12)),
  ];
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SupermarketApp());
}

class SupermarketApp extends StatelessWidget {
  const SupermarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حسابیار سوپرمارکت',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: Brand.teal, primary: Brand.teal, secondary: Brand.amber),
        scaffoldBackgroundColor: Brand.cream,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          foregroundColor: Brand.navy,
          centerTitle: false,
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          elevation: 0,
          indicatorColor: Brand.teal.withOpacity(.12),
          labelTextStyle: WidgetStateProperty.all(const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: Brand.teal,
            foregroundColor: Colors.white,
            minimumSize: const Size(64, 48),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            textStyle: const TextStyle(fontWeight: FontWeight.w900),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: Brand.deep,
            side: BorderSide(color: Brand.teal.withOpacity(.28)),
            minimumSize: const Size(64, 48),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            textStyle: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: Brand.navy.withOpacity(.62), fontWeight: FontWeight.w700),
          prefixIconColor: Brand.teal,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: Brand.teal.withOpacity(.08))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Brand.teal, width: 1.4)),
        ),
      ),
      home: const AuthGate(),
    );
  }
}

// ---------------- Utils ----------------

String fa(String input) {
  const e = ['0','1','2','3','4','5','6','7','8','9'];
  const f = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  var out = input;
  for (var i=0;i<e.length;i++) { out = out.replaceAll(e[i], f[i]); }
  return out;
}

String enDigits(String input) {
  const f = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  const a = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
  const e = ['0','1','2','3','4','5','6','7','8','9'];
  var out = input;
  for (var i=0;i<e.length;i++) { out = out.replaceAll(f[i], e[i]).replaceAll(a[i], e[i]); }
  return out;
}

int cleanAmount(String v) => int.tryParse(enDigits(v).replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;

String money(int value) {
  final s = value.abs().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',');
  return '${fa(s)} تومان';
}

String signedMoney(int value) {
  if (value == 0) return 'تسویه';
  if (value < 0) return 'بستانکار: ${money(value)}';
  return money(value);
}

String isoDate(DateTime d) => d.toIso8601String().substring(0,10);
String todayIso() => isoDate(DateTime.now());

String jalaliSimple(String iso) => fa(iso); // ساده و پایدار برای Build؛ در نسخه بعد می‌شود DatePicker کامل اضافه کرد.

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}

class CurrentSession {
  static String username = '';
  static String role = 'staff';
  static int staffId = 0;
  static Map<String, int> permissions = {};
  static bool get isAdmin => role == 'admin';
  static bool can(String key) => isAdmin || (permissions[key] ?? 0) == 1;
}

// ---------------- Database ----------------

class Db {
  static Database? _db;

  static Future<Database> get instance async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'supermarket_v13.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
      await db.execute('CREATE TABLE staff(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, username TEXT, password TEXT, role TEXT, active INTEGER, canSell INTEGER, canEditProduct INTEGER, canEditCustomer INTEGER, canDeleteInvoice INTEGER, canViewProfit INTEGER, canViewReports INTEGER)');
      await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, note TEXT, groupName TEXT, creditLimit INTEGER, dueDays INTEGER, createdAt TEXT)');
      await db.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, buyPrice INTEGER, sellPrice INTEGER, stock INTEGER, minStock INTEGER, category TEXT, isActive INTEGER)');
      await db.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER, customerName TEXT, staffId INTEGER, staffName TEXT, paymentType TEXT, subtotal INTEGER, discount INTEGER, tax INTEGER, delivery INTEGER, total INTEGER, profit INTEGER, status TEXT, dateIso TEXT, createdAt TEXT)');
      await db.execute('CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, saleId INTEGER, productId INTEGER, productName TEXT, buyPrice INTEGER, sellPrice INTEGER, qty INTEGER, total INTEGER, profit INTEGER)');
      await db.execute('CREATE TABLE account_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, customerId INTEGER, type TEXT, amount INTEGER, dateIso TEXT, note TEXT)');
      await db.execute('CREATE TABLE subscriptions(id INTEGER PRIMARY KEY, title TEXT, months INTEGER, price INTEGER)');
    });
    await seed();
    return _db!;
  }

  static Future<void> seed() async {
    final db = _db!;
    final rows = await db.query('settings', where:'key=?', whereArgs:['seeded']);
    if (rows.isNotEmpty) return;

    await db.insert('settings', {'key':'seeded','value':'yes'});
    await db.insert('settings', {'key':'storeCode','value':'SM1001'});
    await db.insert('settings', {'key':'businessName','value':'سوپرمارکت نمونه'});
    await db.insert('settings', {'key':'businessPhone','value':''});
    await db.insert('settings', {'key':'trialEnd','value': isoDate(DateTime.now().add(const Duration(days:30)))});

    await db.insert('staff', {'name':'مدیر فروشگاه','username':'admin','password':'1234','role':'admin','active':1,'canSell':1,'canEditProduct':1,'canEditCustomer':1,'canDeleteInvoice':1,'canViewProfit':1,'canViewReports':1});
    await db.insert('staff', {'name':'شاگرد نمونه','username':'shagerd','password':'1111','role':'staff','active':1,'canSell':1,'canEditProduct':0,'canEditCustomer':0,'canDeleteInvoice':0,'canViewProfit':0,'canViewReports':0});

    final products = <List<Object>>[
      ['شیر کم‌چرب', 27300, 35000, 8, 5, 'لبنیات'],
      ['شیر پرچرب', 33540, 43000, 11, 5, 'لبنیات'],
      ['شیر کاکائو', 39780, 51000, 14, 5, 'لبنیات'],
      ['ماست ساده', 46020, 59000, 17, 5, 'لبنیات'],
      ['ماست موسیر', 52260, 67000, 20, 5, 'لبنیات'],
      ['ماست چکیده', 58500, 75000, 23, 5, 'لبنیات'],
      ['پنیر سفید', 31980, 41000, 26, 5, 'لبنیات'],
      ['پنیر خامه‌ای', 38220, 49000, 29, 5, 'لبنیات'],
      ['خامه صبحانه', 44460, 57000, 32, 5, 'لبنیات'],
      ['کره', 50700, 65000, 8, 5, 'لبنیات'],
      ['دوغ خانواده', 56940, 73000, 11, 5, 'لبنیات'],
      ['دوغ کوچک', 63180, 81000, 14, 5, 'لبنیات'],
      ['نوشابه خانواده', 23400, 30000, 8, 5, 'نوشیدنی'],
      ['نوشابه قوطی', 29640, 38000, 11, 5, 'نوشیدنی'],
      ['دلستر', 35880, 46000, 14, 5, 'نوشیدنی'],
      ['آب معدنی کوچک', 42120, 54000, 17, 5, 'نوشیدنی'],
      ['آب معدنی بزرگ', 48360, 62000, 20, 5, 'نوشیدنی'],
      ['آبمیوه پاکتی', 54600, 70000, 23, 5, 'نوشیدنی'],
      ['نوشیدنی انرژی‌زا', 28080, 36000, 26, 5, 'نوشیدنی'],
      ['شربت', 34320, 44000, 29, 5, 'نوشیدنی'],
      ['برنج ایرانی', 66300, 85000, 8, 5, 'خواربار'],
      ['برنج خارجی', 72540, 93000, 11, 5, 'خواربار'],
      ['روغن مایع', 78780, 101000, 14, 5, 'خواربار'],
      ['روغن سرخ‌کردنی', 85020, 109000, 17, 5, 'خواربار'],
      ['قند', 91260, 117000, 20, 5, 'خواربار'],
      ['شکر', 97500, 125000, 23, 5, 'خواربار'],
      ['چای', 70980, 91000, 26, 5, 'خواربار'],
      ['نمک', 77220, 99000, 29, 5, 'خواربار'],
      ['رب گوجه', 83460, 107000, 32, 5, 'خواربار'],
      ['ماکارونی', 89700, 115000, 8, 5, 'خواربار'],
      ['آرد', 95940, 123000, 11, 5, 'خواربار'],
      ['عدس', 102180, 131000, 14, 5, 'خواربار'],
      ['لپه', 75660, 97000, 17, 5, 'خواربار'],
      ['نخود', 81900, 105000, 20, 5, 'خواربار'],
      ['لوبیا چیتی', 88140, 113000, 23, 5, 'خواربار'],
      ['لوبیا قرمز', 94380, 121000, 26, 5, 'خواربار'],
      ['سویا', 100620, 129000, 29, 5, 'خواربار'],
      ['تن ماهی', 50700, 65000, 8, 5, 'کنسرو'],
      ['کنسرو لوبیا', 56940, 73000, 11, 5, 'کنسرو'],
      ['کنسرو ذرت', 63180, 81000, 14, 5, 'کنسرو'],
      ['کنسرو نخودفرنگی', 69420, 89000, 17, 5, 'کنسرو'],
      ['کنسرو قارچ', 75660, 97000, 20, 5, 'کنسرو'],
      ['کمپوت آناناس', 81900, 105000, 23, 5, 'کنسرو'],
      ['کمپوت هلو', 55380, 71000, 26, 5, 'کنسرو'],
      ['چیپس', 19500, 25000, 8, 5, 'تنقلات'],
      ['پفک', 25740, 33000, 11, 5, 'تنقلات'],
      ['اسنک', 31980, 41000, 14, 5, 'تنقلات'],
      ['بیسکویت', 38220, 49000, 17, 5, 'تنقلات'],
      ['ویفر', 44460, 57000, 20, 5, 'تنقلات'],
      ['کیک', 50700, 65000, 23, 5, 'تنقلات'],
      ['کلوچه', 24180, 31000, 26, 5, 'تنقلات'],
      ['شکلات', 30420, 39000, 29, 5, 'تنقلات'],
      ['آدامس', 36660, 47000, 32, 5, 'تنقلات'],
      ['پاستیل', 42900, 55000, 8, 5, 'تنقلات'],
      ['تخمه', 49140, 63000, 11, 5, 'تنقلات'],
      ['لواشک', 55380, 71000, 14, 5, 'تنقلات'],
      ['دستمال کاغذی', 58500, 75000, 8, 5, 'بهداشتی'],
      ['دستمال توالت', 64740, 83000, 11, 5, 'بهداشتی'],
      ['مایع دستشویی', 70980, 91000, 14, 5, 'بهداشتی'],
      ['شامپو', 77220, 99000, 17, 5, 'بهداشتی'],
      ['صابون', 83460, 107000, 20, 5, 'بهداشتی'],
      ['خمیر دندان', 89700, 115000, 23, 5, 'بهداشتی'],
      ['مسواک', 63180, 81000, 26, 5, 'بهداشتی'],
      ['پوشک', 69420, 89000, 29, 5, 'بهداشتی'],
      ['دستمال مرطوب', 75660, 97000, 32, 5, 'بهداشتی'],
      ['مایع ظرفشویی', 70200, 90000, 8, 5, 'شوینده'],
      ['پودر لباسشویی', 76440, 98000, 11, 5, 'شوینده'],
      ['مایع لباسشویی', 82680, 106000, 14, 5, 'شوینده'],
      ['نرم‌کننده', 88920, 114000, 17, 5, 'شوینده'],
      ['سفیدکننده', 95160, 122000, 20, 5, 'شوینده'],
      ['جرم‌گیر', 101400, 130000, 23, 5, 'شوینده'],
      ['شیشه‌شوی', 74880, 96000, 26, 5, 'شوینده'],
      ['اسکاچ', 81120, 104000, 29, 5, 'شوینده'],
      ['کیسه زباله', 87360, 112000, 32, 5, 'شوینده'],
      ['سس مایونز', 35100, 45000, 8, 5, 'چاشنی'],
      ['سس کچاپ', 41340, 53000, 11, 5, 'چاشنی'],
      ['آبلیمو', 47580, 61000, 14, 5, 'چاشنی'],
      ['آبغوره', 53820, 69000, 17, 5, 'چاشنی'],
      ['سرکه', 60060, 77000, 20, 5, 'چاشنی'],
      ['خیارشور', 66300, 85000, 23, 5, 'چاشنی'],
      ['ترشی', 39780, 51000, 26, 5, 'چاشنی'],
      ['زردچوبه', 46020, 59000, 29, 5, 'چاشنی'],
      ['فلفل', 52260, 67000, 32, 5, 'چاشنی'],
      ['دارچین', 58500, 75000, 8, 5, 'چاشنی'],
      ['تخم مرغ', 117000, 150000, 8, 5, 'پروتئینی'],
      ['مرغ بسته‌بندی', 123240, 158000, 11, 5, 'پروتئینی'],
      ['سوسیس', 129480, 166000, 14, 5, 'پروتئینی'],
      ['کالباس', 135720, 174000, 17, 5, 'پروتئینی'],
      ['همبرگر منجمد', 141960, 182000, 20, 5, 'پروتئینی'],
      ['ناگت', 148200, 190000, 23, 5, 'پروتئینی'],
      ['فلافل منجمد', 121680, 156000, 26, 5, 'پروتئینی'],
      ['عسل', 66300, 85000, 8, 5, 'صبحانه'],
      ['مربا', 72540, 93000, 11, 5, 'صبحانه'],
      ['حلوا شکری', 78780, 101000, 14, 5, 'صبحانه'],
      ['ارده', 85020, 109000, 17, 5, 'صبحانه'],
      ['شکلات صبحانه', 91260, 117000, 20, 5, 'صبحانه'],
      ['کورن فلکس', 97500, 125000, 23, 5, 'صبحانه'],
      ['خرما', 70980, 91000, 26, 5, 'صبحانه'],
      ['کبریت', 23400, 30000, 8, 5, 'مصرفی'],
      ['فندک', 29640, 38000, 11, 5, 'مصرفی'],
      ['باتری', 35880, 46000, 14, 5, 'مصرفی'],
      ['چسب', 42120, 54000, 17, 5, 'مصرفی'],
      ['لامپ', 48360, 62000, 20, 5, 'مصرفی'],
      ['لیوان یکبارمصرف', 54600, 70000, 23, 5, 'مصرفی'],
      ['سفره یکبارمصرف', 28080, 36000, 26, 5, 'مصرفی'],
      ['فویل', 34320, 44000, 29, 5, 'مصرفی'],
      ['سلفون', 40560, 52000, 32, 5, 'مصرفی']
    ];
    for (final row in products) {
      await db.insert('products', {'name':row[0], 'buyPrice':row[1], 'sellPrice':row[2], 'stock':row[3], 'minStock':row[4], 'category':row[5], 'isActive':1});
    }

    final c1 = await db.insert('customers', {'name':'محمد کدخدایی','phone':'09153480704','note':'مشتری تستی','groupName':'VIP','creditLimit':5000000,'dueDays':14,'createdAt':DateTime.now().toIso8601String()});
    final c2 = await db.insert('customers', {'name':'عبدالله احمدی','phone':'09120000001','note':'مشتری نسیه','groupName':'ثابت','creditLimit':3000000,'dueDays':7,'createdAt':DateTime.now().toIso8601String()});
    await db.insert('account_transactions', {'customerId':c1,'type':'debt','amount':1200000,'dateIso':todayIso(),'note':'بدهی تستی'});
    await db.insert('account_transactions', {'customerId':c2,'type':'debt','amount':800000,'dateIso':todayIso(),'note':'بدهی تستی'});
  }

  static Future<String?> setting(String key) async {
    final db = await instance;
    final rows = await db.query('settings', where:'key=?', whereArgs:[key]);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  static Future<void> setSetting(String key, String value) async {
    final db = await instance;
    await db.insert('settings', {'key':key,'value':value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<bool> login(String username, String password, String storeCode) async {
    final db = await instance;
    final code = (await setting('storeCode')) ?? 'SM1001';
    if (enDigits(storeCode.trim()).toUpperCase() != code.toUpperCase()) return false;
    final rows = await db.query('staff', where:'username=? AND password=? AND active=1', whereArgs:[username.trim(), enDigits(password.trim())], limit:1);
    if (rows.isEmpty) return false;
    final s = rows.first;
    CurrentSession.staffId = s['id'] as int;
    CurrentSession.username = s['username'].toString();
    CurrentSession.role = s['role'].toString();
    CurrentSession.permissions = {
      'sell': s['canSell'] as int,
      'editProduct': s['canEditProduct'] as int,
      'editCustomer': s['canEditCustomer'] as int,
      'deleteInvoice': s['canDeleteInvoice'] as int,
      'viewProfit': s['canViewProfit'] as int,
      'viewReports': s['canViewReports'] as int,
    };
    return true;
  }

  static Future<List<Map<String,Object?>>> products(String q) async {
    final db = await instance;
    if (q.trim().isEmpty) return db.query('products', where:'isActive=1', orderBy:'name ASC', limit:40);
    return db.query('products', where:'isActive=1 AND (name LIKE ? OR category LIKE ?)', whereArgs:['%$q%','%$q%'], orderBy:'name ASC', limit:50);
  }

  static Future<List<Map<String,Object?>>> allProducts() async {
    final db = await instance;
    return db.query('products', where:'isActive=1', orderBy:'category ASC, name ASC');
  }

  static Future<void> saveProduct({int? id, required String name, required int buyPrice, required int sellPrice, required int stock, required int minStock, required String category}) async {
    final db = await instance;
    final data = {'name':name,'buyPrice':buyPrice,'sellPrice':sellPrice,'stock':stock,'minStock':minStock,'category':category,'isActive':1};
    if (id == null) await db.insert('products', data); else await db.update('products', data, where:'id=?', whereArgs:[id]);
  }

  static Future<void> deleteProduct(int id) async {
    final db = await instance;
    await db.update('products', {'isActive':0}, where:'id=?', whereArgs:[id]);
  }

  static Future<List<Map<String,Object?>>> customers(String q) async {
    final db = await instance;
    if (q.trim().isEmpty) return db.query('customers', orderBy:'id DESC');
    return db.query('customers', where:'name LIKE ? OR phone LIKE ?', whereArgs:['%$q%','%$q%'], orderBy:'id DESC');
  }

  static Future<int> saveCustomer({int? id, required String name, String phone='', String note='', String groupName='عادی', int creditLimit=0, int dueDays=7}) async {
    final db = await instance;
    final data = {'name':name,'phone':phone,'note':note,'groupName':groupName,'creditLimit':creditLimit,'dueDays':dueDays,'createdAt':DateTime.now().toIso8601String()};
    if (id == null) return db.insert('customers', data);
    await db.update('customers', data, where:'id=?', whereArgs:[id]);
    return id;
  }

  static Future<int> findOrCreateCustomer(String name) async {
    final db = await instance;
    final rows = await db.query('customers', where:'name=?', whereArgs:[name.trim()], limit:1);
    if (rows.isNotEmpty) return rows.first['id'] as int;
    return saveCustomer(name:name.trim());
  }

  static Future<Map<String,Object?>?> customer(int id) async {
    final db = await instance;
    final rows = await db.query('customers', where:'id=?', whereArgs:[id]);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<List<Map<String,Object?>>> transactions(int customerId) async {
    final db = await instance;
    return db.query('account_transactions', where:'customerId=?', whereArgs:[customerId], orderBy:'id DESC');
  }

  static Future<int> balance(int customerId) async {
    final txs = await transactions(customerId);
    var total = 0;
    for (final t in txs) {
      total += t['type'] == 'debt' ? t['amount'] as int : -(t['amount'] as int);
    }
    return total;
  }

  static Future<void> addTransaction(int customerId, String type, int amount, String note) async {
    final db = await instance;
    await db.insert('account_transactions', {'customerId':customerId,'type':type,'amount':amount,'dateIso':todayIso(),'note':note});
  }

  static Future<int> saveSale({required int customerId, required String customerName, required String paymentType, required int subtotal, required int discount, required int tax, required int delivery, required int total, required List<CartItem> items}) async {
    final db = await instance;
    final profit = items.fold<int>(0, (sum, item) => sum + item.profit) - discount + delivery;
    final saleId = await db.insert('sales', {
      'customerId':customerId,'customerName':customerName,'staffId':CurrentSession.staffId,'staffName':CurrentSession.username,
      'paymentType':paymentType,'subtotal':subtotal,'discount':discount,'tax':tax,'delivery':delivery,'total':total,'profit':profit,
      'status':'active','dateIso':todayIso(),'createdAt':DateTime.now().toIso8601String()
    });
    for (final item in items) {
      await db.insert('sale_items', {'saleId':saleId,'productId':item.productId,'productName':item.name,'buyPrice':item.buyPrice,'sellPrice':item.sellPrice,'qty':item.qty,'total':item.total,'profit':item.profit});
      await db.rawUpdate('UPDATE products SET stock = stock - ? WHERE id=?', [item.qty, item.productId]);
    }
    if (paymentType == 'credit') {
      await addTransaction(customerId, 'debt', total, 'خرید نسیه فاکتور $saleId');
    }
    return saleId;
  }

  static Future<void> cancelSale(int saleId) async {
    final db = await instance;
    final sales = await db.query('sales', where:'id=?', whereArgs:[saleId]);
    if (sales.isEmpty || sales.first['status'] == 'cancelled') return;
    final items = await db.query('sale_items', where:'saleId=?', whereArgs:[saleId]);
    for (final item in items) {
      await db.rawUpdate('UPDATE products SET stock = stock + ? WHERE id=?', [item['qty'], item['productId']]);
    }
    await db.update('sales', {'status':'cancelled'}, where:'id=?', whereArgs:[saleId]);
  }

  static Future<List<Map<String,Object?>>> sales() async {
    final db = await instance;
    return db.query('sales', orderBy:'id DESC', limit:100);
  }

  static Future<List<Map<String,Object?>>> lowStock() async {
    final db = await instance;
    return db.rawQuery('SELECT * FROM products WHERE isActive=1 AND stock <= minStock ORDER BY stock ASC');
  }

  static Future<List<Map<String,Object?>>> staff() async {
    final db = await instance;
    return db.query('staff', orderBy:'id ASC');
  }

  static Future<void> saveStaff({int? id, required String name, required String username, required String password, required int active, required int canSell, required int canEditProduct, required int canEditCustomer, required int canDeleteInvoice, required int canViewProfit, required int canViewReports}) async {
    final db = await instance;
    final data = {'name':name,'username':username,'password':password,'role':'staff','active':active,'canSell':canSell,'canEditProduct':canEditProduct,'canEditCustomer':canEditCustomer,'canDeleteInvoice':canDeleteInvoice,'canViewProfit':canViewProfit,'canViewReports':canViewReports};
    if (id == null) await db.insert('staff', data); else await db.update('staff', data, where:'id=?', whereArgs:[id]);
  }

  static Future<Map<String,int>> stats() async {
    final db = await instance;
    final salesRows = await db.query('sales', where:"status='active'");
    var subtotal=0, cash=0, credit=0, profit=0, discount=0;
    for (final s in salesRows) {
      final total = s['total'] as int;
      subtotal += total;
      discount += s['discount'] as int;
      profit += s['profit'] as int;
      if (s['paymentType'] == 'cash') cash += total; else credit += total;
    }
    final productsCount = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE isActive=1')) ?? 0;
    final stockCount = Sqflite.firstIntValue(await db.rawQuery('SELECT SUM(stock) FROM products WHERE isActive=1')) ?? 0;
    final stockValue = Sqflite.firstIntValue(await db.rawQuery('SELECT SUM(stock*sellPrice) FROM products WHERE isActive=1')) ?? 0;
    final lowCount = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE isActive=1 AND stock<=minStock')) ?? 0;
    return {'sales':subtotal,'cash':cash,'credit':credit,'profit':profit,'discount':discount,'products':productsCount,'stock':stockCount,'stockValue':stockValue,'lowStock':lowCount};
  }

  static Future<List<Map<String,Object?>>> staffReport() async {
    final db = await instance;
    return db.rawQuery("""
      SELECT staffName, COUNT(*) as invoiceCount,
      SUM(total) as totalSales,
      SUM(CASE WHEN paymentType='cash' THEN total ELSE 0 END) as cashSales,
      SUM(CASE WHEN paymentType='credit' THEN total ELSE 0 END) as creditSales,
      SUM(profit) as profit
      FROM sales WHERE status='active'
      GROUP BY staffName
      ORDER BY totalSales DESC
    """);
  }

  static Future<String> backupText() async {
    final db = await instance;
    final data = {
      'settings': await db.query('settings'),
      'staff': await db.query('staff'),
      'customers': await db.query('customers'),
      'products': await db.query('products'),
      'sales': await db.query('sales'),
      'sale_items': await db.query('sale_items'),
      'account_transactions': await db.query('account_transactions'),
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }
}

class CartItem {
  final int productId;
  final String name;
  final int buyPrice;
  final int sellPrice;
  int qty;
  CartItem({required this.productId, required this.name, required this.buyPrice, required this.sellPrice, this.qty=1});
  int get total => sellPrice * qty;
  int get profit => (sellPrice - buyPrice) * qty;
}

// ---------------- Auth ----------------

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState()=>_AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading=true;
  bool loggedIn=false;
  bool splash=true;
  @override
  void initState() { super.initState(); boot(); }
  Future<void> boot() async {
    await Db.instance;
    await Future.delayed(const Duration(milliseconds: 1050));
    if (mounted) setState((){ loading=false; splash=false; });
  }
  @override
  Widget build(BuildContext context) {
    if (loading || splash) return const SplashScreen();
    if (!loggedIn) return LoginScreen(onLogin:()=>setState(()=>loggedIn=true));
    return AppShell(onLogout:()=>setState(()=>loggedIn=false));
  }
}


class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: Brand.premiumGradient),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 112,
                  height: 112,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(34),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.20), blurRadius: 32, offset: const Offset(0, 18))],
                  ),
                  child: Image.asset('assets/brand/splash_mark.png'),
                ),
                const SizedBox(height: 18),
                const Text('حسابیار سوپرمارکت', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('فروش، نسیه، موجودی و شاگردها', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  final VoidCallback onLogin;
  const LoginScreen({super.key, required this.onLogin});
  @override
  State<LoginScreen> createState()=>_LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username=TextEditingController(text:'admin');
  final password=TextEditingController(text:'1234');
  final code=TextEditingController(text:'SM1001');
  bool hide=true;

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: ProBackground(child: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(22), child: Column(children: [
        const AppLogo(size: 104),
        const SizedBox(height:18),
        Text('حسابیار سوپرمارکت', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900, color: Brand.navy)),
        const SizedBox(height:8),
        const Text('سیستم اختصاصی فروش، نسیه و موجودی', style: TextStyle(color: Color(0xff64748B), fontWeight: FontWeight.w700)),
        const SizedBox(height:24),
        ProCard(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: const [BrandIcon(icon: Icons.verified_user_outlined), SizedBox(width:10), Expanded(child: Text('ورود امن فروشگاه', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)))]),
          const SizedBox(height:16),
          ProField(controller: username, label:'نام کاربری', icon: Icons.person_outline),
          const SizedBox(height:10),
          TextField(controller:password, obscureText:hide, keyboardType:TextInputType.number, decoration:InputDecoration(labelText:'رمز عبور', prefixIcon:const Icon(Icons.lock_outline), suffixIcon:IconButton(icon:Icon(hide?Icons.visibility_outlined:Icons.visibility_off_outlined), onPressed:()=>setState(()=>hide=!hide)))),
          const SizedBox(height:10),
          ProField(controller: code, label:'کد اختصاصی فروشگاه', icon: Icons.store_mall_directory_outlined),
          const SizedBox(height:16),
          FilledButton(onPressed:login, child: const Text('ورود به پنل فروشگاه')),
          const SizedBox(height:10),
          const Center(child: Text('admin / 1234 / SM1001', style: TextStyle(color: Color(0xff94A3B8), fontSize: 12, fontWeight: FontWeight.w700))),
        ])),
      ]))))),
    ));
  }

  Future<void> login() async {
    if (await Db.login(username.text,password.text,code.text)) {
      widget.onLogin();
    } else {
      toast(context,'نام کاربری، رمز یا کد فروشگاه اشتباه است');
    }
  }
}

// ---------------- Shell ----------------

class AppShell extends StatefulWidget {
  final VoidCallback onLogout;
  const AppShell({super.key, required this.onLogout});
  @override
  State<AppShell> createState()=>_AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index=0;
  @override
  Widget build(BuildContext context) {
    final pages=[
      const DashboardPage(),
      const SalePage(),
      const CustomersPage(),
      const ProductsPage(),
      MorePage(onLogout:widget.onLogout),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex:index,
        onDestinationSelected:(i)=>setState(()=>index=i),
        destinations: const [
          NavigationDestination(icon:NavMark(icon:Icons.dashboard_outlined), selectedIcon:NavMark(icon:Icons.dashboard, active:true), label:'داشبورد'),
          NavigationDestination(icon:NavMark(icon:Icons.point_of_sale_outlined), selectedIcon:NavMark(icon:Icons.point_of_sale, active:true), label:'فروش'),
          NavigationDestination(icon:NavMark(icon:Icons.people_outline), selectedIcon:NavMark(icon:Icons.people, active:true), label:'مشتری'),
          NavigationDestination(icon:NavMark(icon:Icons.inventory_2_outlined), selectedIcon:NavMark(icon:Icons.inventory_2, active:true), label:'کالا'),
          NavigationDestination(icon:NavMark(icon:Icons.more_horiz), selectedIcon:NavMark(icon:Icons.more, active:true), label:'بیشتر'),
        ],
      ),
    ));
  }
}

// ---------------- Dashboard ----------------

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState()=>_DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Future<Map<String,int>>? future;
  Future<List<Map<String,Object?>>>? low;
  @override
  void initState() { super.initState(); reload(); }
  void reload() { future=Db.stats(); low=Db.lowStock(); setState((){}); }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(title:'داشبورد', child: RefreshIndicator(onRefresh:()async=>reload(), child: ListView(padding: const EdgeInsets.all(16), children:[
      FutureBuilder<Map<String,int>>(future:future, builder:(context,snap) {
        final s=snap.data??{};
        return Column(children:[
          HeroCard(title:'فروش امروز', value:money(s['sales']??0), sub:'نقد: ${money(s['cash']??0)} | نسیه: ${money(s['credit']??0)}'),
          const SizedBox(height:12),
          GridView.count(crossAxisCount:2, shrinkWrap:true, physics:const NeverScrollableScrollPhysics(), crossAxisSpacing:10, mainAxisSpacing:10, childAspectRatio:1.55, children:[
            StatCard(label:'تعداد کالا', value:fa('${s['products']??0}'), icon:Icons.inventory_2_outlined),
            StatCard(label:'کل موجودی', value:fa('${s['stock']??0}'), icon:Icons.warehouse_outlined),
            StatCard(label:'ارزش موجودی', value:money(s['stockValue']??0), icon:Icons.savings_outlined),
            StatCard(label:'کم‌موجودی', value:fa('${s['lowStock']??0}'), icon:Icons.warning_amber_outlined),
            if (CurrentSession.can('viewProfit')) StatCard(label:'سود تقریبی', value:money(s['profit']??0), icon:Icons.trending_up),
            StatCard(label:'تخفیف‌ها', value:money(s['discount']??0), icon:Icons.discount_outlined),
          ]),
        ]);
      }),
      const SizedBox(height:16),
      Text('کالاهای کم‌موجودی', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
      FutureBuilder<List<Map<String,Object?>>>(future:low, builder:(context,snap) {
        final list=snap.data??[];
        if (list.isEmpty) return const Padding(padding:EdgeInsets.all(16), child:Text('کالای کم‌موجودی وجود ندارد', style:TextStyle(color:Colors.grey)));
        return Column(children:list.take(10).map((p)=>Padding(padding:const EdgeInsets.only(top:8), child:ProCard(padding:const EdgeInsets.all(12), child:Row(children:[
          Expanded(child:Text(p['name'].toString(), style:const TextStyle(fontWeight:FontWeight.w900))),
          Text('موجودی: ${fa('${p['stock']}')}', style:const TextStyle(color:Colors.orange, fontWeight:FontWeight.w900)),
        ])))).toList());
      })
    ])));
  }
}

// ---------------- Sale ----------------

class SalePage extends StatefulWidget {
  const SalePage({super.key});
  @override
  State<SalePage> createState()=>_SalePageState();
}

class _SalePageState extends State<SalePage> {
  final customer=TextEditingController();
  final search=TextEditingController();
  final discountAmount=TextEditingController(text:'0');
  final discountPercent=TextEditingController(text:'0');
  final tax=TextEditingController(text:'0');
  final delivery=TextEditingController(text:'0');
  final cart=<CartItem>[];
  List<Map<String,Object?>> suggestions=[];
  String paymentType='cash';

  int get subtotal=>cart.fold(0,(sum,i)=>sum+i.total);
  int get discount {
    final amount=cleanAmount(discountAmount.text);
    final percent=cleanAmount(discountPercent.text);
    return amount + ((subtotal * percent) ~/ 100);
  }
  int get taxAmount=>cleanAmount(tax.text);
  int get deliveryAmount=>cleanAmount(delivery.text);
  int get total=>subtotal - discount + taxAmount + deliveryAmount;

  @override
  void initState() { super.initState(); searchProducts(''); }
  Future<void> searchProducts(String q) async { suggestions=await Db.products(q); setState((){}); }
  void addProduct(Map<String,Object?> p) {
    final id=p['id'] as int;
    final stock=p['stock'] as int;
    final existing=cart.where((i)=>i.productId==id).toList();
    if (stock <= 0) { toast(context,'موجودی این کالا صفر است'); return; }
    if (existing.isNotEmpty) {
      if (existing.first.qty >= stock) { toast(context,'موجودی کافی نیست'); return; }
      existing.first.qty++;
    } else {
      cart.add(CartItem(productId:id, name:p['name'].toString(), buyPrice:p['buyPrice'] as int, sellPrice:p['sellPrice'] as int));
    }
    search.clear(); searchProducts(''); setState((){});
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(title:'فروش سریع', child: Column(children:[
      Padding(padding: const EdgeInsets.fromLTRB(16,8,16,6), child: Column(children:[
        ProField(controller:customer, label:'نام مشتری', icon:Icons.person_search_outlined),
        const SizedBox(height:8),
        TextField(controller:search, autofocus:true, onChanged:searchProducts, decoration:const InputDecoration(labelText:'جستجوی کالا با یک حرف', prefixIcon:Icon(Icons.search))),
      ])),
      SizedBox(height:120, child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:16), scrollDirection:Axis.horizontal, itemCount:suggestions.length, separatorBuilder:(_,__)=>const SizedBox(width:8), itemBuilder:(context,i){
        final p=suggestions[i];
        return SizedBox(width:170, child:InkWell(onTap:()=>addProduct(p), borderRadius:BorderRadius.circular(22), child:ProCard(padding:const EdgeInsets.all(12), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Text(p['name'].toString(), maxLines:2, overflow:TextOverflow.ellipsis, style:const TextStyle(fontWeight:FontWeight.w900)),
          const Spacer(),
          Text('${p['category']} | موجودی: ${fa('${p['stock']}')}', style:const TextStyle(fontSize:11,color:Colors.grey)),
          Text(money(p['sellPrice'] as int), style:TextStyle(color:Theme.of(context).colorScheme.primary, fontWeight:FontWeight.w900)),
        ]))));
      })),
      Expanded(child:cart.isEmpty?const EmptyState(icon:Icons.shopping_cart_outlined,title:'سبد خالی است',subtitle:'کالا را جستجو و انتخاب کن.') : ListView.separated(padding:const EdgeInsets.all(16), itemCount:cart.length, separatorBuilder:(_,__)=>const SizedBox(height:8), itemBuilder:(context,i){
        final item=cart[i];
        return ProCard(padding:const EdgeInsets.all(12), child:Row(children:[
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
            Text(item.name, style:const TextStyle(fontWeight:FontWeight.w900)),
            Text('${money(item.sellPrice)} × ${fa('${item.qty}')} = ${money(item.total)}', style:const TextStyle(color:Colors.grey,fontSize:12)),
          ])),
          IconButton(onPressed:()=>setState(()=>item.qty++), icon:const Icon(Icons.add_circle_outline)),
          Text(fa('${item.qty}'), style:const TextStyle(fontWeight:FontWeight.w900)),
          IconButton(onPressed:()=>setState((){ item.qty--; if(item.qty<=0) cart.removeAt(i); }), icon:const Icon(Icons.remove_circle_outline)),
        ]));
      })),
      Container(padding:const EdgeInsets.all(14), decoration:const BoxDecoration(color:Colors.white, boxShadow:[BoxShadow(color:Color(0x11000000), blurRadius:18, offset:Offset(0,-8))]), child:SafeArea(top:false, child:Column(children:[
        ExpansionTile(tilePadding:EdgeInsets.zero, title:const Text('تخفیف، مالیات و حمل', style:TextStyle(fontWeight:FontWeight.w900)), children:[
          Row(children:[
            Expanded(child:ProField(controller:discountAmount,label:'تخفیف مبلغی',keyboardType:TextInputType.number)),
            const SizedBox(width:8),
            Expanded(child:ProField(controller:discountPercent,label:'تخفیف درصدی',keyboardType:TextInputType.number)),
          ]),
          const SizedBox(height:8),
          Row(children:[
            Expanded(child:ProField(controller:tax,label:'مالیات',keyboardType:TextInputType.number)),
            const SizedBox(width:8),
            Expanded(child:ProField(controller:delivery,label:'حمل',keyboardType:TextInputType.number)),
          ]),
          const SizedBox(height:8),
        ]),
        InfoLine(label:'جمع کالاها', value:money(subtotal)),
        InfoLine(label:'تخفیف', value:money(discount)),
        InfoLine(label:'جمع نهایی', value:money(total)),
        SegmentedButton<String>(segments:const [ButtonSegment(value:'cash',label:Text('نقد')), ButtonSegment(value:'credit',label:Text('نسیه'))], selected:{paymentType}, onSelectionChanged:(v)=>setState(()=>paymentType=v.first)),
        const SizedBox(height:8),
        SizedBox(width:double.infinity, child:FilledButton.icon(onPressed:finishSale, icon:const Icon(Icons.check), label:const Text('ثبت فروش'))),
      ]))),
    ]));
  }

  Future<void> finishSale() async {
    if (!CurrentSession.can('sell')) { toast(context,'دسترسی ثبت فروش ندارید'); return; }
    if (customer.text.trim().isEmpty) { toast(context,'نام مشتری را وارد کن'); return; }
    if (cart.isEmpty) { toast(context,'سبد خرید خالی است'); return; }
    final customerId=await Db.findOrCreateCustomer(customer.text.trim());
    final saleId=await Db.saveSale(customerId:customerId, customerName:customer.text.trim(), paymentType:paymentType, subtotal:subtotal, discount:discount, tax:taxAmount, delivery:deliveryAmount, total:total, items:cart);
    final txt=invoiceText(saleId);
    await showShareDialog(context, txt, title:'فروش ثبت شد', subtitle:'فاکتور ${fa('$saleId')}\nمبلغ: ${money(total)}');
    setState((){ customer.clear(); search.clear(); discountAmount.text='0'; discountPercent.text='0'; tax.text='0'; delivery.text='0'; cart.clear(); paymentType='cash'; });
    searchProducts('');
  }

  String invoiceText(int saleId) {
    final b=StringBuffer();
    b.writeln('فاکتور سوپرمارکت');
    b.writeln('شماره: ${fa('$saleId')}');
    b.writeln('تاریخ: ${jalaliSimple(todayIso())}');
    b.writeln('فروشنده: ${CurrentSession.username}');
    b.writeln('مشتری: ${customer.text.trim()}');
    b.writeln('پرداخت: ${paymentType=='cash'?'نقد':'نسیه'}');
    b.writeln('--------------------');
    for(final item in cart){ b.writeln('${item.name} | ${fa('${item.qty}')} عدد | ${money(item.total)}'); }
    b.writeln('--------------------');
    b.writeln('جمع کالاها: ${money(subtotal)}');
    b.writeln('تخفیف: ${money(discount)}');
    b.writeln('مالیات: ${money(taxAmount)}');
    b.writeln('حمل: ${money(deliveryAmount)}');
    b.writeln('جمع نهایی: ${money(total)}');
    return b.toString();
  }
}

// ---------------- Customers ----------------

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});
  @override
  State<CustomersPage> createState()=>_CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  Future<List<Map<String,Object?>>>? future;
  final search=TextEditingController();
  @override
  void initState() { super.initState(); reload(); }
  void reload()=>setState(()=>future=load());
  Future<List<Map<String,Object?>>> load() async {
    final list=await Db.customers(search.text);
    final out=<Map<String,Object?>>[];
    for(final c in list){ out.add({...c, 'balance': await Db.balance(c['id'] as int)}); }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return ProScaffold(title:'مشتریان', action:IconButton(onPressed:()=>editCustomer(), icon:const Icon(Icons.person_add_alt)), child:Column(children:[
      Padding(padding:const EdgeInsets.all(16), child:TextField(controller:search, onChanged:(_)=>reload(), decoration:const InputDecoration(labelText:'جستجوی مشتری', prefixIcon:Icon(Icons.search)))),
      Expanded(child:FutureBuilder<List<Map<String,Object?>>>(future:future, builder:(context,snap){
        final list=snap.data??[];
        if(list.isEmpty) return const EmptyState(icon:Icons.people_outline,title:'مشتری نیست',subtitle:'مشتری جدید ثبت کن.');
        return ListView.separated(padding:const EdgeInsets.all(16), itemCount:list.length, separatorBuilder:(_,__)=>const SizedBox(height:8), itemBuilder:(context,i){
          final c=list[i]; final bal=c['balance'] as int;
          return ProCard(child:ListTile(
            leading:CircleAvatar(child:Text(c['name'].toString()[0])),
            title:Text(c['name'].toString(), style:const TextStyle(fontWeight:FontWeight.w900)),
            subtitle:Text('${c['groupName'] ?? 'عادی'} | سقف اعتبار: ${money(c['creditLimit'] as int? ?? 0)}'),
            trailing:Text(signedMoney(bal), style:const TextStyle(fontWeight:FontWeight.w900)),
            onTap:()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>CustomerDetailsPage(customerId:c['id'] as int))).then((_)=>reload()),
          ));
        });
      })),
    ]));
  }

  Future<void> editCustomer({Map<String,Object?>? customer}) async {
    if (!CurrentSession.can('editCustomer')) { toast(context,'دسترسی ویرایش مشتری ندارید'); return; }
    final name=TextEditingController(text:customer?['name']?.toString()??'');
    final phone=TextEditingController(text:customer?['phone']?.toString()??'');
    final note=TextEditingController(text:customer?['note']?.toString()??'');
    final credit=TextEditingController(text:customer?['creditLimit']?.toString()??'0');
    String group=customer?['groupName']?.toString()??'عادی';
    final ok=await showDialog<bool>(context:context,builder:(context)=>StatefulBuilder(builder:(context,setState)=>Directionality(textDirection:TextDirection.rtl, child:AlertDialog(title:Text(customer==null?'افزودن مشتری':'ویرایش مشتری'), content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min, children:[
      ProField(controller:name,label:'نام مشتری',icon:Icons.person_outline), const SizedBox(height:8),
      ProField(controller:phone,label:'موبایل',icon:Icons.phone_outlined), const SizedBox(height:8),
      DropdownButtonFormField<String>(value:group, decoration:const InputDecoration(labelText:'گروه مشتری'), items:['عادی','ثابت','عمده‌فروش','VIP'].map((e)=>DropdownMenuItem(value:e, child:Text(e))).toList(), onChanged:(v)=>setState(()=>group=v??group)),
      const SizedBox(height:8), ProField(controller:credit,label:'سقف اعتبار',icon:Icons.credit_score,keyboardType:TextInputType.number),
      const SizedBox(height:8), ProField(controller:note,label:'یادداشت',icon:Icons.note_alt_outlined),
    ])), actions:[TextButton(onPressed:()=>Navigator.pop(context,false), child:const Text('انصراف')), FilledButton(onPressed:()=>Navigator.pop(context,true), child:const Text('ذخیره'))]))));
    if(ok==true && name.text.trim().isNotEmpty){ await Db.saveCustomer(id:customer?['id'] as int?, name:name.text, phone:phone.text, note:note.text, groupName:group, creditLimit:cleanAmount(credit.text)); reload(); }
  }
}

class CustomerDetailsPage extends StatefulWidget {
  final int customerId;
  const CustomerDetailsPage({super.key, required this.customerId});
  @override
  State<CustomerDetailsPage> createState()=>_CustomerDetailsPageState();
}

class _CustomerDetailsPageState extends State<CustomerDetailsPage> {
  Map<String,Object?>? customer;
  int balance=0;
  List<Map<String,Object?>> txs=[];
  @override
  void initState() { super.initState(); reload(); }
  Future<void> reload() async {
    customer=await Db.customer(widget.customerId);
    balance=await Db.balance(widget.customerId);
    txs=await Db.transactions(widget.customerId);
    setState((){});
  }
  @override
  Widget build(BuildContext context) {
    final c=customer;
    if(c==null) return const ProScaffold(title:'مشتری', child:Center(child:CircularProgressIndicator()));
    final creditLimit=c['creditLimit'] as int? ?? 0;
    return ProScaffold(title:c['name'].toString(), child:ListView(padding:const EdgeInsets.all(16), children:[
      ProCard(child:Column(children:[
        InfoLine(label:'مانده حساب', value:signedMoney(balance)),
        InfoLine(label:'گروه', value:c['groupName']?.toString()??'عادی'),
        InfoLine(label:'سقف اعتبار', value:money(creditLimit)),
        if(balance>creditLimit && creditLimit>0) const Text('هشدار: بدهی از سقف اعتبار بیشتر است', style:TextStyle(color:Colors.red, fontWeight:FontWeight.w900)),
      ])),
      const SizedBox(height:10),
      Row(children:[
        Expanded(child:FilledButton.icon(onPressed:()=>addTx('payment'), icon:const Icon(Icons.payments_outlined), label:const Text('پرداخت'))),
        const SizedBox(width:8),
        Expanded(child:OutlinedButton.icon(onPressed:()=>addTx('debt'), icon:const Icon(Icons.add_card), label:const Text('بدهی'))),
      ]),
      const SizedBox(height:8),
      Row(children:[
        Expanded(child:OutlinedButton.icon(onPressed:()=>showShareDialog(context, statement(), title:'صورتحساب کامل', subtitle:'ارسال از واتساپ، روبیکا یا بله'), icon:const Icon(Icons.send), label:const Text('ارسال صورتحساب'))),
        const SizedBox(width:8),
        Expanded(child:OutlinedButton.icon(onPressed:copyStatement, icon:const Icon(Icons.copy), label:const Text('کپی'))),
      ]),
      const SizedBox(height:16),
      Text('ریز حساب', style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w900)),
      ...txs.map((t)=>ProCard(padding:const EdgeInsets.all(12), child:ListTile(
        title:Text('${t['type']=='debt'?'بدهی':'پرداخت'} - ${money(t['amount'] as int)}'),
        subtitle:Text('${jalaliSimple(t['dateIso'].toString())}\n${t['note'] ?? ''}'),
        isThreeLine:true,
      )))
    ]));
  }

  String statement() {
    final c=customer!;
    final b=StringBuffer();
    b.writeln('صورتحساب مشتری');
    b.writeln('نام: ${c['name']}');
    b.writeln('تاریخ: ${jalaliSimple(todayIso())}');
    b.writeln('مانده حساب: ${signedMoney(balance)}');
    b.writeln('--------------------');
    for(final t in txs){ b.writeln('${t['type']=='debt'?'بدهی':'پرداخت'} | ${money(t['amount'] as int)} | ${jalaliSimple(t['dateIso'].toString())} | ${t['note'] ?? ''}'); }
    return b.toString();
  }

  Future<void> copyStatement() async { await Clipboard.setData(ClipboardData(text:statement())); if(mounted)toast(context,'صورتحساب کپی شد'); }

  Future<void> addTx(String type) async {
    final amount=TextEditingController();
    final note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(context)=>Directionality(textDirection:TextDirection.rtl, child:AlertDialog(title:Text(type=='debt'?'ثبت بدهی':'ثبت پرداخت'), content:Column(mainAxisSize:MainAxisSize.min, children:[
      ProField(controller:amount,label:'مبلغ',icon:Icons.payments_outlined,keyboardType:TextInputType.number), const SizedBox(height:8),
      ProField(controller:note,label:'توضیح',icon:Icons.note_alt_outlined),
    ]), actions:[TextButton(onPressed:()=>Navigator.pop(context,false), child:const Text('انصراف')), FilledButton(onPressed:()=>Navigator.pop(context,true), child:const Text('ثبت'))])));
    if(ok==true){ final a=cleanAmount(amount.text); if(a>0){ await Db.addTransaction(widget.customerId,type,a,note.text); reload(); } }
  }
}

// ---------------- Products ----------------

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});
  @override
  State<ProductsPage> createState()=>_ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  Future<List<Map<String,Object?>>>? future;
  final search=TextEditingController();
  @override
  void initState() { super.initState(); reload(); }
  void reload()=>setState(()=>future=Db.allProducts());
  @override
  Widget build(BuildContext context) {
    return ProScaffold(title:'کالاها', action:IconButton(onPressed:()=>editProduct(), icon:const Icon(Icons.add)), child:FutureBuilder<List<Map<String,Object?>>>(future:future, builder:(context,snap){
      final all=snap.data??[];
      final q=search.text.trim();
      final list=q.isEmpty?all:all.where((p)=>p['name'].toString().contains(q)||(p['category']?.toString()??'').contains(q)).toList();
      return Column(children:[
        Padding(padding:const EdgeInsets.all(16), child:TextField(controller:search, onChanged:(_)=>setState((){}), decoration:const InputDecoration(labelText:'جستجوی کالا', prefixIcon:Icon(Icons.search)))),
        Expanded(child:ListView.separated(padding:const EdgeInsets.all(16), itemCount:list.length, separatorBuilder:(_,__)=>const SizedBox(height:8), itemBuilder:(context,i){
          final p=list[i];
          final low=(p['stock'] as int) <= (p['minStock'] as int);
          return ProCard(child:ListTile(
            title:Text(p['name'].toString(), style:const TextStyle(fontWeight:FontWeight.w900)),
            subtitle:Text('${p['category']} | موجودی: ${fa('${p['stock']}')} | حداقل: ${fa('${p['minStock']}')}'),
            trailing:Column(mainAxisAlignment:MainAxisAlignment.center, crossAxisAlignment:CrossAxisAlignment.end, children:[
              Text(money(p['sellPrice'] as int), style:const TextStyle(fontWeight:FontWeight.w900)),
              if(low) const Text('کم‌موجودی', style:TextStyle(color:Colors.red, fontSize:11)),
            ]),
            onTap:()=>editProduct(product:p),
          ));
        })),
      ]);
    }));
  }

  Future<void> editProduct({Map<String,Object?>? product}) async {
    if(!CurrentSession.can('editProduct')) { toast(context,'دسترسی ویرایش کالا ندارید'); return; }
    final name=TextEditingController(text:product?['name']?.toString()??'');
    final buy=TextEditingController(text:product?['buyPrice']?.toString()??'');
    final sell=TextEditingController(text:product?['sellPrice']?.toString()??'');
    final stock=TextEditingController(text:product?['stock']?.toString()??'0');
    final minStock=TextEditingController(text:product?['minStock']?.toString()??'5');
    final cat=TextEditingController(text:product?['category']?.toString()??'');
    final ok=await showDialog<bool>(context:context,builder:(context)=>Directionality(textDirection:TextDirection.rtl, child:AlertDialog(title:Text(product==null?'افزودن کالا':'ویرایش کالا'), content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min, children:[
      ProField(controller:name,label:'نام کالا',icon:Icons.inventory_2_outlined), const SizedBox(height:8),
      Row(children:[Expanded(child:ProField(controller:buy,label:'قیمت خرید',keyboardType:TextInputType.number)), const SizedBox(width:8), Expanded(child:ProField(controller:sell,label:'قیمت فروش',keyboardType:TextInputType.number))]),
      const SizedBox(height:8),
      Row(children:[Expanded(child:ProField(controller:stock,label:'موجودی',keyboardType:TextInputType.number)), const SizedBox(width:8), Expanded(child:ProField(controller:minStock,label:'حداقل موجودی',keyboardType:TextInputType.number))]),
      const SizedBox(height:8), ProField(controller:cat,label:'دسته‌بندی',icon:Icons.category_outlined),
    ])), actions:[
      if(product!=null) TextButton(onPressed:()async{ await Db.deleteProduct(product['id'] as int); if(context.mounted)Navigator.pop(context,true); }, child:const Text('حذف')),
      TextButton(onPressed:()=>Navigator.pop(context,false), child:const Text('انصراف')),
      FilledButton(onPressed:()=>Navigator.pop(context,true), child:const Text('ذخیره')),
    ])));
    if(ok==true && name.text.trim().isNotEmpty) {
      await Db.saveProduct(id:product?['id'] as int?, name:name.text, buyPrice:cleanAmount(buy.text), sellPrice:cleanAmount(sell.text), stock:cleanAmount(stock.text), minStock:cleanAmount(minStock.text), category:cat.text);
      reload();
    }
  }
}

// ---------------- More / Reports / Staff ----------------

class MorePage extends StatelessWidget {
  final VoidCallback onLogout;
  const MorePage({super.key, required this.onLogout});
  @override
  Widget build(BuildContext context) {
    return ProScaffold(title:'بیشتر', child:ListView(padding:const EdgeInsets.all(16), children:[
      MenuTile(icon:Icons.bar_chart, title:'گزارش فروش', onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ReportsPage()))),
      MenuTile(icon:Icons.assignment_return_outlined, title:'مرجوعی / ابطال فاکتور', onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ReturnsPage()))),
      if(CurrentSession.isAdmin) MenuTile(icon:Icons.manage_accounts, title:'مدیریت شاگردها', onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const StaffPage()))),
      MenuTile(icon:Icons.backup_outlined, title:'بکاپ JSON', onTap:()async{ final txt=await Db.backupText(); await Clipboard.setData(ClipboardData(text:txt)); if(context.mounted)toast(context,'بکاپ کپی شد'); }),
      MenuTile(icon:Icons.settings, title:'تنظیمات فروشگاه', onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsPage(onLogout:onLogout)))),
      const SizedBox(height:12),
      FilledButton.tonalIcon(onPressed:onLogout, icon:const Icon(Icons.lock_outline), label:const Text('خروج')),
    ]));
  }
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState()=>_ReportsPageState();
}
class _ReportsPageState extends State<ReportsPage> {
  Future<Map<String,int>>? stats;
  Future<List<Map<String,Object?>>>? staffReport;
  @override void initState(){ super.initState(); reload(); }
  void reload(){ stats=Db.stats(); staffReport=Db.staffReport(); setState((){}); }
  @override
  Widget build(BuildContext context){
    if(!CurrentSession.can('viewReports')) return const ProScaffold(title:'گزارش', child:Center(child:Text('دسترسی مشاهده گزارش ندارید')));
    return ProScaffold(title:'گزارش فروش', child:RefreshIndicator(onRefresh:()async=>reload(), child:ListView(padding:const EdgeInsets.all(16), children:[
      FutureBuilder<Map<String,int>>(future:stats,builder:(context,snap){ final s=snap.data??{}; return ProCard(child:Column(children:[
        InfoLine(label:'کل فروش', value:money(s['sales']??0)),
        InfoLine(label:'فروش نقد', value:money(s['cash']??0)),
        InfoLine(label:'فروش نسیه', value:money(s['credit']??0)),
        if(CurrentSession.can('viewProfit')) InfoLine(label:'سود تقریبی', value:money(s['profit']??0)),
        InfoLine(label:'تخفیف‌ها', value:money(s['discount']??0)),
      ])); }),
      const SizedBox(height:16),
      Text('عملکرد شاگردها', style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w900)),
      FutureBuilder<List<Map<String,Object?>>>(future:staffReport,builder:(context,snap){ final list=snap.data??[]; return Column(children:list.map((r)=>Padding(padding:const EdgeInsets.only(top:8), child:ProCard(child:Column(children:[
        InfoLine(label:'فروشنده', value:r['staffName']?.toString()??'-'),
        InfoLine(label:'تعداد فاکتور', value:fa('${r['invoiceCount']??0}')),
        InfoLine(label:'فروش کل', value:money((r['totalSales'] as int?)??0)),
        InfoLine(label:'نقد', value:money((r['cashSales'] as int?)??0)),
        InfoLine(label:'نسیه', value:money((r['creditSales'] as int?)??0)),
        if(CurrentSession.can('viewProfit')) InfoLine(label:'سود', value:money((r['profit'] as int?)??0)),
      ])))).toList()); }),
    ])));
  }
}

class ReturnsPage extends StatefulWidget {
  const ReturnsPage({super.key});
  @override
  State<ReturnsPage> createState()=>_ReturnsPageState();
}
class _ReturnsPageState extends State<ReturnsPage> {
  Future<List<Map<String,Object?>>>? future;
  @override void initState(){ super.initState(); reload(); }
  void reload()=>setState(()=>future=Db.sales());
  @override
  Widget build(BuildContext context){
    return ProScaffold(title:'مرجوعی / ابطال فاکتور', child:FutureBuilder<List<Map<String,Object?>>>(future:future,builder:(context,snap){
      final list=snap.data??[];
      return ListView.separated(padding:const EdgeInsets.all(16), itemCount:list.length, separatorBuilder:(_,__)=>const SizedBox(height:8), itemBuilder:(context,i){
        final s=list[i];
        final cancelled=s['status']=='cancelled';
        return ProCard(child:ListTile(
          title:Text('فاکتور ${fa('${s['id']}')} - ${money(s['total'] as int)}'),
          subtitle:Text('${s['customerName']} | ${s['paymentType']=='cash'?'نقد':'نسیه'} | ${cancelled?'باطل شده':'فعال'}'),
          trailing:cancelled?const Icon(Icons.cancel,color:Colors.red):IconButton(icon:const Icon(Icons.undo), onPressed:()async{
            if(!CurrentSession.can('deleteInvoice')){ toast(context,'دسترسی ابطال فاکتور ندارید'); return; }
            final ok=await confirm(context,'ابطال فاکتور','موجودی کالاها برگردد و فاکتور باطل شود؟');
            if(ok){ await Db.cancelSale(s['id'] as int); reload(); }
          }),
        ));
      });
    }));
  }
}

class StaffPage extends StatefulWidget {
  const StaffPage({super.key});
  @override State<StaffPage> createState()=>_StaffPageState();
}
class _StaffPageState extends State<StaffPage>{
  Future<List<Map<String,Object?>>>? future;
  @override void initState(){ super.initState(); reload(); }
  void reload()=>setState(()=>future=Db.staff());
  @override Widget build(BuildContext context)=>ProScaffold(title:'مدیریت شاگردها', action:IconButton(icon:const Icon(Icons.add), onPressed:()=>editStaff()), child:FutureBuilder<List<Map<String,Object?>>>(future:future,builder:(context,snap){
    final list=snap.data??[];
    return ListView.separated(padding:const EdgeInsets.all(16), itemCount:list.length, separatorBuilder:(_,__)=>const SizedBox(height:8), itemBuilder:(context,i){
      final s=list[i];
      return ProCard(child:ListTile(title:Text(s['name'].toString(),style:const TextStyle(fontWeight:FontWeight.w900)), subtitle:Text('${s['username']} | ${s['role']} | ${s['active']==1?'فعال':'غیرفعال'}'), onTap:()=>editStaff(staff:s)));
    });
  }));
  Future<void> editStaff({Map<String,Object?>? staff})async{
    final name=TextEditingController(text:staff?['name']?.toString()??''); final username=TextEditingController(text:staff?['username']?.toString()??''); final password=TextEditingController(text:staff?['password']?.toString()??'');
    int active=(staff?['active'] as int?)??1, sell=(staff?['canSell'] as int?)??1, ep=(staff?['canEditProduct'] as int?)??0, ec=(staff?['canEditCustomer'] as int?)??0, di=(staff?['canDeleteInvoice'] as int?)??0, vp=(staff?['canViewProfit'] as int?)??0, vr=(staff?['canViewReports'] as int?)??0;
    final ok=await showDialog<bool>(context:context,builder:(context)=>StatefulBuilder(builder:(context,setState)=>Directionality(textDirection:TextDirection.rtl, child:AlertDialog(title:Text(staff==null?'افزودن شاگرد':'ویرایش شاگرد'), content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min, children:[
      ProField(controller:name,label:'نام',icon:Icons.person_outline), const SizedBox(height:8), ProField(controller:username,label:'نام کاربری'), const SizedBox(height:8), ProField(controller:password,label:'رمز'),
      SwitchListTile(value:active==1,onChanged:(v)=>setState(()=>active=v?1:0),title:const Text('فعال')),
      CheckboxListTile(value:sell==1,onChanged:(v)=>setState(()=>sell=v!?1:0),title:const Text('ثبت فروش')),
      CheckboxListTile(value:ep==1,onChanged:(v)=>setState(()=>ep=v!?1:0),title:const Text('ویرایش کالا')),
      CheckboxListTile(value:ec==1,onChanged:(v)=>setState(()=>ec=v!?1:0),title:const Text('ویرایش مشتری')),
      CheckboxListTile(value:di==1,onChanged:(v)=>setState(()=>di=v!?1:0),title:const Text('ابطال فاکتور')),
      CheckboxListTile(value:vp==1,onChanged:(v)=>setState(()=>vp=v!?1:0),title:const Text('مشاهده سود')),
      CheckboxListTile(value:vr==1,onChanged:(v)=>setState(()=>vr=v!?1:0),title:const Text('مشاهده گزارش')),
    ])), actions:[TextButton(onPressed:()=>Navigator.pop(context,false), child:const Text('انصراف')), FilledButton(onPressed:()=>Navigator.pop(context,true), child:const Text('ذخیره'))]))));
    if(ok==true && name.text.trim().isNotEmpty){ await Db.saveStaff(id:staff?['id'] as int?, name:name.text, username:username.text, password:password.text, active:active, canSell:sell, canEditProduct:ep, canEditCustomer:ec, canDeleteInvoice:di, canViewProfit:vp, canViewReports:vr); reload(); }
  }
}

class SettingsPage extends StatefulWidget {
  final VoidCallback onLogout;
  const SettingsPage({super.key, required this.onLogout});
  @override State<SettingsPage> createState()=>_SettingsPageState();
}
class _SettingsPageState extends State<SettingsPage>{
  final business=TextEditingController(), phone=TextEditingController(), code=TextEditingController();
  @override void initState(){ super.initState(); load(); }
  Future<void> load()async{ business.text=await Db.setting('businessName')??''; phone.text=await Db.setting('businessPhone')??''; code.text=await Db.setting('storeCode')??'SM1001'; setState((){}); }
  @override Widget build(BuildContext context)=>ProScaffold(title:'تنظیمات', child:ListView(padding:const EdgeInsets.all(16), children:[
    ProCard(child:Column(children:[ProField(controller:business,label:'نام سوپرمارکت',icon:Icons.storefront), const SizedBox(height:8), ProField(controller:phone,label:'شماره تماس',icon:Icons.phone), const SizedBox(height:8), ProField(controller:code,label:'کد فروشگاه',icon:Icons.store_mall_directory_outlined), const SizedBox(height:12), FilledButton(onPressed:save, child:const Text('ذخیره'))])),
  ]));
  Future<void> save()async{ await Db.setSetting('businessName',business.text); await Db.setSetting('businessPhone',phone.text); await Db.setSetting('storeCode',code.text.toUpperCase()); if(mounted)toast(context,'ذخیره شد'); }
}

// ---------------- Share / UI ----------------

Future<void> showShareDialog(BuildContext context, String text, {required String title, required String subtitle}) async {
  await showDialog(context:context,builder:(context)=>Directionality(textDirection:TextDirection.rtl, child:AlertDialog(title:Text(title), content:Text(subtitle), actions:[
    TextButton(onPressed:()async{ await Clipboard.setData(ClipboardData(text:text)); if(context.mounted)Navigator.pop(context); }, child:const Text('کپی')),
    TextButton(onPressed:()async{ await openUrlOrCopy(context,'https://wa.me/?text=${Uri.encodeComponent(text)}',text); if(context.mounted)Navigator.pop(context); }, child:const Text('واتساپ')),
    TextButton(onPressed:()async{ await openUrlOrCopy(context,'rubika://share?text=${Uri.encodeComponent(text)}',text); if(context.mounted)Navigator.pop(context); }, child:const Text('روبیکا')),
    FilledButton(onPressed:()async{ await openUrlOrCopy(context,'https://ble.ir/share/url?text=${Uri.encodeComponent(text)}',text); if(context.mounted)Navigator.pop(context); }, child:const Text('بله')),
  ])));
}
Future<void> openUrlOrCopy(BuildContext context, String url, String text) async {
  final ok=await launchUrl(Uri.parse(url), mode:LaunchMode.externalApplication);
  if(!ok){ await Clipboard.setData(ClipboardData(text:text)); if(context.mounted)toast(context,'برنامه باز نشد؛ متن کپی شد'); }
}
Future<bool> confirm(BuildContext context, String title, String msg) async => await showDialog<bool>(context:context,builder:(context)=>Directionality(textDirection:TextDirection.rtl, child:AlertDialog(title:Text(title), content:Text(msg), actions:[TextButton(onPressed:()=>Navigator.pop(context,false), child:const Text('نه')), FilledButton(onPressed:()=>Navigator.pop(context,true), child:const Text('بله'))])))??false;

class ProBackground extends StatelessWidget {
  final Widget child;
  const ProBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context)=>Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Brand.cream, Color(0xffEEF6F1), Color(0xffFDFBF7)]),
    ),
    child: child,
  );
}

class ProScaffold extends StatelessWidget {
  final String title; final Widget child; final Widget? action;
  const ProScaffold({super.key, required this.title, required this.child, this.action});
  @override
  Widget build(BuildContext context)=>Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: Row(children:[
          const MiniBrandMark(),
          const SizedBox(width:10),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: Brand.navy))),
        ]),
        actions: action==null?null:[Padding(padding: const EdgeInsets.only(left: 10), child: action!)],
      ),
      body: child,
    ),
  );
}

class ProCard extends StatelessWidget {
  final Widget child; final EdgeInsetsGeometry padding;
  const ProCard({super.key, required this.child, this.padding=const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context)=>Container(
    decoration: BoxDecoration(
      color: Brand.paper,
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: Brand.teal.withOpacity(.08)),
      boxShadow: Brand.softShadow,
    ),
    child: Padding(padding: padding, child: child),
  );
}

class AppLogo extends StatelessWidget {
  final double size;
  const AppLogo({super.key, this.size = 82});
  @override
  Widget build(BuildContext context)=>Center(
    child: Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(size * .10),
      decoration: BoxDecoration(
        gradient: Brand.premiumGradient,
        borderRadius: BorderRadius.circular(size * .30),
        boxShadow: [BoxShadow(color: Brand.deep.withOpacity(.24), blurRadius: 32, offset: const Offset(0, 16))],
      ),
      child: Image.asset('assets/brand/splash_mark.png'),
    ),
  );
}

class MiniBrandMark extends StatelessWidget {
  const MiniBrandMark({super.key});
  @override
  Widget build(BuildContext context)=>Container(
    width: 34,
    height: 34,
    padding: const EdgeInsets.all(4),
    decoration: BoxDecoration(gradient: Brand.premiumGradient, borderRadius: BorderRadius.circular(12)),
    child: Image.asset('assets/brand/splash_mark.png'),
  );
}

class BrandIcon extends StatelessWidget {
  final IconData icon;
  final bool warning;
  const BrandIcon({super.key, required this.icon, this.warning=false});
  @override
  Widget build(BuildContext context)=>Container(
    width: 42,
    height: 42,
    decoration: BoxDecoration(
      gradient: warning ? const LinearGradient(colors:[Color(0xffF59E0B), Color(0xffEA580C)]) : Brand.premiumGradient,
      borderRadius: BorderRadius.circular(16),
      boxShadow: [BoxShadow(color: (warning ? Brand.amber : Brand.teal).withOpacity(.18), blurRadius: 18, offset: const Offset(0,8))],
    ),
    child: Icon(icon, color: Colors.white, size: 22),
  );
}

class NavMark extends StatelessWidget {
  final IconData icon;
  final bool active;
  const NavMark({super.key, required this.icon, this.active=false});
  @override
  Widget build(BuildContext context)=>Container(
    width: 34,
    height: 34,
    decoration: BoxDecoration(
      color: active ? Brand.teal : Colors.transparent,
      borderRadius: BorderRadius.circular(14),
    ),
    child: Icon(icon, size: 21, color: active ? Colors.white : Brand.navy.withOpacity(.62)),
  );
}

class ProField extends StatelessWidget {
  final TextEditingController controller; final String label; final IconData? icon; final TextInputType? keyboardType; final bool obscure;
  const ProField({super.key, required this.controller, required this.label, this.icon, this.keyboardType, this.obscure=false});
  @override Widget build(BuildContext context)=>TextField(controller:controller, keyboardType:keyboardType, obscureText:obscure, decoration:InputDecoration(labelText:label, prefixIcon:icon==null?null:Icon(icon)));
}

class InfoLine extends StatelessWidget {
  final String label,value;
  const InfoLine({super.key, required this.label, required this.value});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.symmetric(vertical:7), child:Row(children:[Text(label,style:TextStyle(color:Brand.navy.withOpacity(.55), fontWeight: FontWeight.w700)), const Spacer(), Flexible(child:Text(value,style:const TextStyle(fontWeight:FontWeight.w900,color:Brand.navy)))]));
}

class EmptyState extends StatelessWidget {
  final IconData icon; final String title,subtitle;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});
  @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(24), child:Column(mainAxisSize:MainAxisSize.min, children:[BrandIcon(icon: icon), const SizedBox(height:12), Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:18,color:Brand.navy)), const SizedBox(height:6), Text(subtitle,textAlign:TextAlign.center,style:TextStyle(color:Brand.navy.withOpacity(.52), fontWeight: FontWeight.w600))])));
}

class HeroCard extends StatelessWidget {
  final String title,value,sub;
  const HeroCard({super.key, required this.title, required this.value, required this.sub});
  @override Widget build(BuildContext context)=>Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(gradient: Brand.premiumGradient, borderRadius: BorderRadius.circular(30), boxShadow: [BoxShadow(color: Brand.deep.withOpacity(.20), blurRadius: 28, offset: const Offset(0,16))]),
    child: Stack(children:[
      Positioned(left:-8, top:-18, child: Icon(Icons.shopping_bag_rounded, color: Colors.white.withOpacity(.10), size: 104)),
      Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
        Row(children: const [BrandIcon(icon: Icons.point_of_sale), SizedBox(width:10), Text('پنل فروشگاه', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]),
        const SizedBox(height:14),
        Text(title,style:const TextStyle(color:Colors.white70, fontWeight: FontWeight.w700)),
        const SizedBox(height:8),
        Text(value,style:const TextStyle(color:Colors.white,fontSize:26,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        Text(sub,style:const TextStyle(color:Colors.white70, fontWeight: FontWeight.w700)),
      ]),
    ]),
  );
}

class StatCard extends StatelessWidget {
  final String label,value; final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  @override Widget build(BuildContext context)=>ProCard(padding:const EdgeInsets.all(13), child:Row(children:[BrandIcon(icon:icon, warning: label.contains('کم')), const SizedBox(width:10), Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, mainAxisAlignment:MainAxisAlignment.center, children:[Text(label,style:TextStyle(color:Brand.navy.withOpacity(.55),fontSize:12,fontWeight:FontWeight.w700)), Text(value,style:const TextStyle(fontWeight:FontWeight.w900,color:Brand.navy))]))]));
}

class MenuTile extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap;
  const MenuTile({super.key, required this.icon, required this.title, required this.onTap});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:10), child:ProCard(padding:const EdgeInsets.all(8), child:ListTile(leading:BrandIcon(icon:icon), title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900,color:Brand.navy)), trailing:Container(width:34,height:34,decoration:BoxDecoration(color:Brand.teal.withOpacity(.10),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.chevron_left,color:Brand.teal)), onTap:onTap)));
}
